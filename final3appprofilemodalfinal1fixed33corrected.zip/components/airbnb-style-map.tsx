"use client"

import { useEffect, useRef, useState } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import type { Service } from "@/lib/service-data"
import { getAvatarByUserId } from "@/utils/avatar-utils"

interface AirbnbStyleMapProps {
  activeFilter: string
  onMarkerClick?: (serviceId: number) => void
  services?: Service[]
  center?: [number, number]
  zoom?: number
}

export default function AirbnbStyleMap({
  activeFilter = "todos",
  onMarkerClick,
  services = [],
  center = [43.263, -2.935], // Bilbao por defecto
  zoom = 14,
}: AirbnbStyleMapProps) {
  const mapRef = useRef<L.Map | null>(null)
  const markersRef = useRef<L.Marker[]>([])
  const mapContainerRef = useRef<HTMLDivElement>(null)
  const [selectedService, setSelectedService] = useState<Service | null>(null)

  // Inicializar el mapa
  useEffect(() => {
    if (!mapContainerRef.current) return

    // Crear el mapa si no existe
    if (!mapRef.current) {
      mapRef.current = L.map(mapContainerRef.current).setView(center, zoom)

      // Añadir capa de mapa estilo Airbnb
      L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: "abcd",
        maxZoom: 19,
      }).addTo(mapRef.current)
    } else {
      // Si el mapa ya existe, actualizar la vista
      mapRef.current.setView(center, zoom)
    }

    // Limpiar al desmontar
    return () => {
      if (mapRef.current) {
        mapRef.current.remove()
        mapRef.current = null
      }
    }
  }, [])

  // Actualizar marcadores cuando cambian los servicios o el filtro
  useEffect(() => {
    if (!mapRef.current) return

    // Limpiar marcadores existentes
    markersRef.current.forEach((marker) => marker.remove())
    markersRef.current = []

    // Filtrar servicios según el filtro activo
    const filteredServices =
      activeFilter === "todos" ? services : services.filter((service) => service.type === activeFilter)

    // Crear nuevos marcadores
    filteredServices.forEach((service) => {
      // Crear icono personalizado según el tipo de servicio
      const getMarkerColor = (type: string) => {
        switch (type) {
          case "particulares":
            return "#FF5A5F" // Rojo Airbnb
          case "profesionales":
            return "#00A699" // Verde Airbnb
          case "anuncios":
            return "#FC642D" // Naranja Airbnb
          case "ofertas":
            return "#FFBD00" // Amarillo Airbnb
          default:
            return "#767676" // Gris Airbnb
        }
      }

      const getCategoryEmoji = (category: string) => {
        switch (category) {
          case "fontaneria":
            return "🔧"
          case "musica":
            return "🎸"
          case "pintura":
            return "🎨"
          case "comida":
            return "🍲"
          case "mudanzas":
            return "🚚"
          case "informatica":
            return "💻"
          case "alojamiento":
            return "🏠"
          case "educacion":
            return "📚"
          case "electricidad":
            return "⚡"
          case "bienestar":
            return "💆"
          default:
            return "📌"
        }
      }

      // Crear HTML para el marcador personalizado (versión simplificada)
      const markerHtml = `
        <div style="
          background-color: ${getMarkerColor(service.type)};
          color: white;
          font-weight: bold;
          font-size: 12px;
          padding: 5px 8px;
          border-radius: 16px;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <span style="margin-right: 4px;">${getCategoryEmoji(service.category)}</span>
          <span>${service.price}€</span>
        </div>
      `

      // Crear icono personalizado
      const customIcon = L.divIcon({
        html: markerHtml,
        className: "custom-marker",
        iconSize: [80, 30],
        iconAnchor: [40, 15],
      })

      // Crear marcador
      const marker = L.marker([service.lat, service.lng], { icon: customIcon }).addTo(mapRef.current!)

      // Añadir evento de clic
      marker.on("click", () => {
        setSelectedService(service)
        if (onMarkerClick) {
          onMarkerClick(service.id)
        }
      })

      // Guardar referencia al marcador
      markersRef.current.push(marker)
    })
  }, [services, activeFilter, onMarkerClick])

  return (
    <div className="relative h-full w-full">
      <div ref={mapContainerRef} className="h-full w-full" />

      {/* Tarjeta de servicio seleccionado */}
      {selectedService && (
        <div className="absolute bottom-4 left-1/2 z-10 w-[90%] max-w-md -translate-x-1/2 transform rounded-xl bg-white p-4 shadow-lg">
          <div className="flex">
            <div className="mr-3 h-12 w-12 overflow-hidden rounded-full">
              <img
                src={getAvatarByUserId(selectedService.userId) || "/placeholder.svg"}
                alt={selectedService.name}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="flex-1">
              <div className="mb-1 flex items-center">
                <span className="mr-2 rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-800">
                  {selectedService.category}
                </span>
                <div className="flex items-center text-xs text-yellow-500">
                  ★ {selectedService.rating}
                  <span className="ml-1 text-gray-500">({selectedService.reviews})</span>
                </div>
              </div>
              <h3 className="text-sm font-semibold">{selectedService.name}</h3>
              <p className="text-xs text-gray-600">{selectedService.description}</p>
              <div className="mt-2 flex items-center justify-between">
                <span className="font-medium text-[#FF5A5F]">{selectedService.price}€/hora</span>
                <button className="rounded-lg bg-[#FF5A5F] px-3 py-1 text-xs font-medium text-white hover:bg-[#FF5A5F]/90">
                  Contactar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
