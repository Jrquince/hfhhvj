"use client"

import { forwardRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, Check, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ServicePreviewProps {
  service: any
  onClose: () => void
}

const ServicePreview = forwardRef<HTMLDivElement, ServicePreviewProps>(({ service, onClose }, ref) => {
  if (!service) return null

  return (
    <Card className="overflow-hidden shadow-md max-w-[280px] rounded-xl border border-gray-100" ref={ref}>
      <CardContent className="p-0">
        {/* Contenido del servicio - Diseño minimalista */}
        <div className="p-3">
          <div className="flex items-start gap-3">
            {/* Avatar */}
            <div className="relative h-10 w-10 flex-shrink-0">
              <div className="h-10 w-10 overflow-hidden rounded-full border border-gray-100">
                <img
                  src={service.image || "/placeholder.svg"}
                  alt={service.name}
                  className="h-full w-full object-cover"
                />
              </div>
              {service.verified && (
                <div className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full bg-blue-500 flex items-center justify-center border border-white">
                  <Check className="h-2 w-2 text-white" />
                </div>
              )}
            </div>

            {/* Información */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-0.5">
                <h3 className="text-sm font-medium truncate">{service.name}</h3>
                <Badge variant="outline" className="bg-gray-50 text-[10px] px-1.5 py-0 h-4 ml-1">
                  {service.category}
                </Badge>
              </div>

              <div className="flex items-center text-[10px] text-gray-500 mb-1">
                <Star className="mr-0.5 h-2.5 w-2.5 fill-amber-400 text-amber-400" />
                <span>{service.rating}</span>
                <span className="ml-0.5 mr-2">({service.reviews || 0})</span>
                <MapPin className="mr-0.5 h-2.5 w-2.5" />
                <span>Bilbao</span>
              </div>

              <p className="text-[10px] text-gray-600 line-clamp-1 mb-2">{service.description}</p>

              <div className="flex items-center justify-between">
                <span className="text-xs font-bold">{service.price}€/h</span>
                <Button size="sm" className="bg-black text-white hover:bg-black/90 h-6 text-xs px-2 rounded-full">
                  <MessageSquare className="h-3 w-3 mr-1" />
                  Contactar
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
})

ServicePreview.displayName = "ServicePreview"

export default ServicePreview
