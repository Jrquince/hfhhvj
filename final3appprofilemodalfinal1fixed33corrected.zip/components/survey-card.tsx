"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ClipboardList, CheckCircle, ArrowRight, X } from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"

interface SurveyCardProps {
  title: string
  options: string[]
  onVote: (option: string) => void
}

export default function SurveyCard({ title, options, onVote }: SurveyCardProps) {
  const [showSurvey, setShowSurvey] = useState(false)
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)

  // Preguntas simuladas para la encuesta
  const questions = [
    {
      question: title,
      options: options,
    },
    {
      question: "¿Con qué frecuencia utilizas este servicio?",
      options: ["Diariamente", "Semanalmente", "Mensualmente", "Ocasionalmente", "Nunca"],
    },
    {
      question: "¿Recomendarías este servicio a un amigo?",
      options: ["Definitivamente sí", "Probablemente sí", "No estoy seguro", "Probablemente no", "Definitivamente no"],
    },
  ]

  const handleSubmit = () => {
    if (selectedOption) {
      onVote(selectedOption)
      if (currentStep < questions.length - 1) {
        setCurrentStep(currentStep + 1)
        setSelectedOption(null)
      } else {
        setIsSubmitted(true)
      }
    }
  }

  const resetSurvey = () => {
    setCurrentStep(0)
    setSelectedOption(null)
    setIsSubmitted(false)
    setShowSurvey(false)
  }

  return (
    <>
      {/* Vista previa minimalista de la encuesta */}
      <div
        className="bg-gradient-to-r from-gray-50 to-gray-100 p-5 rounded-xl border border-gray-200 text-center cursor-pointer hover:shadow-sm transition-shadow"
        onClick={() => setShowSurvey(true)}
      >
        <div className="flex flex-col items-center justify-center space-y-3">
          <div className="bg-white p-3 rounded-full shadow-sm">
            <ClipboardList className="h-6 w-6 text-gray-700" />
          </div>
          <h3 className="font-medium text-gray-800">{title}</h3>
          <p className="text-sm text-gray-600">Participa en esta encuesta y ayúdanos a mejorar</p>
          <Badge className="bg-gray-200 text-gray-700 hover:bg-gray-300">
            <span className="text-xs">Encuesta rápida</span>
          </Badge>
          <Button
            variant="outline"
            size="sm"
            className="mt-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-semibold border-orange-500 shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 px-4 py-2 rounded-lg"
          >
            ¡PARTICIPAR AHORA!
            <ArrowRight className="ml-1.5 h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Modal de encuesta */}
      <Dialog open={showSurvey} onOpenChange={setShowSurvey}>
        <DialogContent className="sm:max-w-[320px] max-w-[90%] w-[320px] rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <DialogTitle className="text-base">{title}</DialogTitle>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={resetSurvey}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="py-2">
            {!isSubmitted ? (
              <>
                <div className="mb-3">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>
                      Pregunta {currentStep + 1} de {questions.length}
                    </span>
                    <span>{Math.round(((currentStep + 1) / questions.length) * 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div
                      className="bg-gray-800 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${((currentStep + 1) / questions.length) * 100}%` }}
                    ></div>
                  </div>
                </div>

                <h3 className="text-sm font-medium mb-2">{questions[currentStep].question}</h3>

                <RadioGroup value={selectedOption || ""} onValueChange={setSelectedOption} className="space-y-2">
                  {questions[currentStep].options.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2 border p-2 rounded-md hover:bg-gray-50">
                      <RadioGroupItem value={option} id={`option-${index}`} />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer text-sm">
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </>
            ) : (
              <div className="text-center py-3">
                <div className="flex justify-center mb-3">
                  <div className="bg-green-100 p-2.5 rounded-full">
                    <CheckCircle className="h-7 w-7 text-green-600" />
                  </div>
                </div>
                <h3 className="text-base font-medium mb-2">¡Gracias por participar!</h3>
                <p className="text-sm text-gray-600 mb-3">
                  Has completado la encuesta correctamente y has ganado un boost de nivel.
                </p>
                <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">+1 Nivel de boost</Badge>
              </div>
            )}
          </div>

          <DialogFooter className="flex justify-between sm:justify-between mt-2 pt-2 border-t">
            {!isSubmitted ? (
              <>
                <Button variant="outline" size="sm" onClick={resetSurvey} className="text-xs h-7">
                  Cancelar
                </Button>
                <Button
                  size="sm"
                  onClick={handleSubmit}
                  disabled={!selectedOption}
                  className="text-xs h-7 bg-gray-900 hover:bg-gray-800"
                >
                  {currentStep < questions.length - 1 ? "Siguiente" : "Finalizar"}
                </Button>
              </>
            ) : (
              <Button size="sm" onClick={resetSurvey} className="w-full text-xs h-7 bg-gray-900 hover:bg-gray-800">
                Cerrar
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
