import Image from "next/image"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { getAvatarByUserId } from "@/lib/avatar-utils"

type ProfileImageProps = {
  profileId?: number
  username?: string
  size?: "sm" | "md" | "lg" | "xl"
  className?: string
  verified?: boolean
}

// Función para determinar si un nombre es probablemente femenino
const isFeminineName = (name?: string): boolean => {
  if (!name) return false

  // Lista de terminaciones comunes en nombres femeninos en español
  const feminineEndings = ["a", "ia", "na", "la", "ra", "ta", "sa", "za"]
  // Lista de nombres femeninos comunes que no siguen el patrón de terminación
  const feminineNames = [
    "mercedes",
    "dolores",
    "pilar",
    "carmen",
    "isabel",
    "beatriz",
    "ruth",
    "raquel",
    "ines",
    "neus",
    "lourdes",
    "mar",
  ]

  const firstName = name.split(" ")[0].toLowerCase()

  return feminineNames.includes(firstName) || feminineEndings.some((ending) => firstName.endsWith(ending))
}

export function ProfileImage({
  profileId = 1,
  username,
  size = "md",
  className = "",
  verified = false,
}: ProfileImageProps) {
  // Determinar el tamaño del avatar basado en el prop size
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-16 w-16",
    xl: "h-20 w-20",
  }

  // Usar la función getAvatarByUserId para obtener la imagen de perfil
  const avatarSrc = getAvatarByUserId(profileId || 1)

  return (
    <div className="relative">
      <Avatar className={`${sizeClasses[size]} border-2 border-gray-200 overflow-hidden ${className}`}>
        <Image
          src={avatarSrc || "/placeholder.svg"}
          alt={`Perfil de ${username || "usuario"}`}
          width={size === "xl" ? 80 : size === "lg" ? 64 : size === "md" ? 40 : 32}
          height={size === "xl" ? 80 : size === "lg" ? 64 : size === "md" ? 40 : 32}
          className="h-full w-full object-cover"
        />
        <AvatarFallback>{username ? username.substring(0, 2).toUpperCase() : "U"}</AvatarFallback>
      </Avatar>

      {verified && (
        <div
          className={`absolute ${
            size === "xl"
              ? "-bottom-1 -right-1"
              : size === "lg"
                ? "-bottom-1 -right-1"
                : size === "md"
                  ? "-bottom-0.5 -right-0.5"
                  : "-bottom-0.5 -right-0.5"
          }`}
        >
          <div
            className={`bg-blue-500 rounded-full flex items-center justify-center ${
              size === "xl" ? "w-6 h-6" : size === "lg" ? "w-5 h-5" : size === "md" ? "w-4 h-4" : "w-3.5 h-3.5"
            }`}
          >
            <svg
              className={`text-white ${
                size === "xl" ? "w-4 h-4" : size === "lg" ? "w-3.5 h-3.5" : size === "md" ? "w-2.5 h-2.5" : "w-2 h-2"
              }`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
            </svg>
          </div>
        </div>
      )}
    </div>
  )
}
