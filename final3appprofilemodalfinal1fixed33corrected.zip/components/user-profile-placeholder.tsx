"use client"

import { useState } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, MessageSquare, ThumbsUp, Award, X, ChevronRight } from "lucide-react"
import { ProfileAvatar } from "./profile-avatar"
import Link from "next/link"

interface UserProfilePlaceholderProps {
  isOpen: boolean
  onClose: () => void
  user: {
    id: string | number
    name: string
    image?: string
    location: string
    verified?: boolean
    rating: number
    recommendations: number
    badges?: string[]
    profession?: string
    experience?: string
    description?: string
  }
}

export default function UserProfilePlaceholder({ isOpen, onClose, user }: UserProfilePlaceholderProps) {
  const [activeTab, setActiveTab] = useState("info")

  // Generar estrellas para la calificación
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${i < Math.floor(rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
        />
      ))
  }

  // Recomendaciones de ejemplo
  const recommendations = [
    {
      id: 1,
      user: { name: "Laura Martínez", image: "/placeholder.svg?height=40&width=40" },
      rating: 5,
      comment: "Excelente profesional, muy puntual y trabajo impecable.",
      date: "hace 2 semanas",
    },
    {
      id: 2,
      user: { name: "Carlos Rodríguez", image: "/placeholder.svg?height=40&width=40" },
      rating: 4,
      comment: "Muy buen servicio, recomendado para trabajos rápidos.",
      date: "hace 1 mes",
    },
    {
      id: 3,
      user: { name: "Ana García", image: "/placeholder.svg?height=40&width=40" },
      rating: 5,
      comment: "Siempre responde rápido y hace un trabajo excelente.",
      date: "hace 2 meses",
    },
  ]

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent
        className="sm:max-w-[320px] max-w-[90%] w-[320px] p-0 rounded-lg overflow-hidden"
        showCloseButton={false}
      >
        <div className="p-4 pb-0">
          <div className="flex items-start justify-between">
            <h2 className="text-lg font-semibold">Perfil</h2>
            <Button variant="ghost" size="icon" onClick={onClose} className="h-7 w-7">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="p-4">
          <div className="flex items-center mb-4">
            <ProfileAvatar
              userId={user.id}
              username={user.name}
              image={user.image}
              size="lg"
              verified={user.verified}
            />
            <div className="ml-3">
              <h3 className="font-medium text-base">{user.name}</h3>
              <div className="flex items-center text-sm text-gray-500 mt-0.5">
                <MapPin className="h-3.5 w-3.5 mr-1" />
                {user.location}
              </div>
              <div className="flex items-center mt-1">
                {renderStars(user.rating)}
                <span className="text-xs text-gray-500 ml-1">({user.rating.toFixed(1)})</span>
              </div>
            </div>
          </div>

          <Tabs defaultValue="info" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-2 h-8">
              <TabsTrigger value="info" className="text-xs">
                Información
              </TabsTrigger>
              <TabsTrigger value="recommendations" className="text-xs">
                Recomendaciones
              </TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="mt-3">
              <div className="space-y-3">
                {user.profession && (
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-1">Profesión</h4>
                    <p className="text-sm">{user.profession}</p>
                  </div>
                )}

                {user.experience && (
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-1">Experiencia</h4>
                    <p className="text-sm">{user.experience}</p>
                  </div>
                )}

                {user.description && (
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-1">Descripción</h4>
                    <p className="text-sm">{user.description}</p>
                  </div>
                )}

                {user.badges && user.badges.length > 0 && (
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-1">Insignias</h4>
                    <div className="flex flex-wrap gap-1">
                      {user.badges.map((badge, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          <Award className="h-3 w-3 mr-1" />
                          {badge}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-2">
                  <h4 className="text-xs font-medium text-gray-500 mb-1">Estadísticas</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-gray-50 p-2 rounded-md">
                      <div className="flex items-center text-gray-600">
                        <ThumbsUp className="h-3.5 w-3.5 mr-1.5" />
                        <span className="text-xs font-medium">Recomendaciones</span>
                      </div>
                      <p className="text-sm font-medium mt-1">{user.recommendations}</p>
                    </div>
                    <div className="bg-gray-50 p-2 rounded-md">
                      <div className="flex items-center text-gray-600">
                        <Star className="h-3.5 w-3.5 mr-1.5" />
                        <span className="text-xs font-medium">Valoración</span>
                      </div>
                      <p className="text-sm font-medium mt-1">{user.rating.toFixed(1)} de 5</p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="recommendations" className="mt-3">
              <div className="space-y-3 max-h-[240px] overflow-y-auto pr-1">
                {recommendations.map((rec) => (
                  <div key={rec.id} className="border rounded-md p-2.5">
                    <div className="flex items-center mb-1.5">
                      <ProfileAvatar
                        userId={rec.id.toString()}
                        username={rec.user.name}
                        image={rec.user.image}
                        size="sm"
                      />
                      <div className="ml-2">
                        <p className="text-xs font-medium">{rec.user.name}</p>
                        <div className="flex mt-0.5">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`h-3 w-3 ${
                                  i < rec.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                        </div>
                      </div>
                      <span className="text-[10px] text-gray-500 ml-auto">{rec.date}</span>
                    </div>
                    <p className="text-xs text-gray-600">{rec.comment}</p>
                  </div>
                ))}

                <Button variant="ghost" size="sm" className="w-full text-xs h-7 mt-2">
                  Ver todas las recomendaciones
                  <ChevronRight className="h-3.5 w-3.5 ml-1" />
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="p-3 border-t flex space-x-2">
          <Link href={`/chat-detail/${user.id}`} className="flex-1">
            <Button className="w-full h-8 text-xs bg-gray-900 hover:bg-gray-800">
              <MessageSquare className="h-3.5 w-3.5 mr-1.5" />
              Contactar
            </Button>
          </Link>
          <Button variant="outline" className="h-8 text-xs" onClick={() => setActiveTab("recommendations")}>
            <ThumbsUp className="h-3.5 w-3.5 mr-1.5" />
            Ver recomendaciones
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
