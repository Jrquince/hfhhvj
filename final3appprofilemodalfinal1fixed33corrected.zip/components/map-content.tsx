"use client"

import { useState } from "react"
import { Search, ArrowLeft } from "lucide-react"
import dynamic from "next/dynamic"

// Importar el mapa dinámicamente para evitar problemas de SSR
const BilbaoMap = dynamic(() => import("./bilbao-map"), {
  ssr: false,
  loading: () => (
    <div className="flex-1 flex items-center justify-center bg-gray-100 rounded-lg">
      <p className="text-gray-500">Cargando mapa de Bilbao...</p>
    </div>
  ),
})

// Componente principal
export default function MapContent() {
  const [activeFilter, setActiveFilter] = useState<string | null>(null)

  const handleFilterClick = (filter: string) => {
    setActiveFilter(activeFilter === filter ? null : filter)
  }

  return (
    <main className="flex-1 flex flex-col h-full">
      <div className="flex-1 flex flex-col relative h-full">
        {/* Barra superior */}
        <div className="absolute top-0 left-0 right-0 z-10 bg-white bg-opacity-90 p-2">
          <div className="flex items-center justify-between">
            <button className="p-2">
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex-1 text-center text-sm font-medium">Mapa de Bilbao</div>
            <button className="p-2">
              <Search className="h-5 w-5" />
            </button>
          </div>

          {/* Pestañas de filtro */}
          <div className="flex justify-around mt-2">
            <button
              className={`text-xs font-medium py-1 px-2 ${activeFilter === "anuncios" ? "border-b-2 border-black" : ""}`}
              onClick={() => handleFilterClick("anuncios")}
            >
              Anuncios
            </button>
            <button
              className={`text-xs font-medium py-1 px-2 ${activeFilter === "profesionales" ? "border-b-2 border-black" : ""}`}
              onClick={() => handleFilterClick("profesionales")}
            >
              Profesionales
            </button>
            <button
              className={`text-xs font-medium py-1 px-2 ${activeFilter === "nuestros" ? "border-b-2 border-black" : ""}`}
              onClick={() => handleFilterClick("nuestros")}
            >
              Nuestros
            </button>
            <button
              className={`text-xs font-medium py-1 px-2 ${activeFilter === null ? "border-b-2 border-black" : ""}`}
              onClick={() => setActiveFilter(null)}
            >
              Mapa
            </button>
          </div>
        </div>

        {/* Mapa a pantalla completa */}
        <div className="flex-1 h-full pt-20">
          <BilbaoMap />
        </div>
      </div>
    </main>
  )
}
