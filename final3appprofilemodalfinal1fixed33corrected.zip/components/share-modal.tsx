"use client"

import { useState } from "react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Copy, Share2, MessageSquare, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

interface ShareModalProps {
  isOpen: boolean
  onClose: () => void
  title?: string
  url?: string
}

const ShareModal = ({
  isOpen,
  onClose,
  title = "Compartir este perfil",
  url = "https://quickia.app/profile/123",
}: ShareModalProps) => {
  const { toast } = useToast()
  const [copied, setCopied] = useState(false)

  const handleCopyLink = () => {
    navigator.clipboard.writeText(url)
    setCopied(true)
    toast({
      title: "Enlace copiado",
      description: "El enlace se ha copiado al portapapeles",
    })
    setTimeout(() => setCopied(false), 2000)
  }

  const shareOptions = [
    {
      name: "WhatsApp",
      icon: <MessageSquare className="h-5 w-5 text-green-600" />,
      action: () => {
        window.open(`https://wa.me/?text=${encodeURIComponent(url)}`, "_blank")
        onClose()
      },
    },
    {
      name: "Email",
      icon: <Mail className="h-5 w-5 text-blue-600" />,
      action: () => {
        window.open(
          `mailto:?subject=${encodeURIComponent("Mira este perfil en Quickia")}&body=${encodeURIComponent(url)}`,
          "_blank",
        )
        onClose()
      },
    },
  ]

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogContent className="bg-white p-4 rounded-lg max-w-md mx-auto max-h-[90vh] overflow-hidden">
        <AlertDialogHeader className="pb-2">
          <AlertDialogTitle className="text-lg font-semibold">{title}</AlertDialogTitle>
          <AlertDialogDescription className="text-gray-500 text-sm">
            Comparte este perfil con amigos o guárdalo para más tarde.
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="flex items-center space-x-2 my-3 p-2 border rounded-lg bg-gray-50">
          <div className="flex-1 truncate text-sm">{url}</div>
          <Button variant="outline" size="sm" onClick={handleCopyLink} className="flex items-center gap-1">
            <Copy className="h-4 w-4" />
            {copied ? "Copiado" : "Copiar"}
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3 my-4">
          {shareOptions.map((option) => (
            <button
              key={option.name}
              onClick={option.action}
              className="flex items-center justify-center gap-2 p-3 border rounded-lg hover:bg-gray-50 transition"
            >
              {option.icon}
              <span>{option.name}</span>
            </button>
          ))}
        </div>

        <AlertDialogFooter>
          <AlertDialogCancel className="w-full sm:w-auto">Cancelar</AlertDialogCancel>
          <AlertDialogAction
            className="w-full sm:w-auto bg-black text-white hover:bg-gray-800 flex items-center gap-2"
            onClick={onClose}
          >
            <Share2 className="h-4 w-4" />
            Compartir
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default ShareModal
