"use client"

import { useState } from "react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

interface ReportDialogProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (reason: string, details: string) => void
}

export const ReportDialog = ({ isOpen, onClose, onSubmit }: ReportDialogProps) => {
  const [reason, setReason] = useState("")
  const [details, setDetails] = useState("")

  const handleSubmit = () => {
    onSubmit(reason, details)
    onClose()
  }

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      {/* Ajustar el tamaño y comportamiento del diálogo de reporte */}
      <AlertDialogContent className="bg-white p-4 rounded-lg max-w-md mx-auto max-h-[90vh] overflow-auto">
        <AlertDialogHeader className="pb-2">
          <AlertDialogTitle className="text-lg font-semibold">Reportar problema</AlertDialogTitle>
          <AlertDialogDescription className="text-gray-500 text-sm">
            Ayúdanos a entender qué ha ocurrido para poder tomar medidas.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="space-y-3 my-3">
          <RadioGroup value={reason} onValueChange={setReason}>
            <div className="flex items-start space-x-2">
              <RadioGroupItem value="inappropriate" id="inappropriate" />
              <Label htmlFor="inappropriate" className="font-normal">
                Contenido inapropiado
              </Label>
            </div>
            <div className="flex items-start space-x-2">
              <RadioGroupItem value="scam" id="scam" />
              <Label htmlFor="scam" className="font-normal">
                Intento de estafa
              </Label>
            </div>
            <div className="flex items-start space-x-2">
              <RadioGroupItem value="harassment" id="harassment" />
              <Label htmlFor="harassment" className="font-normal">
                Acoso o comportamiento inadecuado
              </Label>
            </div>
            <div className="flex items-start space-x-2">
              <RadioGroupItem value="other" id="other" />
              <Label htmlFor="other" className="font-normal">
                Otro motivo
              </Label>
            </div>
          </RadioGroup>
          <div className="space-y-2">
            <Label htmlFor="details">Detalles adicionales (opcional)</Label>
            <Textarea
              id="details"
              placeholder="Describe el problema con más detalle..."
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              className="min-h-[100px]"
            />
          </div>
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel className="w-full sm:w-auto border border-gray-300 text-gray-700">
            Cancelar
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleSubmit}
            disabled={!reason}
            className={`w-full sm:w-auto ${
              !reason ? "bg-gray-300 cursor-not-allowed" : "bg-black hover:bg-gray-800"
            } text-white`}
          >
            Enviar reporte
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
