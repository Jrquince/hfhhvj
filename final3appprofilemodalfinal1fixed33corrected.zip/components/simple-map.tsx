"use client"

import { useEffect, useState } from "react"
import mapboxgl from "mapbox-gl"

// Datos de servicios
const servicesData = [
  {
    id: 1,
    name: "Juan Fontanero",
    description: "Fontanero profesional con 10 años de experiencia",
    price: 25,
    rating: 4.8,
    reviews: 120,
    location: "Centro de Bilbao",
    category: "fontanería",
    userId: 12,
    phone: "+34600123456",
    lat: 43.263,
    lng: -2.935,
    type: "profesionales",
    tags: ["urgencias", "ofertas"],
  },
  {
    id: 2,
    name: "María Electricista",
    description: "Instalaciones y reparaciones eléctricas",
    price: 30,
    rating: 4.9,
    reviews: 85,
    location: "Abando, Bilbao",
    category: "electricidad",
    userId: 11,
    phone: "+34600789012",
    lat: 43.268,
    lng: -2.938,
    type: "profesionales",
    tags: [],
  },
  {
    id: 3,
    name: "Carlos Pintor",
    description: "Pintura de interiores y exteriores",
    price: 20,
    rating: 4.5,
    reviews: 65,
    location: "Deusto, Bilbao",
    category: "pintura",
    userId: 13,
    phone: "+34600345678",
    lat: 43.258,
    lng: -2.925,
    type: "particulares",
    tags: ["ofertas"],
  },
  {
    id: 4,
    name: "Ana Limpieza",
    description: "Limpieza de hogares y oficinas",
    price: 15,
    rating: 4.7,
    reviews: 95,
    location: "Indautxu, Bilbao",
    category: "limpieza",
    userId: 15,
    phone: "+34600901234",
    lat: 43.265,
    lng: -2.94,
    type: "particulares",
    tags: [],
  },
  {
    id: 5,
    name: "Pedro Profesor",
    description: "Clases particulares de matemáticas y física",
    price: 18,
    rating: 4.6,
    reviews: 50,
    location: "Santutxu, Bilbao",
    category: "clases",
    userId: 14,
    phone: "+34600567890",
    lat: 43.261,
    lng: -2.928,
    type: "particulares",
    tags: ["anuncios"],
  },
  {
    id: 6,
    name: "Lucía Jardinera",
    description: "Diseño y mantenimiento de jardines",
    price: 22,
    rating: 4.4,
    reviews: 40,
    location: "Basurto, Bilbao",
    category: "jardinería",
    userId: 17,
    phone: "+34600234567",
    lat: 43.27,
    lng: -2.932,
    type: "profesionales",
    tags: ["ofertas"],
  },
  {
    id: 7,
    name: "Miguel Informático",
    description: "Reparación de ordenadores y redes",
    price: 28,
    rating: 4.9,
    reviews: 110,
    location: "Casco Viejo, Bilbao",
    category: "informática",
    userId: 16,
    phone: "+34600890123",
    lat: 43.259,
    lng: -2.923,
    type: "profesionales",
    tags: ["urgencias"],
  },
  {
    id: 8,
    name: "Sofía Mudanzas",
    description: "Servicio de mudanzas y transporte",
    price: 35,
    rating: 4.7,
    reviews: 75,
    location: "Rekalde, Bilbao",
    category: "mudanzas",
    userId: 10,
    phone: "+34600456789",
    lat: 43.255,
    lng: -2.945,
    type: "profesionales",
    tags: ["anuncios"],
  },
  {
    id: 9,
    name: "David Cuidador",
    description: "Cuidado de personas mayores y dependientes",
    price: 16,
    rating: 4.8,
    reviews: 60,
    location: "Zorroza, Bilbao",
    category: "cuidados",
    userId: 12,
    phone: "+34600012345",
    lat: 43.275,
    lng: -2.95,
    type: "particulares",
    tags: [],
  },
  {
    id: 10,
    name: "Elena Reparadora",
    description: "Reparaciones del hogar y bricolaje",
    price: 24,
    rating: 4.6,
    reviews: 85,
    location: "Miribilla, Bilbao",
    category: "reparaciones",
    userId: 11,
    phone: "+34600678901",
    lat: 43.252,
    lng: -2.93,
    type: "profesionales",
    tags: ["urgencias", "ofertas"],
  },
  {
    id: 11,
    name: "Roberto Carpintero",
    description: "Carpintero con experiencia en reparaciones y construcción",
    price: 32,
    rating: 4.7,
    reviews: 70,
    location: "Getaria, Bilbao",
    category: "carpintería",
    userId: 18,
    phone: "+34600112233",
    lat: 43.26,
    lng: -2.94,
    type: "profesionales",
    tags: ["ofertas"],
  },
]

// Función para obtener la imagen de perfil del mapa
const getMapAvatar = (userId: number) => {
  // Implementación de la función aquí
}

// Componente SimpleMap
const SimpleMap = () => {
  const [map, setMap] = useState(null)
  const [markers, setMarkers] = useState([])

  useEffect(() => {
    const initMap = async () => {
      const mapboxMap = new mapboxgl.Map({
        container: "map",
        style: "mapbox://styles/mapbox/streets-v11",
        center: [-2.935, 43.263],
        zoom: 12,
      })

      setMap(mapboxMap)

      const newMarkers = servicesData.map((service) => {
        const el = document.createElement("div")
        el.className = "marker"
        el.style.backgroundImage = `url(${getMapAvatar(service.userId)})`
        el.style.width = "30px"
        el.style.height = "30px"
        el.style.backgroundSize = "contain"
        el.style.backgroundRepeat = "no-repeat"

        return new mapboxgl.Marker(el).setLngLat([service.lng, service.lat]).addTo(mapboxMap)
      })

      setMarkers(newMarkers)
    }

    initMap()
  }, [])

  return (
    <div>
      <div id="map" style={{ width: "100%", height: "500px" }} />
      {/* Resto del código aquí */}
    </div>
  )
}

export default SimpleMap
