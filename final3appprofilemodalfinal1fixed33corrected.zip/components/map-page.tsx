"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import dynamic from "next/dynamic"
import { BottomNavigation } from "@/components/bottom-navigation"
import { AirbnbStyleSearchBar } from "@/components/airbnb-style-search-bar"
import { MapFilters } from "@/components/map-filters"
import { servicesData } from "@/lib/service-data"
import { QuickIAModal, type GeneratedContent } from "@/components/quickia-modal"
import { useToast } from "@/hooks/use-toast"
import { ChevronUp, X, Star, MapPin, Check, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

// Importar el componente de mapa de forma dinámica para evitar problemas de SSR
const MinimalistMap = dynamic(() => import("@/components/minimalist-map"), {
  ssr: false,
  loading: () => (
    <div className="flex h-screen w-full items-center justify-center bg-gray-100">
      <div className="h-8 w-8 animate-spin rounded-full border-4 border-gray-300 border-t-[#FF5A5F]"></div>
    </div>
  ),
})

const ProfileCard = dynamic(() => import("@/components/profile-card"), { ssr: false })

// Imágenes estáticas de personas (URLs confiables)
const profileImages = [
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces",
]

export default function MapPage() {
  const router = useRouter()
  const [activeFilter, setActiveFilter] = useState("todos")
  const [filteredServices, setFilteredServices] = useState([])
  const [isQuickIAOpen, setIsQuickIAOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [showProfiles, setShowProfiles] = useState(false)
  const [selectedService, setSelectedService] = useState<any | null>(null)
  const profilesRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()

  // Preparar los servicios con imágenes al inicio
  useEffect(() => {
    // Asegurarse de que todos los servicios tengan imágenes
    const servicesWithImages = servicesData.map((service, index) => ({
      ...service,
      image: profileImages[index % profileImages.length],
      verified: service.verified !== undefined ? service.verified : Math.random() > 0.7,
    }))

    if (activeFilter === "todos") {
      setFilteredServices(servicesWithImages)
    } else {
      setFilteredServices(servicesWithImages.filter((service) => service.type === activeFilter))
    }
  }, [activeFilter])

  // Manejar clic en marcador
  const handleMarkerClick = (service: any) => {
    // Asegurarse de que el servicio tenga una imagen
    const serviceWithImage = {
      ...service,
      image: service.image || profileImages[service.id % profileImages.length],
      verified: service.verified !== undefined ? service.verified : Math.random() > 0.7,
    }

    setSelectedService(serviceWithImage)
  }

  // Manejar búsqueda
  const handleSearch = (query: string) => {
    setSearchQuery(query)
    toast({
      title: "Búsqueda realizada",
      description: `Buscando: ${query}`,
      duration: 2000,
    })
  }

  // Manejar QuickIA
  const handleQuickIASubmit = (content: GeneratedContent) => {
    toast({
      title: "Sugerencia de QuickIA",
      description: content.title,
      duration: 3000,
    })

    // Filtrar servicios basados en la sugerencia de QuickIA
    setSearchQuery(content.title)
  }

  // Manejar contacto con servicio
  const handleContactService = (serviceId: number) => {
    router.push(`/post-detail/${serviceId}`)
    setSelectedService(null)
  }

  // Manejar toggle de perfiles
  const handleToggleProfiles = () => {
    setShowProfiles(!showProfiles)

    // Scroll a los perfiles si se están mostrando
    if (!showProfiles && profilesRef.current) {
      setTimeout(() => {
        profilesRef.current?.scrollIntoView({ behavior: "smooth" })
      }, 100)
    }
  }

  // Función para enviar mensajes (será implementada cuando se necesite)
  const handleSendMessage = (message: string, recipientId: number) => {
    toast({
      title: "Mensaje enviado",
      description: `Mensaje "${message}" enviado al usuario #${recipientId}`,
      duration: 3000,
    })
    // Aquí iría la lógica para enviar el mensaje
  }

  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Mapa a pantalla completa */}
      <div className="absolute inset-0">
        <MinimalistMap
          activeFilter={activeFilter}
          onMarkerClick={handleMarkerClick}
          services={filteredServices}
          center={[43.263, -2.935]} // Coordenadas de Bilbao
          zoom={14}
        />
      </div>

      {/* Barra de búsqueda estilo minimalista */}
      <div className="absolute left-0 right-0 top-0 z-10 px-4 pt-4">
        <AirbnbStyleSearchBar onSearch={handleSearch} onQuickIAClick={() => setIsQuickIAOpen(true)} />
      </div>

      {/* Filtros */}
      <div className="absolute left-0 right-0 top-16 z-10 px-4">
        <MapFilters onFilterChange={setActiveFilter} />
      </div>

      {/* Botón para mostrar perfiles */}
      <div className="absolute bottom-20 left-1/2 z-10 -translate-x-1/2 transform">
        <Button
          onClick={handleToggleProfiles}
          className="flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-md"
        >
          <span className="text-sm font-medium">Perfiles cercanos</span>
          <ChevronUp className={`h-4 w-4 transition-transform ${showProfiles ? "rotate-180" : ""}`} />
        </Button>
      </div>

      {/* Panel de perfiles deslizable */}
      <div
        className={`absolute bottom-0 left-0 right-0 z-10 transition-transform duration-300 ${
          showProfiles ? "translate-y-0" : "translate-y-full"
        }`}
        ref={profilesRef}
      >
        <div className="max-h-60 overflow-y-auto rounded-t-xl bg-white p-4 shadow-lg">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-lg font-semibold">Perfiles cercanos</h3>
            <button
              onClick={() => setShowProfiles(false)}
              className="rounded-full p-1 text-gray-500 hover:bg-gray-100"
              aria-label="Cerrar perfiles"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {filteredServices.map((service) => (
              <ProfileCard key={service.id} service={service} onClick={() => handleContactService(service.id)} />
            ))}
          </div>
        </div>
      </div>

      {/* Modal personalizado centrado en la pantalla */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
          <div className="relative w-full max-w-[320px] overflow-hidden rounded-xl border border-gray-100 bg-white shadow-lg">
            {/* Botón X para cerrar como una pestaña flotante */}
            <div className="absolute -right-1 -top-1 z-10">
              <button
                onClick={() => setSelectedService(null)}
                className="flex h-7 w-7 items-center justify-center rounded-full bg-white shadow-md hover:bg-gray-100"
                aria-label="Cerrar"
              >
                <X className="h-4 w-4 text-gray-600" />
              </button>
            </div>

            {/* Contenido minimalista con padding superior adicional */}
            <div className="p-4 pt-5">
              <div className="flex items-start gap-4">
                {/* Avatar e imagen */}
                <div className="relative">
                  <div className="h-16 w-16 overflow-hidden rounded-full border border-gray-100 bg-white">
                    <img
                      src={selectedService.image || "/placeholder.svg"}
                      alt={selectedService.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  {selectedService.verified && (
                    <div className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-blue-500 flex items-center justify-center border-2 border-white">
                      <Check className="h-3 w-3 text-white" />
                    </div>
                  )}
                </div>

                {/* Información principal */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <h3 className="text-base font-semibold">{selectedService.name}</h3>
                    <Badge variant="outline" className="bg-gray-50 ml-2">
                      {selectedService.category}
                    </Badge>
                  </div>

                  <div className="flex flex-wrap items-center text-xs text-gray-500 mb-1">
                    <div className="mr-2 flex items-center">
                      <Star className="mr-1 h-3 w-3 fill-amber-400 text-amber-400" />
                      <span className="font-medium">{selectedService.rating}</span>
                      <span className="ml-1">({selectedService.reviews || 0})</span>
                    </div>

                    <div className="flex items-center">
                      <MapPin className="mr-1 h-3 w-3 text-gray-400" />
                      <span>Bilbao</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Descripción */}
              <p className="my-3 text-sm text-gray-700">{selectedService.description}</p>

              {/* Precio */}
              <div className="mb-4 flex items-center justify-between rounded-lg bg-gray-50 p-2">
                <span className="text-xs font-medium text-gray-700">Precio por hora</span>
                <span className="text-base font-bold">{selectedService.price}€</span>
              </div>

              {/* Botones de acción */}
              <div className="flex justify-end space-x-2">
                <Button
                  className="rounded-full bg-black text-white hover:bg-black/90"
                  size="sm"
                  onClick={() => handleContactService(selectedService.id)}
                >
                  <MessageSquare className="h-3.5 w-3.5 mr-1.5" />
                  Contactar
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navegación inferior */}
      <div className="absolute bottom-0 left-0 right-0 z-10">
        <BottomNavigation activeItem="search" />
      </div>

      {/* Modal de QuickIA */}
      <QuickIAModal open={isQuickIAOpen} onOpenChange={setIsQuickIAOpen} onSubmit={handleQuickIASubmit} mode="map" />
    </div>
  )
}

// Exportar la función handleSendMessage para que esté disponible para otros componentes
export { MapPage }
