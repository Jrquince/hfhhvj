"use client"

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Trophy, Star, Award, Gift } from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface GamificationModalProps {
  isOpen: boolean
  onClose: () => void
  level?: number
  points?: number
  nextLevelPoints?: number
}

export const GamificationModal = ({
  isOpen,
  onClose,
  level = 3,
  points = 275,
  nextLevelPoints = 500,
}: GamificationModalProps) => {
  const progress = Math.round((points / nextLevelPoints) * 100)

  const rewards = [
    {
      name: "Descuento 10%",
      description: "En tu próximo servicio",
      icon: <Gift className="h-5 w-5 text-purple-500" />,
      unlocked: true,
    },
    {
      name: "Badge Experto",
      description: "Desbloquea un badge especial",
      icon: <Award className="h-5 w-5 text-blue-500" />,
      unlocked: true,
    },
    {
      name: "Prioridad en búsquedas",
      description: "Aparece primero en los resultados",
      icon: <Star className="h-5 w-5 text-amber-500" />,
      unlocked: false,
    },
    {
      name: "Verificación Premium",
      description: "Insignia de verificación especial",
      icon: <Trophy className="h-5 w-5 text-green-500" />,
      unlocked: false,
    },
  ]

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogContent className="bg-white p-4 rounded-lg max-w-md mx-auto max-h-[90vh] overflow-auto">
        <AlertDialogHeader className="pb-2">
          <AlertDialogTitle className="text-lg font-semibold text-center">Tu nivel y recompensas</AlertDialogTitle>
          <AlertDialogDescription className="text-center text-gray-500 text-sm">
            Sigue participando para desbloquear más beneficios
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4 my-3">
          {/* Nivel actual */}
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-amber-100 mb-2">
              <Trophy className="h-8 w-8 text-amber-600" />
            </div>
            <h3 className="text-lg font-semibold">Nivel {level}</h3>
            <p className="text-sm text-gray-500">Colaborador Activo</p>
          </div>

          {/* Progreso */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>{points} puntos</span>
              <span>{nextLevelPoints} puntos</span>
            </div>
            <Progress value={progress} className="h-2" />
            <p className="text-xs text-center text-gray-500">
              {nextLevelPoints - points} puntos para el nivel {level + 1}
            </p>
          </div>

          {/* Recompensas */}
          <div className="space-y-2">
            <h4 className="font-medium">Recompensas</h4>
            <div className="grid grid-cols-2 gap-2">
              {rewards.map((reward, index) => (
                <div
                  key={index}
                  className={`p-3 border rounded-lg ${
                    reward.unlocked ? "border-green-200 bg-green-50" : "border-gray-200 bg-gray-50 opacity-70"
                  }`}
                >
                  <div className="flex items-start">
                    <div className="mr-2">{reward.icon}</div>
                    <div>
                      <p className="font-medium text-sm">{reward.name}</p>
                      <p className="text-xs text-gray-500">{reward.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <AlertDialogFooter>
          <AlertDialogAction onClick={onClose} className="w-full bg-black hover:bg-gray-800 text-white">
            Continuar
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
