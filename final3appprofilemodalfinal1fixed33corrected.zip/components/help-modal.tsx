"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { HelpCircle, MessageSquare, Phone, Mail, X } from "lucide-react"

interface HelpModalProps {
  isOpen: boolean
  onClose: () => void
}

export const HelpModal = ({ isOpen, onClose }: HelpModalProps) => {
  const helpOptions = [
    {
      title: "Centro de ayuda",
      description: "Encuentra respuestas a preguntas frecuentes",
      icon: <HelpCircle className="h-5 w-5 text-blue-500" />,
      action: () => {
        window.open("/configuracion/ayuda", "_self")
        onClose()
      },
    },
    {
      title: "Chat con soporte",
      description: "Habla con un agente de soporte",
      icon: <MessageSquare className="h-5 w-5 text-green-500" />,
      action: () => {
        // Implementar lógica para abrir chat con soporte
        onClose()
      },
    },
    {
      title: "Llamar a soporte",
      description: "Lun-Vie: 9:00-18:00",
      icon: <Phone className="h-5 w-5 text-purple-500" />,
      action: () => {
        window.open("tel:+34900123456", "_blank")
        onClose()
      },
    },
    {
      title: "Enviar email",
      description: "soporte@quickia.app",
      icon: <Mail className="h-5 w-5 text-red-500" />,
      action: () => {
        window.open("mailto:soporte@quickia.app", "_blank")
        onClose()
      },
    },
  ]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white p-4 rounded-lg w-[90%] sm:w-[80%] md:w-[70%] lg:w-[50%] relative max-h-[85vh] overflow-hidden">
        <button
          onClick={() => onClose()}
          className="absolute right-3 top-3 p-1 rounded-full hover:bg-gray-100 transition-colors"
          aria-label="Cerrar"
        >
          <X className="h-4 w-4 text-gray-500" />
        </button>

        <DialogHeader className="pb-2">
          <DialogTitle className="text-lg font-semibold">¿Necesitas ayuda?</DialogTitle>
          <DialogDescription className="text-gray-500 text-sm">
            Selecciona una opción para recibir asistencia
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2.5 my-3 overflow-y-auto max-h-[50vh]">
          {helpOptions.map((option) => (
            <button
              key={option.title}
              onClick={option.action}
              className="w-full flex items-start p-3 border rounded-lg hover:bg-gray-50 transition text-left"
            >
              <div className="mr-3 mt-0.5">{option.icon}</div>
              <div>
                <div className="font-medium">{option.title}</div>
                <div className="text-sm text-gray-500">{option.description}</div>
              </div>
            </button>
          ))}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="w-full">
            Cerrar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
