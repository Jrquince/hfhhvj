"use client"

import { useEffect, useState, useRef } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { Home, GraduationCap, PenToolIcon as Tool, Scissors, Book, Heart, Palette, Briefcase } from "lucide-react"

// Definir el centro del mapa en Bilbao
const BILBAO_CENTER = [43.263, -2.935]

// Datos de ejemplo para los servicios
const services = [
  {
    id: 1,
    position: [43.263, -2.935],
    name: "Ana Jiménez",
    service: "Fontanero profesional",
    rating: 4.8,
    price: "25€/h",
    location: "Bilbao, Casco Viejo",
    description: "Reparaciones e instalaciones. Disponible fines de semana.",
    image: "/images/avatars/avatar1.jpeg",
    icon: "tool",
  },
  {
    id: 2,
    position: [43.258, -2.925],
    name: "Ana Garde",
    service: "Electricista certificado",
    rating: 4.6,
    price: "30€/h",
    location: "Bilbao, Abando",
    description: "Instalaciones eléctricas y reparaciones. Respuesta rápida.",
    image: "/images/avatars/avatar2.jpeg",
    icon: "home",
  },
  {
    id: 3,
    position: [43.268, -2.938],
    name: "Miguel R.",
    service: "Pintor profesional",
    rating: 4.5,
    price: "22€/h",
    location: "Bilbao, Indautxu",
    description: "Pintura de interiores y exteriores. Acabados de calidad.",
    image: "/images/avatars/avatar3.jpeg",
    icon: "palette",
  },
  {
    id: 4,
    position: [43.26, -2.93],
    name: "Ana S.",
    service: "Carpintero disponible",
    rating: 4.9,
    price: "28€/h",
    location: "Bilbao, Deusto",
    description: "Trabajos de carpintería a medida. Calidad garantizada.",
    image: "/images/avatars/avatar4.jpeg",
    icon: "tool",
  },
  {
    id: 5,
    position: [43.265, -2.94],
    name: "Elena M.",
    service: "Limpieza de hogar",
    rating: 4.7,
    price: "15€/h",
    location: "Bilbao, San Francisco",
    description: "Servicio de limpieza profesional para hogares y oficinas.",
    image: "/images/avatars/avatar5.jpeg",
    icon: "home",
  },
  {
    id: 6,
    position: [43.271, -2.942],
    name: "Pablo R.",
    service: "Jardinero experto",
    rating: 4.5,
    price: "22€/h",
    location: "Bilbao, Santutxu",
    description: "Diseño y mantenimiento de jardines. Poda y plantación.",
    image: "/images/avatars/avatar6.jpeg",
    icon: "tool",
  },
  {
    id: 7,
    position: [43.255, -2.932],
    name: "Lucía F.",
    service: "Profesor de piano",
    rating: 4.8,
    price: "25€/h",
    location: "Bilbao, Abando",
    description: "Clases de piano para todos los niveles. Método personalizado.",
    image: "/images/avatars/avatar7.jpeg",
    icon: "book",
  },
  {
    id: 8,
    position: [43.267, -2.927],
    name: "Diego Gómez",
    service: "Clases de inglés nativo",
    rating: 4.9,
    price: "18€/h",
    location: "Bilbao, Begoña",
    description: "Profesor nativo de inglés. Todos los niveles. Preparación exámenes oficiales.",
    image: "/images/avatars/avatar8.jpeg",
    icon: "education",
  },
]

// Componente para el mapa de Bilbao
export default function BilbaoMap() {
  const [selectedService, setSelectedService] = useState<number | null>(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const mapRef = useRef<HTMLDivElement>(null)
  const leafletMapRef = useRef<L.Map | null>(null)

  // Crear iconos personalizados para los marcadores
  useEffect(() => {
    // Verificar que estamos en el cliente y que el elemento del mapa existe
    if (typeof window !== "undefined" && mapRef.current && !leafletMapRef.current) {
      // Coordenadas de Bilbao
      const bilbaoCoordinates: [number, number] = [43.263, -2.935]

      // Inicializar el mapa
      const map = L.map(mapRef.current).setView(bilbaoCoordinates, 14)

      // Añadir la capa de OpenStreetMap
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(map)

      // Guardar la referencia del mapa
      leafletMapRef.current = map
      setMapLoaded(true)

      // Crear marcadores simplificados
      services.forEach((service) => {
        // Determinar el color según el tipo de servicio
        let color = "#4B5563" // Gris por defecto

        if (service.icon === "tool")
          color = "#F59E0B" // Ámbar
        else if (service.icon === "home")
          color = "#3B82F6" // Azul
        else if (service.icon === "palette")
          color = "#EC4899" // Rosa
        else if (service.icon === "book")
          color = "#10B981" // Verde
        else if (service.icon === "education") color = "#8B5CF6" // Púrpura

        // Crear icono personalizado
        const customIcon = L.divIcon({
          html: `
            <div style="
              background-color: ${color}; 
              width: 32px; 
              height: 32px; 
              border-radius: 50%; 
              display: flex; 
              align-items: center; 
              justify-content: center; 
              box-shadow: 0 2px 5px rgba(0,0,0,0.3); 
              border: 2px solid white;
              color: white;
              font-weight: bold;
              font-size: 16px;
              text-align: center;
            ">
              ${
                service.icon === "tool"
                  ? "🔧"
                  : service.icon === "home"
                    ? "🏠"
                    : service.icon === "palette"
                      ? "🎨"
                      : service.icon === "book"
                        ? "📚"
                        : service.icon === "education"
                          ? "🎓"
                          : "📌"
              }
            </div>
          `,
          className: "",
          iconSize: [32, 32],
          iconAnchor: [16, 16],
        })

        // Añadir marcador al mapa
        L.marker(service.position as [number, number], { icon: customIcon })
          .addTo(map)
          .on("click", () => {
            setSelectedService(service.id)
          })
      })
    }

    // Limpiar el mapa cuando el componente se desmonte
    return () => {
      if (leafletMapRef.current) {
        leafletMapRef.current.remove()
        leafletMapRef.current = null
      }
    }
  }, [])

  // Función para obtener el icono según el tipo de servicio
  const getIconForService = (iconType: string) => {
    // Determinar el SVG según el tipo de icono
    let iconSvg = ""

    switch (iconType) {
      case "tool":
        iconSvg =
          '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>'
        break
      case "scissors":
        iconSvg =
          '<circle cx="6" cy="6" r="3"></circle><circle cx="6" cy="18" r="3"></circle><line x1="20" y1="4" x2="8.12" y2="15.88"></line><line x1="14.47" y1="14.48" x2="20" y2="20"></line><line x1="8.12" y1="8.12" x2="12" y2="12"></line>'
        break
      case "book":
        iconSvg =
          '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>'
        break
      case "heart":
        iconSvg =
          '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>'
        break
      case "palette":
        iconSvg =
          '<circle cx="13.5" cy="6.5" r=".5"></circle><circle cx="17.5" cy="10.5" r=".5"></circle><circle cx="8.5" cy="7.5" r=".5"></circle><circle cx="6.5" cy="12.5" r=".5"></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path>'
        break
      case "briefcase":
        iconSvg =
          '<rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>'
        break
      case "education":
        iconSvg = '<path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path>'
        break
      case "home":
      default:
        iconSvg =
          '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>'
    }

    return L.divIcon({
      html: `
      <div style="position: relative; width: 40px; height: 40px;">
        <div style="
          position: absolute;
          top: 0;
          left: 0;
          background-color: var(--map-marker-bg, #4B5563); 
          width: 36px; 
          height: 36px; 
          border-radius: 10px;
          transform: rotate(45deg);
          box-shadow: 0 4px 8px rgba(0,0,0,0.3); 
          border: 2px solid white;
        "></div>
        <div style="
          position: absolute;
          top: 0;
          left: 0;
          width: 36px; 
          height: 36px; 
          display: flex; 
          align-items: center; 
          justify-content: center;
          z-index: 10;
        ">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            ${iconSvg}
          </svg>
        </div>
      </div>
    `,
      className: "",
      iconSize: [40, 40],
      iconAnchor: [20, 20],
    })
  }

  // Componente para la lista de servicios vertical
  const ServicesList = () => {
    return (
      <div className="absolute bottom-0 left-0 right-0 bg-white bg-opacity-95 rounded-t-xl shadow-lg z-10 max-h-[40vh] overflow-hidden">
        <div className="p-3 border-b sticky top-0 bg-white z-10">
          <h3 className="font-medium">Servicios en Bilbao</h3>
          <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mt-1"></div>
        </div>
        <div className="overflow-y-auto max-h-[calc(40vh-40px)]">
          {services.map((service) => (
            <div
              key={service.id}
              className={`p-3 border-b cursor-pointer ${service.id === selectedService ? "bg-yellow-100" : ""}`}
              onClick={() => setSelectedService(service.id)}
            >
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full overflow-hidden flex-shrink-0">
                  <img
                    src={service.image || "/placeholder.svg"}
                    alt={service.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">{service.name}</h3>
                    <div className="flex items-center justify-center w-7 h-7 rounded-full bg-gray-100 dark:bg-gray-800">
                      {service.icon === "tool" ? (
                        <Tool className="h-4 w-4 text-gray-700 dark:text-gray-300" />
                      ) : service.icon === "scissors" ? (
                        <Scissors className="h-4 w-4 text-gray-700 dark:text-gray-300" />
                      ) : service.icon === "book" ? (
                        <Book className="h-4 w-4 text-gray-700 dark:text-gray-300" />
                      ) : service.icon === "heart" ? (
                        <Heart className="h-4 w-4 text-gray-700 dark:text-gray-300" />
                      ) : service.icon === "palette" ? (
                        <Palette className="h-4 w-4 text-gray-700 dark:text-gray-300" />
                      ) : service.icon === "briefcase" ? (
                        <Briefcase className="h-4 w-4 text-gray-700 dark:text-gray-300" />
                      ) : service.icon === "education" ? (
                        <GraduationCap className="h-4 w-4 text-gray-700 dark:text-gray-300" />
                      ) : (
                        <Home className="h-4 w-4 text-gray-700 dark:text-gray-300" />
                      )}
                    </div>
                  </div>
                  <div className="flex items-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <span key={star} className="text-yellow-500">
                        ★
                      </span>
                    ))}
                    <span className="text-xs ml-1 text-gray-600">{service.rating}</span>
                  </div>
                  <p className="text-xs mt-1">{service.location}</p>
                  <p className="text-sm mt-1 line-clamp-2">{service.description}</p>
                  <p className="text-sm font-bold mt-1">{service.price}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (!mapLoaded) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-100 rounded-lg">
        <p className="text-gray-500">Cargando mapa de Bilbao...</p>
      </div>
    )
  }

  return (
    <div ref={mapRef} className="w-full h-full relative" style={{ height: "100%", minHeight: "500px" }}>
      <ServicesList />
    </div>
  )
}
