"use client"

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface FollowRequestPopupProps {
  isOpen: boolean
  onClose: () => void
  onAccept: () => void
  onDecline: () => void
  user: {
    name: string
    username: string
    avatar: string
  }
}

export const FollowRequestPopup = ({
  isOpen,
  onClose,
  onAccept,
  onDecline,
  user = {
    name: "Laura García",
    username: "@lauragarcia",
    avatar: "/placeholder.svg?height=40&width=40",
  },
}: FollowRequestPopupProps) => {
  const handleAccept = () => {
    onAccept()
    onClose()
  }

  const handleDecline = () => {
    onDecline()
    onClose()
  }

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      {/* Ajustar el tamaño y comportamiento del popup de solicitud de seguimiento */}
      <AlertDialogContent className="bg-white p-4 rounded-lg max-w-md mx-auto max-h-[90vh] overflow-hidden">
        <AlertDialogHeader className="pb-2">
          <AlertDialogTitle className="text-lg font-semibold">Solicitud de seguimiento</AlertDialogTitle>
          <AlertDialogDescription className="text-gray-500 text-sm">
            Esta persona quiere seguirte
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="flex items-center space-x-4 my-3 p-3 border rounded-lg">
          <Avatar className="h-12 w-12">
            <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
            <AvatarFallback>
              {user.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-medium">{user.name}</h3>
            <p className="text-sm text-gray-500">{user.username}</p>
          </div>
        </div>

        <AlertDialogFooter className="flex-col space-y-2 sm:space-y-0">
          <AlertDialogAction onClick={handleAccept} className="w-full bg-black hover:bg-gray-800 text-white">
            Aceptar
          </AlertDialogAction>
          <AlertDialogCancel onClick={handleDecline} className="w-full mt-2 sm:mt-0">
            Rechazar
          </AlertDialogCancel>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default FollowRequestPopup
