"use client"

import { useEffect, useRef } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { getAvatarByUserId } from "@/lib/avatar-utils"

// Iconos SVG para cada categoría con colores más vibrantes
const categoryIcons: Record<string, { svg: string; color: string }> = {
  fontanería: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M7 21h10"></path><rect x="2" y="3" width="20" height="14" rx="2"></rect><path d="M12 17v4"></path></svg>`,
    color: "#3B82F6", // Azul brillante
  },
  electricidad: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path></svg>`,
    color: "#FACC15", // Amarillo brillante
  },
  pintura: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22a4 4 0 0 1-4-4V6c0-1.1.9-2 2-2h4a2 2 0 0 1 2 2v12a4 4 0 0 1-4 4Z"></path><path d="M18 16a4 4 0 0 0-4-4H8"></path><path d="M2 6h12"></path><path d="M2 10h8"></path></svg>`,
    color: "#EC4899", // Rosa brillante
  },
  carpintería: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m18 2 4 4"></path><path d="m17 7 3-3"></path><path d="M19 9 8.7 19.3c-1 1-2.5 1-3.4 0l-.6-.6c-1-1-1-2.5 0-3.4L15 5"></path><path d="m9 11 4 4"></path><path d="m5 19-3 3"></path></svg>`,
    color: "#B45309", // Marrón brillante
  },
  limpieza: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`,
    color: "#06B6D4", // Cian brillante
  },
  jardinería: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 10a6 6 0 0 0-6-6 6 6 0 0 0 0 12h12a6 6 0 0 0 0-12 6 6 0 0 0-6 6"></path></svg>`,
    color: "#10B981", // Verde brillante
  },
  informática: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>`,
    color: "#6366F1", // Índigo brillante
  },
  clases: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>`,
    color: "#8B5CF6", // Púrpura brillante
  },
  mudanzas: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>`,
    color: "#F97316", // Naranja brillante
  },
  cuidados: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path></svg>`,
    color: "#EF4444", // Rojo brillante
  },
  reparaciones: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>`,
    color: "#4F46E5", // Índigo oscuro brillante
  },
  vivienda: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>`,
    color: "#0EA5E9", // Azul cielo brillante
  },
  compraventa: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><path d="M3 6h18"></path><path d="M16 10a4 4 0 0 1-8 0"></path></svg>`,
    color: "#F59E0B", // Ámbar brillante
  },
  eventos: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>`,
    color: "#D946EF", // Fucsia brillante
  },
  otros: {
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`,
    color: "#6B7280", // Gris brillante
  },
}

interface MinimalistMapProps {
  activeFilter?: string
  onMarkerClick: (service: any) => void
  services: any[]
  center?: [number, number]
  zoom?: number
}

export default function MinimalistMap({
  activeFilter = "todos",
  onMarkerClick,
  services,
  center = [43.263, -2.935], // Bilbao por defecto
  zoom = 14,
}: MinimalistMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<L.Map | null>(null)
  const markersRef = useRef<L.Marker[]>([])

  // Limpiar marcadores existentes
  const clearMarkers = () => {
    if (mapInstanceRef.current) {
      markersRef.current.forEach((marker) => {
        mapInstanceRef.current?.removeLayer(marker)
      })
      markersRef.current = []
    }
  }

  // Añadir marcadores al mapa
  const addMarkers = () => {
    if (!mapInstanceRef.current) return

    services.forEach((service, index) => {
      // Determinar la categoría
      const category = service.category?.toLowerCase() || "otros"

      // Obtener el icono adecuado para la categoría
      const iconInfo = categoryIcons[category] || categoryIcons.otros

      // Alternar colores (negro y amarillo anaranjado)
      const markerColor = index % 2 === 0 ? "#F59E0B" : "#000000"

      // Crear un marcador con un único elemento HTML
      const html = `
        <div class="marker-container" style="
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background-color: ${markerColor};
          border: 2px solid white;
          box-shadow: 0 2px 5px rgba(0,0,0,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
        ">
          ${iconInfo.svg}
        </div>
      `

      const customIcon = L.divIcon({
        html,
        className: "custom-marker-icon",
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      })

      // Asegurarse de que el servicio tenga una imagen
      const serviceWithImage = {
        ...service,
        image: service.image || getAvatarByUserId(service.id || index + 1),
      }

      // Crear y añadir el marcador al mapa
      const marker = L.marker([service.lat, service.lng], {
        icon: customIcon,
        interactive: true,
        bubblingMouseEvents: false,
      })
        .addTo(mapInstanceRef.current!)
        .on("click", () => {
          onMarkerClick(serviceWithImage)
        })

      markersRef.current.push(marker)
    })
  }

  // Efecto para inicializar el mapa
  useEffect(() => {
    if (typeof window !== "undefined" && mapContainerRef.current && !mapInstanceRef.current) {
      // Inicializar el mapa
      const map = L.map(mapContainerRef.current, {
        center,
        zoom,
        zoomControl: false,
        attributionControl: false,
      })

      // Añadir la capa de OpenStreetMap
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
      }).addTo(map)

      // Añadir controles de zoom en la esquina inferior derecha
      L.control
        .zoom({
          position: "bottomright",
        })
        .addTo(map)

      // Guardar la referencia del mapa
      mapInstanceRef.current = map

      // Añadir marcadores iniciales
      addMarkers()

      // Forzar una actualización del tamaño del mapa
      setTimeout(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize()
        }
      }, 100)
    }

    // Limpiar el mapa cuando el componente se desmonte
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  // Efecto para actualizar marcadores cuando cambia el filtro o los servicios
  useEffect(() => {
    clearMarkers()
    addMarkers()
  }, [activeFilter, services])

  return (
    <div className="relative w-full h-full">
      {/* Estilos globales para eliminar cualquier icono pequeño */}
      <style jsx global>{`
        /* Estilos para marcadores personalizados */
        .custom-marker-icon {
          background: transparent !important;
          border: none !important;
          contain: strict !important;
        }
        
        /* Eliminar cualquier elemento adicional */
        .leaflet-marker-icon > *:not(.marker-container),
        .leaflet-marker-icon > div:not(.marker-container) {
          display: none !important;
        }
        
        /* Asegurar que no haya elementos posicionados absolutamente */
        .leaflet-marker-icon * {
          position: static !important;
        }
        
        /* Forzar que solo haya un elemento por marcador */
        .leaflet-marker-icon {
          overflow: hidden !important;
        }
      `}</style>

      <div ref={mapContainerRef} className="w-full h-full" style={{ height: "100%", width: "100%" }} />
    </div>
  )
}
