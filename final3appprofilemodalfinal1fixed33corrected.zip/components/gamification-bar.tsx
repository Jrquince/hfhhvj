"use client"

import { useState } from "react"
import { Info, Star, Award, Trophy, ChevronUp, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface GamificationBarProps {
  current: number
  total: number
  message: string
  stars?: number
  nextLevel?: number
  badges?: number
}

export default function GamificationBar({
  current,
  total,
  message,
  stars = 4.8,
  nextLevel = 2,
  badges = 3,
}: GamificationBarProps) {
  const [expanded, setExpanded] = useState(false)
  const percentage = (current / total) * 100

  return (
    <div className="w-full px-4 py-2">
      <div className="flex items-center justify-between mb-1">
        <h3 className="text-sm font-semibold">AYUDAS REALIZADAS</h3>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                <Info className="h-4 w-4 text-gray-400" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">Completa ayudas para subir de nivel y desbloquear insignias</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <div className="relative h-8" onClick={() => setExpanded(!expanded)}>
        <div className="absolute inset-0 bg-gray-200 rounded-full"></div>
        <div
          className="absolute inset-y-0 left-0 bg-amber-400 rounded-full flex items-center justify-center cursor-pointer"
          style={{ width: `${percentage}%` }}
        >
          <span className="text-white font-medium text-sm">
            {current}/{total}
          </span>
        </div>

        {/* Marcadores de progreso */}
        <div className="absolute inset-0 flex items-center justify-between px-2">
          {[...Array(total)].map((_, i) => (
            <div key={i} className={`h-4 w-1 rounded-full ${i < current ? "bg-white opacity-50" : "bg-gray-300"}`} />
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between mt-1">
        <p className="text-sm">
          {current === total
            ? "¡Felicidades! Has completado todas las ayudas"
            : `${message} - ${total - current} más para completar`}
        </p>
        <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setExpanded(!expanded)}>
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>
      </div>

      {expanded && (
        <div className="mt-3 bg-gray-50 rounded-lg p-4 space-y-3 animate-in fade-in-50 duration-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Star className="h-5 w-5 text-yellow-500 fill-yellow-500 mr-2" />
              <span className="text-sm font-medium">Valoración media</span>
            </div>
            <div className="flex items-center">
              <span className="font-bold mr-1">{stars}</span>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`h-3 w-3 ${
                      star <= Math.floor(stars) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Award className="h-5 w-5 text-amber-500 mr-2" />
              <span className="text-sm font-medium">Insignias obtenidas</span>
            </div>
            <span className="font-bold">{badges}</span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Trophy className="h-5 w-5 text-green-500 mr-2" />
              <span className="text-sm font-medium">Siguiente nivel</span>
            </div>
            <span className="font-bold">En {nextLevel} ayudas</span>
          </div>

          <div className="bg-amber-100 rounded-lg p-3 mt-2">
            <p className="text-sm text-center text-amber-800">
              🎖️ ¡Completa {nextLevel} ayudas más para desbloquear la insignia de Profesional!
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
