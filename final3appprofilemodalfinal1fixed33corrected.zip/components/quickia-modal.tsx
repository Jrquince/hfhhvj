"use client"

import { useState, useRef, useEffect } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Mic, Send, ImageIcon, Paperclip, Sparkles, X } from "lucide-react"
import { Button } from "@/components/ui/button"

// Definir el tipo para el contenido generado
export interface GeneratedContent {
  title: string
  description?: string
  suggestedCategory?: string
}

// Definir el tipo para los mensajes
interface ChatMessage {
  id: string
  content: string
  sender: "user" | "bot"
  timestamp: Date
  generatedContent?: GeneratedContent | null
}

// Definir las props del componente
interface QuickIAModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit?: (content: GeneratedContent) => void
  mode?: "create" | "chat" | "map"
}

export const QuickIAModal = ({ open, onOpenChange, onSubmit, mode = "chat" }: QuickIAModalProps) => {
  const [inputMessage, setInputMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const chatContainerRef = useRef<HTMLDivElement>(null)

  // Inicializar el chat con un mensaje de bienvenida cuando se abre
  useEffect(() => {
    if (open && messages.length === 0) {
      const welcomeMessage = getWelcomeMessage()
      setMessages([
        {
          id: "welcome",
          content: welcomeMessage,
          sender: "bot",
          timestamp: new Date(),
        },
      ])
    }
  }, [open])

  // Función para hacer scroll al final de los mensajes
  const scrollToBottom = () => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight
    }
  }

  // Hacer scroll cuando cambian los mensajes
  useEffect(() => {
    if (open) {
      setTimeout(scrollToBottom, 100)
    }
  }, [messages, isLoading, open])

  // Generar respuesta automática basada en el mensaje del usuario
  const generateBotResponse = (userMessage: string): Promise<ChatMessage> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        // Palabras clave para diferentes tipos de respuestas
        const lowerCaseMessage = userMessage.toLowerCase()

        if (mode === "create") {
          // Respuesta para modo de creación de anuncios
          const content = {
            title: "Fontanero profesional para reparaciones urgentes",
            description:
              "Ofrezco servicios de fontanería para todo tipo de reparaciones urgentes. Disponibilidad inmediata, precios competitivos y trabajo garantizado. Más de 10 años de experiencia en el sector.",
            suggestedCategory: "Profesionales",
          }

          resolve({
            id: `bot-${Date.now()}`,
            content: "He generado un anuncio basado en tu solicitud. ¿Te gustaría utilizarlo?",
            sender: "bot",
            timestamp: new Date(),
            generatedContent: content,
          })
        } else if (mode === "map") {
          // Respuesta para modo de mapa
          if (lowerCaseMessage.includes("fontaner") || lowerCaseMessage.includes("plomer")) {
            const content = {
              title: "Fontaneros cerca de Bilbao",
              description: "He encontrado 5 fontaneros disponibles en tu zona con buenas valoraciones.",
              suggestedCategory: "Fontanería",
            }

            resolve({
              id: `bot-${Date.now()}`,
              content: "He encontrado varios profesionales que podrían ayudarte. ¿Quieres ver los resultados?",
              sender: "bot",
              timestamp: new Date(),
              generatedContent: content,
            })
          } else if (lowerCaseMessage.includes("electricista") || lowerCaseMessage.includes("electric")) {
            const content = {
              title: "Electricistas en tu zona",
              description: "He encontrado 3 electricistas disponibles cerca de ti con buenas valoraciones.",
              suggestedCategory: "Electricidad",
            }

            resolve({
              id: `bot-${Date.now()}`,
              content: "He encontrado varios electricistas en tu zona. ¿Quieres ver los resultados?",
              sender: "bot",
              timestamp: new Date(),
              generatedContent: content,
            })
          } else {
            resolve({
              id: `bot-${Date.now()}`,
              content:
                "¿Podrías darme más detalles sobre el tipo de servicio que estás buscando? Puedo ayudarte a encontrar profesionales cercanos.",
              sender: "bot",
              timestamp: new Date(),
            })
          }
        } else {
          // Respuestas para modo chat general
          if (
            lowerCaseMessage.includes("hola") ||
            lowerCaseMessage.includes("buenos días") ||
            lowerCaseMessage.includes("buenas")
          ) {
            resolve({
              id: `bot-${Date.now()}`,
              content: "¡Hola! ¿En qué puedo ayudarte hoy?",
              sender: "bot",
              timestamp: new Date(),
            })
          } else if (lowerCaseMessage.includes("gracias") || lowerCaseMessage.includes("thank")) {
            resolve({
              id: `bot-${Date.now()}`,
              content: "¡De nada! Estoy aquí para ayudarte. ¿Hay algo más en lo que pueda asistirte?",
              sender: "bot",
              timestamp: new Date(),
            })
          } else if (
            lowerCaseMessage.includes("servicio") ||
            lowerCaseMessage.includes("ayuda") ||
            lowerCaseMessage.includes("busco")
          ) {
            resolve({
              id: `bot-${Date.now()}`,
              content:
                "Puedo ayudarte a encontrar servicios profesionales. ¿Qué tipo de servicio estás buscando? Por ejemplo: fontanería, electricidad, limpieza, etc.",
              sender: "bot",
              timestamp: new Date(),
            })
          } else {
            resolve({
              id: `bot-${Date.now()}`,
              content: "Entiendo. ¿Podrías darme más detalles para poder ayudarte mejor?",
              sender: "bot",
              timestamp: new Date(),
            })
          }
        }
      }, 1500) // Simular retraso de respuesta
    })
  }

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = inputMessage
    setInputMessage("")

    // Añadir mensaje del usuario
    const newUserMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      content: userMessage,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, newUserMessage])
    setIsLoading(true)

    // Generar respuesta del bot
    const botResponse = await generateBotResponse(userMessage)
    setIsLoading(false)
    setMessages((prev) => [...prev, botResponse])

    // Si hay contenido generado y una función onSubmit, llamarla
    if (botResponse.generatedContent && onSubmit) {
      onSubmit(botResponse.generatedContent)
    }
  }

  const handleApplyContent = (content: GeneratedContent) => {
    if (content && onSubmit) {
      onSubmit(content)
      onOpenChange(false)
    }
  }

  // Determinar el título y la descripción según el modo
  const getModalTitle = () => {
    switch (mode) {
      case "create":
        return "QuickIA - Generador de anuncios"
      case "map":
        return "QuickIA - Soluciones al momento"
      default:
        return "QuickIA - Soluciones al momento"
    }
  }

  const getModalDescription = () => {
    switch (mode) {
      case "create":
        return "Describe lo que quieres anunciar y te ayudaré a crear un anuncio atractivo"
      case "map":
      default:
        return "Escribe con tus palabras lo que necesitas y quickia te buscará la mejor opción de usuarios y anuncios"
    }
  }

  const getWelcomeMessage = () => {
    switch (mode) {
      case "create":
        return "¡Hola! Soy QuickIA. Describe el anuncio que quieres crear y te ayudaré a generarlo."
      case "map":
        return "¡Hola! Soy QuickIA. Puedo ayudarte a encontrar servicios cercanos o lugares específicos en el mapa."
      default:
        return "¡Hola! Soy QuickIA, tu asistente virtual. ¿En qué puedo ayudarte?"
    }
  }

  const getInputPlaceholder = () => {
    switch (mode) {
      case "create":
        return "Describe tu anuncio..."
      case "map":
      default:
        return "Escribe con tus palabras lo que necesitas..."
    }
  }

  // Formatear hora para mostrar en mensajes
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  if (!open) return null

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
        onClick={(e) => {
          e.stopPropagation()
          onOpenChange(false)
        }}
      />

      {/* Modal - Ahora con ancho completo para eliminar bordes blancos */}
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-[900px] flex flex-col h-[85vh] max-h-[600px] overflow-hidden rounded-xl bg-white shadow-xl">
        {/* Encabezado */}
        <div className="bg-gradient-to-r from-purple-500 to-blue-500 px-4 py-3 flex items-center">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white mr-3">
            <Sparkles className="h-4 w-4" />
          </div>
          <div className="flex-1 pr-8">
            <h3 className="text-base font-medium text-white">{getModalTitle()}</h3>
            <p className="text-xs text-white/80">{getModalDescription()}</p>
          </div>
          {/* Botón X para cerrar */}
          <button
            onClick={(e) => {
              e.stopPropagation()
              onOpenChange(false)
            }}
            className="p-2 rounded-full hover:bg-white/20 transition-colors"
            aria-label="Cerrar"
          >
            <X className="h-5 w-5 text-white" />
          </button>
        </div>

        {/* Área de chat */}
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto bg-gray-50 px-4 py-3">
          <div className="space-y-3">
            {/* Mensajes */}
            {messages.map((msg) => (
              <div key={msg.id} className={`flex items-end ${msg.sender === "user" ? "justify-end" : ""}`}>
                {msg.sender === "bot" && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center text-white mr-2 flex-shrink-0 mb-1">
                    <Sparkles className="h-4 w-4" />
                  </div>
                )}
                <div
                  className={`py-2.5 px-3.5 max-w-[75%] shadow-sm relative ${
                    msg.sender === "user"
                      ? "bg-black rounded-t-lg rounded-bl-lg text-white"
                      : "bg-white rounded-t-lg rounded-br-lg"
                  }`}
                >
                  <p className="text-sm mb-4 break-words">{msg.content}</p>

                  {/* Contenido generado */}
                  {msg.generatedContent && (
                    <div className="mt-2 pt-2 border-t border-gray-200">
                      <p className="text-xs font-medium text-gray-500">
                        {mode === "create" ? "Anuncio generado:" : "Sugerencia:"}
                      </p>
                      <p className="text-sm font-medium mt-1">{msg.generatedContent.title}</p>
                      {msg.generatedContent.description && (
                        <p className="text-xs mt-1 text-gray-600">{msg.generatedContent.description}</p>
                      )}
                      {msg.generatedContent.suggestedCategory && (
                        <p className="text-xs mt-1 text-purple-600">
                          Categoría: {msg.generatedContent.suggestedCategory}
                        </p>
                      )}
                      <Button
                        size="sm"
                        className="mt-2 w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white text-xs py-1.5 h-auto"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleApplyContent(msg.generatedContent!)
                        }}
                      >
                        {mode === "create" ? "Aplicar al formulario" : "Ver resultados"}
                      </Button>
                    </div>
                  )}

                  {/* Timestamp */}
                  <span
                    className={`text-[10px] ${msg.sender === "user" ? "text-gray-300" : "text-gray-400"} absolute bottom-1 ${msg.sender === "user" ? "left-2" : "right-2"}`}
                  >
                    {formatTime(msg.timestamp)}
                  </span>
                </div>
              </div>
            ))}

            {/* Indicador de carga */}
            {isLoading && (
              <div className="flex items-end">
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center text-white mr-2 flex-shrink-0 mb-1">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div className="bg-white rounded-t-lg rounded-br-lg py-2.5 px-3.5 shadow-sm">
                  <div className="flex space-x-1.5">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Área de entrada de texto */}
        <div className="bg-white px-4 py-3 border-t border-gray-100">
          <div className="flex items-center bg-gray-50 rounded-full px-3 py-1">
            <div className="flex space-x-1 mr-2">
              <button className="p-1 rounded-full hover:bg-gray-100">
                <Paperclip className="h-4 w-4 text-gray-500" />
              </button>
              <button className="p-1 rounded-full hover:bg-gray-100">
                <ImageIcon className="h-4 w-4 text-gray-500" />
              </button>
              <button className="p-1 rounded-full hover:bg-gray-100">
                <Mic className="h-4 w-4 text-gray-500" />
              </button>
            </div>
            <Textarea
              placeholder={getInputPlaceholder()}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="min-h-[40px] max-h-[80px] resize-none border-0 bg-transparent focus:ring-0 text-sm py-1.5 flex-1"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSendMessage()
                }
              }}
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || isLoading}
              className={`ml-2 p-2 rounded-full ${
                inputMessage.trim() && !isLoading
                  ? "bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                  : "bg-gray-200"
              }`}
            >
              <Send className={`h-4 w-4 ${inputMessage.trim() && !isLoading ? "text-white" : "text-gray-400"}`} />
            </button>
          </div>
        </div>
      </div>
    </>
  )
}
