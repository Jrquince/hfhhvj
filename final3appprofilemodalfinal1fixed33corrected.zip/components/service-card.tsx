"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import { Star, X, MessageSquare } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface Service {
  id: number
  name: string
  description: string
  category: string
  price: number | string
  rating: number
  reviews?: number
  userId?: number | string
}

interface ServiceCardProps {
  service: Service
  onClose: () => void
  onClick: () => void
}

export function ServiceCard({ service, onClose, onClick }: ServiceCardProps) {
  // Función para obtener el avatar basado en el ID de usuario
  const getAvatarUrl = (userId: number | string | undefined) => {
    if (!userId) return "/placeholder.svg?height=40&width=40"
    return `/placeholder.svg?height=40&width=40&text=${userId}`
  }

  // Función para obtener el emoji según la categoría
  const getCategoryEmoji = (category: string) => {
    const emojis: Record<string, string> = {
      fontanería: "🔧",
      electricidad: "⚡",
      pintura: "🎨",
      carpintería: "🪚",
      limpieza: "🧹",
      jardinería: "🌱",
      informática: "💻",
      clases: "📚",
      mudanzas: "🚚",
      cuidados: "👶",
      reparaciones: "🔨",
      default: "📍",
    }

    return emojis[category.toLowerCase()] || emojis.default
  }

  return (
    <Card className="w-full overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm">
      <CardContent className="p-3">
        <div className="flex items-start space-x-3">
          <Avatar className="h-10 w-10 rounded-full border border-gray-100">
            <img src={getAvatarUrl(service.userId) || "/placeholder.svg"} alt={service.name} />
          </Avatar>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-0.5">
              <h3 className="text-sm font-medium truncate">{service.name}</h3>
              <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full ml-1" onClick={onClose}>
                <X className="h-3 w-3" />
              </Button>
            </div>

            <div className="flex items-center text-xs text-gray-500 mb-1">
              <Badge variant="outline" className="mr-1.5 px-1.5 py-0 h-4 text-[10px] bg-gray-50">
                <span className="mr-1">{getCategoryEmoji(service.category)}</span>
                <span className="capitalize">{service.category}</span>
              </Badge>

              <div className="flex items-center">
                <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                <span className="ml-1 text-xs font-medium">{service.rating}</span>
                <span className="ml-1 text-xs text-gray-500">({service.reviews || 0})</span>
              </div>
            </div>

            <p className="line-clamp-1 text-xs text-gray-500 mb-2">{service.description}</p>

            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold">{service.price}€/h</div>
              <Button className="h-7 rounded-full bg-black text-white hover:bg-black/90" size="sm" onClick={onClick}>
                <MessageSquare className="h-3 w-3 mr-1" />
                Contactar
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
