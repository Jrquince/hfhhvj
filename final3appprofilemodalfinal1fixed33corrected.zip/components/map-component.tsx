"use client"

import { useEffect, useRef, useState } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

// Iconos SVG para cada categoría
const categoryIcons: Record<string, string> = {
  fontanería: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M7 21h10"></path><rect x="2" y="3" width="20" height="14" rx="2"></rect><path d="M12 17v4"></path></svg>`,
  electricidad: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path></svg>`,
  pintura: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22a4 4 0 0 1-4-4V6c0-1.1.9-2 2-2h4a2 2 0 0 1 2 2v12a4 4 0 0 1-4 4Z"></path><path d="M18 16a4 4 0 0 0-4-4H8"></path><path d="M2 6h12"></path><path d="M2 10h8"></path></svg>`,
  carpintería: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m18 2 4 4"></path><path d="m17 7 3-3"></path><path d="M19 9 8.7 19.3c-1 1-2.5 1-3.4 0l-.6-.6c-1-1-1-2.5 0-3.4L15 5"></path><path d="m9 11 4 4"></path><path d="m5 19-3 3"></path></svg>`,
  limpieza: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`,
  jardinería: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 10a6 6 0 0 0-6-6 6 6 0 0 0 0 12h12a6 6 0 0 0 0-12 6 6 0 0 0-6 6"></path></svg>`,
  informática: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>`,
  clases: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>`,
  mudanzas: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>`,
  cuidados: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path></svg>`,
  reparaciones: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>`,
  vivienda: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>`,
  compraventa: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><path d="M3 6h18"></path><path d="M16 10a4 4 0 0 1-8 0"></path></svg>`,
  eventos: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>`,
  otros: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`,
}

// Colores para los marcadores
const markerColors = ["#F59E0B", "#000000", "#3B82F6", "#10B981", "#EF4444", "#8B5CF6", "#EC4899"]

// Imágenes estáticas de personas
const profileImages = [
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces",
]

interface MapComponentProps {
  activeFilter?: string
  onMarkerClick: (serviceId: number) => void
  services: any[]
}

export default function MapComponent({ activeFilter = "todos", onMarkerClick, services }: MapComponentProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<L.Map | null>(null)
  const markersRef = useRef<L.Marker[]>([])
  const [selectedService, setSelectedService] = useState<any | null>(null)

  // Limpiar marcadores existentes
  const clearMarkers = () => {
    if (mapInstanceRef.current) {
      markersRef.current.forEach((marker) => {
        mapInstanceRef.current?.removeLayer(marker)
      })
      markersRef.current = []
    }
  }

  // Crear un icono personalizado para el marcador (versión simplificada)
  const createCustomIcon = (category: string, colorIndex: number) => {
    const iconSvg = categoryIcons[category] || categoryIcons.otros
    const markerColor = markerColors[colorIndex % markerColors.length]

    // Crear un elemento HTML para el icono con diseño simplificado
    const iconHtml = `
      <div style="
        background-color: ${markerColor}; 
        width: 32px; 
        height: 32px; 
        border-radius: 50%; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        box-shadow: 0 2px 5px rgba(0,0,0,0.3); 
        border: 2px solid white;
      ">
        ${iconSvg}
      </div>
    `

    return L.divIcon({
      html: iconHtml,
      className: "", // Importante: clase vacía para evitar estilos por defecto
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    })
  }

  // Añadir marcadores al mapa
  const addMarkers = () => {
    if (!mapInstanceRef.current) return

    services.forEach((service, index) => {
      // Determinar la categoría
      const category = service.category.toLowerCase()

      // Crear el icono personalizado
      const icon = createCustomIcon(category, index)

      // Asegurarse de que el servicio tenga una imagen
      const serviceWithImage = {
        ...service,
        image: service.image || profileImages[index % profileImages.length],
        verified: service.verified !== undefined ? service.verified : Math.random() > 0.7,
      }

      // Crear y añadir el marcador al mapa
      const marker = L.marker([service.lat, service.lng], {
        icon,
        interactive: true, // Asegurarse de que el marcador sea interactivo
        bubblingMouseEvents: false, // Evitar que los eventos se propaguen
      })
        .addTo(mapInstanceRef.current!)
        .on("click", () => {
          setSelectedService(serviceWithImage)
        })

      markersRef.current.push(marker)
    })
  }

  // Efecto para inicializar el mapa
  useEffect(() => {
    if (typeof window !== "undefined" && mapContainerRef.current && !mapInstanceRef.current) {
      // Coordenadas de Bilbao
      const bilbaoCoordinates: [number, number] = [43.263, -2.935]

      // Inicializar el mapa
      const map = L.map(mapContainerRef.current, {
        center: bilbaoCoordinates,
        zoom: 13,
        zoomControl: true,
        attributionControl: false,
      })

      // Añadir la capa de OpenStreetMap
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
      }).addTo(map)

      // Guardar la referencia del mapa
      mapInstanceRef.current = map

      // Añadir marcadores iniciales
      addMarkers()

      // Forzar una actualización del tamaño del mapa
      setTimeout(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize()
        }
      }, 100)
    }

    // Limpiar el mapa cuando el componente se desmonte
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  // Efecto para actualizar marcadores cuando cambia el filtro o los servicios
  useEffect(() => {
    clearMarkers()
    addMarkers()
  }, [activeFilter, services])

  // Manejar el cierre de la previsualización
  const handleClosePreview = () => {
    setSelectedService(null)
  }

  return (
    <div className="relative w-full h-full">
      <div
        ref={mapContainerRef}
        className="w-full h-full rounded-lg shadow-md"
        style={{ height: "500px", width: "100%" }}
      />

      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
          <div className="relative bg-white rounded-xl shadow-lg max-w-md w-full mx-4">
            <button
              onClick={handleClosePreview}
              className="absolute -right-1 -top-1 h-7 w-7 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-gray-100 z-10"
              aria-label="Cerrar"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>

            <div className="p-5">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <div className="h-16 w-16 rounded-full overflow-hidden border-2 border-gray-200">
                    <img
                      src={selectedService.image || "/placeholder.svg"}
                      alt={selectedService.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  {selectedService.verified && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white rounded-full p-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="12"
                        height="12"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                  )}
                </div>

                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{selectedService.name}</h3>
                  <div className="flex items-center text-sm text-gray-500">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                      {selectedService.category}
                    </span>
                    <span className="mx-2">•</span>
                    <div className="flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="12"
                        height="12"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-yellow-500 mr-1"
                      >
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                      </svg>
                      <span>{selectedService.rating}</span>
                      <span className="ml-1">({selectedService.reviews})</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4">
                <p className="text-gray-600 text-sm">{selectedService.description}</p>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="text-lg font-semibold text-amber-600">
                  {selectedService.price}€<span className="text-sm text-gray-500">/hora</span>
                </div>
                <button className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-full text-sm font-medium transition-colors">
                  Contactar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
