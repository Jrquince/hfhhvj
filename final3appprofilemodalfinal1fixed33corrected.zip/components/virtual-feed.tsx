"use client"

import { useRef, useEffect, useState } from "react"
import { useVirtualizer } from "@tanstack/react-virtual"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Heart, Bookmark, MessageCircle, Star, ChevronDown, Check } from "lucide-react"
import ModernSwipeableCard from "./modern-swipeable-card"
import SurveyCard from "./survey-card"
import { ProfileAvatar } from "./profile-avatar"
import { getUniqueProfileImages } from "@/utils/profile-images"
import { useToast } from "@/hooks/use-toast"
import { useModal } from "@/hooks/use-modal-store"

// Datos simulados para el feed
const generateFeedItems = (count: number) => {
  const items = []
  const profileImages = getUniqueProfileImages(count)

  for (let i = 0; i < count; i++) {
    items.push({
      id: i,
      username: `usuario${i}`,
      profileImage: profileImages[i],
      title: `Servicio ${i + 1}`,
      description: `Descripción del servicio ${i + 1}. Este es un ejemplo de descripción para mostrar en el feed.`,
      location: "Bilbao",
      time: "Hace 2 horas",
      likes: Math.floor(Math.random() * 100),
      comments: Math.floor(Math.random() * 20),
      saved: Math.random() > 0.5,
    })
  }
  return items
}

// Helper function to get a consistent profile image URL based on user ID
const getConsistentProfileImage = (userId) => {
  const imageIndex = userId % 10 // Assuming you have 10 unique images
  return `/avatars/${imageIndex}.png`
}

export default function VirtualFeed({
  initialPosts,
  onLoadMore,
  loading,
  hasMore,
  onRefresh,
  onSavePost,
  onLikePost,
  searchQuery,
  filters,
}) {
  const { toast } = useToast()
  const { onOpen } = useModal()
  const [posts, setPosts] = useState(initialPosts || [])
  const parentRef = useRef(null)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [startY, setStartY] = useState(0)
  const [pullDistance, setPullDistance] = useState(0)
  const maxPullDistance = 80
  const minPullToRefreshDistance = 60
  const [activeAudioVideoId, setActiveAudioVideoId] = useState(null)
  const [saveAnimations, setSaveAnimations] = useState({})

  // Update posts when initialPosts changes
  useEffect(() => {
    if (initialPosts) {
      setPosts(initialPosts)
    }
  }, [initialPosts])

  const rowVirtualizer = useVirtualizer({
    count: hasMore ? (posts?.length || 0) + 1 : posts?.length || 0,
    getScrollElement: () => parentRef.current,
    estimateSize: (index) => {
      // Usar un tamaño base consistente para todos los tipos de tarjetas
      if (!posts || index >= posts.length) return 100 // Loading indicator
      return 430 // Tamaño consistente para todos los tipos de tarjetas
    },
    overscan: 5,
  })

  // Handle scroll to load more
  useEffect(() => {
    const [lastItem] = [...rowVirtualizer.getVirtualItems()].reverse()
    if (!lastItem || loading || !hasMore || !posts) return
    if (lastItem.index >= posts.length - 1) {
      onLoadMore && onLoadMore()
    }
  }, [rowVirtualizer.getVirtualItems(), loading, hasMore, posts, onLoadMore])

  // Pull to refresh handlers
  const handleTouchStart = (e) => {
    const touchY = e.touches[0].clientY
    setStartY(touchY)
  }

  const handleTouchMove = (e) => {
    const touchY = e.touches[0].clientY
    const scrollTop = parentRef.current?.scrollTop || 0

    // Only allow pull to refresh when at the top of the scroll
    if (scrollTop > 0) return

    const distance = touchY - startY
    if (distance > 0) {
      setPullDistance(Math.min(distance * 0.5, maxPullDistance))
      if (distance > minPullToRefreshDistance && !isRefreshing) {
        setIsRefreshing(true)
      }
    }
  }

  const handleTouchEnd = () => {
    if (pullDistance > minPullToRefreshDistance) {
      // Trigger refresh
      onRefresh && onRefresh()
      setTimeout(() => {
        setPullDistance(0)
        setIsRefreshing(false)
      }, 1000)
    } else {
      setPullDistance(0)
      setIsRefreshing(false)
    }
  }

  const openUserProfile = (user) => {
    // Obtener la misma imagen que se muestra en el feed para mantener coherencia visual
    const profileImage = user.image || getConsistentProfileImage(user.id)

    // Usar el hook useModal para abrir el modal de perfil
    onOpen("profile", {
      profile: {
        ...user,
        image: profileImage, // Asegurar que se usa exactamente la misma URL de imagen
      },
    })
  }

  // Asegurar que toggleSave maneje correctamente el evento
  const toggleSave = (id, event) => {
    if (event) {
      event.preventDefault()
      event.stopPropagation()
    }

    // Mostrar animación de guardado
    setSaveAnimations((prev) => ({ ...prev, [id]: true }))

    // Ocultar la animación después de 1 segundo
    setTimeout(() => {
      setSaveAnimations((prev) => ({ ...prev, [id]: false }))
    }, 1000)

    // Encontrar el post para determinar si estaba guardado o no
    const post = posts.find((p) => p.id === id)
    const wasSaved = post?.saved

    // Actualizar el estado local si no hay una función externa
    if (!onSavePost) {
      setPosts((prev) => prev.map((item) => (item.id === id ? { ...item, saved: !item.saved } : item)))

      // Mostrar toast de confirmación
      toast({
        title: wasSaved ? "Anuncio eliminado de guardados" : "Anuncio guardado correctamente",
        duration: 2000,
      })
    } else {
      // Si hay una función externa, llamarla con el ID (sin pasar el evento)
      onSavePost(id)
    }
  }

  const toggleLike = (id, event) => {
    if (event) {
      event.preventDefault()
      event.stopPropagation()
    }

    if (onLikePost) {
      onLikePost(id)
    } else {
      setPosts((prev) =>
        prev.map((item) =>
          item.id === id ? { ...item, likes: item.likes + (item.liked ? -1 : 1), liked: !item.liked } : item,
        ),
      )
    }
  }

  // Render post based on type
  const renderPost = (post, index) => {
    if (!post || !post.post) {
      console.error("Invalid post data:", post)
      return null
    }

    if (post.post.type === "video") {
      return renderVideoPost(post, index)
    } else if (post.post.type === "survey") {
      return renderSurveyPost(post, index)
    } else {
      return renderRegularPost(post, index)
    }
  }

  // Render a regular post
  const renderRegularPost = (post, index) => {
    // Asegurarse de que post.stats existe y tiene valores por defecto
    const stats = post.stats || { rating: 0, badges: 0, recommendations: 0 }
    const isAnimating = saveAnimations[post.id] || false

    return (
      <Card key={post.id} className="mb-3 overflow-visible border rounded-xl">
        <div className="p-3">
          <div className="flex items-center mb-4">
            {/* Avatar y nombre clickeables para abrir el modal */}
            <div
              className="flex items-center cursor-pointer"
              onClick={() =>
                openUserProfile({
                  id: post.user.id,
                  name: post.user.name,
                  image: post.user.image || getConsistentProfileImage(post.user.id),
                  location: post.user.location,
                  verified: post.user.verified,
                  email: `${post.user.name.toLowerCase().replace(/\s+/g, ".")}@example.com`,
                  rating: stats.rating,
                  recommendations: stats.recommendations,
                  badges: stats.badges,
                  profession: post.post.category,
                  experience: "5+ años",
                  description: post.post.description || post.post.title,
                })
              }
            >
              <ProfileAvatar
                userId={post.user.id}
                username={post.user.name}
                size="md"
                verified={post.user.verified}
                image={post.user.image}
              />
              <div className="ml-3">
                <h3 className="font-medium text-sm">{post.user?.name || "Usuario"}</h3>
                <div className="flex items-center">
                  <span className="text-xs text-gray-500 mr-2">{post.user?.location || "Sin ubicación"}</span>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${i < Math.floor(stats.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <ModernSwipeableCard
              stats={stats}
              postTitle={post.post.title || "Anuncio"}
              postId={post.id}
              userId={post.user?.id}
              username={post.user?.name}
            >
              <Link href={`/post-detail/${post.id}`}>
                <div className="border rounded-xl p-5 relative mb-2">
                  {/* Botón de guardar en la esquina superior derecha */}
                  <div className="absolute top-3 right-3 z-10">
                    <Button
                      variant="ghost"
                      size="icon"
                      className={`text-gray-400 hover:text-gray-600 bg-white/80 hover:bg-white shadow-sm ${
                        isAnimating ? "animate-bounce-small" : ""
                      }`}
                      onClick={(e) => toggleSave(post.id, e)}
                    >
                      <Bookmark className={`h-5 w-5 ${post.saved ? "fill-yellow-500 text-yellow-500" : ""}`} />
                    </Button>

                    {/* Animación de confirmación */}
                    {isAnimating && (
                      <div className="absolute top-0 right-0 animate-float-up pointer-events-none">
                        <div className="bg-green-500 rounded-full p-1 text-white">
                          <Check className="h-3 w-3" />
                        </div>
                      </div>
                    )}
                  </div>

                  {post.post.urgent && (
                    <div className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                      Urgente
                    </div>
                  )}

                  <div className="mt-10 mb-6 text-center">
                    <p className="font-medium text-lg">{post.post.title || "Sin título"}</p>
                    {post.post.price && (
                      <p className="mt-2 text-amber-700 font-medium text-sm bg-amber-50 rounded-full py-1 px-3 inline-block border border-amber-200">
                        {typeof post.post.price === "string" && post.post.price.includes("€/h")
                          ? post.post.price.replace("€/h", " €/aprox")
                          : post.post.price.includes("€")
                            ? post.post.price.replace("€", " €/aprox")
                            : `${post.post.price} €/aprox`}
                      </p>
                    )}
                    <div className="flex justify-center mt-6">
                      <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                        {getIconForCategory(post.post.category || "Otros")}
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </ModernSwipeableCard>
          </div>

          <div className="flex justify-between items-center text-xs text-gray-500 px-1 mt-2">
            <div className="flex items-center">
              <span className="font-medium">{post.post.category || "Otros"}</span>
              <span className="mx-1">•</span>
              <span>
                {post.timestamp || "Hoy"} {post.time || ""}
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0" onClick={(e) => toggleLike(post.id, e)}>
                <Heart className={`h-5 w-5 ${post.liked ? "fill-red-500 text-red-500" : "text-gray-400"}`} />
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                <ChevronDown className="h-5 w-5 text-gray-400" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    )
  }

  // Render a video post
  const renderVideoPost = (post, index) => {
    // Asegurarse de que post.stats existe y tiene valores por defecto
    const stats = post.stats || { rating: 0, badges: 0, recommendations: 0 }
    const isAudioActive = activeAudioVideoId === post.id
    const isAnimating = saveAnimations[post.id] || false

    return (
      <Card key={post.id} className="mb-3 overflow-visible border rounded-xl">
        <div className="p-3">
          <div
            className="flex items-center mb-4 cursor-pointer"
            onClick={() =>
              openUserProfile({
                id: post.user.id,
                name: post.user.name,
                image: post.user.image || getConsistentProfileImage(post.user.id),
                location: post.user.location,
                verified: post.user.verified,
                email: `${post.user.name.toLowerCase().replace(/\s+/g, ".")}@example.com`,
                rating: stats.rating,
                recommendations: stats.recommendations,
                badges: stats.badges,
                profession: post.post.category,
                experience: "5+ años",
                description: post.post.description || post.post.title,
              })
            }
          >
            <ProfileAvatar
              userId={post.user.id}
              username={post.user.name}
              size="md"
              verified={post.user.verified}
              image={post.user.image}
            />
            <div className="ml-3">
              <h3 className="font-medium text-sm">{post.user?.name || "Usuario"}</h3>
              <div className="flex items-center">
                <span className="text-xs text-gray-500 mr-2">{post.user?.location || "Sin ubicación"}</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 ${i < Math.floor(stats.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <ModernSwipeableCard
              stats={stats}
              postTitle={post.post.title || "Anuncio"}
              postId={post.id}
              userId={post.user?.id}
              username={post.user?.name}
              isVideo={true}
              hideCenterRightCTA={true}
            >
              <div className="relative rounded-xl overflow-hidden mb-2">
                {/* Botón de audio */}
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute top-2 left-2 z-10 bg-black/30 hover:bg-black/50 text-white rounded-full p-1 h-6 w-6 flex items-center justify-center"
                  onClick={(e) => {
                    e.preventDefault()
                    e.stopPropagation()
                    toggleAudio(post.id)
                  }}
                >
                  {isAudioActive ? (
                    <svg
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-white"
                    >
                      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="white" />
                      <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                      <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
                    </svg>
                  ) : (
                    <svg
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-white"
                    >
                      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="white" />
                      <line x1="23" y1="9" x2="17" y2="15" />
                      <line x1="17" y1="9" x2="23" y2="15" />
                    </svg>
                  )}
                </Button>

                {/* Botón de guardar en la esquina superior derecha */}
                <div className="absolute top-2 right-2 z-10">
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`bg-black/30 hover:bg-black/50 text-white rounded-full p-1 h-6 w-6 flex items-center justify-center ${
                      isAnimating ? "animate-bounce-small" : ""
                    }`}
                    onClick={(e) => {
                      e.preventDefault()
                      e.stopPropagation()
                      toggleSave(post.id, e)
                    }}
                  >
                    <Bookmark className={`h-4 w-4 ${post.saved ? "fill-yellow-500" : ""}`} />
                  </Button>

                  {/* Animación de confirmación */}
                  {isAnimating && (
                    <div className="absolute top-0 right-0 animate-float-up pointer-events-none">
                      <div className="bg-green-500 rounded-full p-1 text-white">
                        <Check className="h-3 w-3" />
                      </div>
                    </div>
                  )}
                </div>

                {post.post.videoUrl ? (
                  <video
                    id={`video-${post.id}`}
                    className="w-full h-64 object-cover rounded-t-xl"
                    playsInline
                    muted={!isAudioActive}
                    loop
                    autoPlay
                    preload="auto"
                    poster="/placeholder.svg?height=256&width=400&text=Cargando..."
                  >
                    <source src={post.post.videoUrl} type="video/mp4" />
                    Tu navegador no soporta videos HTML5.
                  </video>
                ) : (
                  <div className="w-full h-64 bg-gray-200 flex items-center justify-center rounded-t-xl">
                    <p className="text-gray-500">Video no disponible</p>
                  </div>
                )}

                <div className="p-4 bg-gradient-to-t from-black/80 to-transparent absolute bottom-0 left-0 right-0 text-white">
                  <h3 className="font-medium text-lg">{post.post.title || "Sin título"}</h3>
                  <p className="text-sm text-gray-200 mt-1">{post.post.description || "Sin descripción"}</p>
                </div>
              </div>
            </ModernSwipeableCard>
          </div>

          <div className="flex justify-between items-center text-xs text-gray-500 px-1 mt-2">
            <div className="flex items-center">
              <span className="font-medium">{post.post.category || "Otros"}</span>
              <span className="mx-1">•</span>
              <span>
                {post.timestamp || "Hoy"} {post.time || ""}
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0" onClick={(e) => toggleLike(post.id, e)}>
                <Heart className={`h-5 w-5 ${post.liked ? "fill-red-500 text-red-500" : "text-gray-400"}`} />
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                <MessageCircle className="h-5 w-5 text-gray-400" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    )
  }

  // Render a survey post
  const renderSurveyPost = (post, index) => {
    // Asegurarse de que post.stats existe y tiene valores por defecto
    const stats = post.stats || { rating: 0, badges: 0, recommendations: 0 }
    const isAnimating = saveAnimations[post.id] || false

    return (
      <Card key={post.id} className="mb-3 overflow-visible border rounded-xl">
        <div className="p-3">
          <div
            className="flex items-center mb-4 cursor-pointer"
            onClick={() =>
              openUserProfile({
                id: post.user.id,
                name: post.user.name,
                image: post.user.image || getConsistentProfileImage(post.user.id),
                location: post.user.location,
                verified: post.user.verified,
                email: `${post.user.name.toLowerCase().replace(/\s+/g, ".")}@example.com`,
                rating: stats.rating,
                recommendations: stats.recommendations,
                badges: stats.badges,
                profession: post.post.category,
                experience: "5+ años",
                description: post.post.description || post.post.title,
              })
            }
          >
            <ProfileAvatar
              userId={post.user.id}
              username={post.user.name}
              size="md"
              verified={post.user.verified}
              image={post.user.image}
            />
            <div className="ml-3">
              <h3 className="font-medium text-sm">{post.user?.name || "Usuario"}</h3>
              <div className="flex items-center">
                <span className="text-xs text-gray-500 mr-2">{post.user?.location || "Sin ubicación"}</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 ${i < Math.floor(stats.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mb-6 relative">
            {/* Botón de guardar en la esquina superior derecha */}
            <div className="absolute top-2 right-2 z-10">
              <Button
                variant="ghost"
                size="sm"
                className={`bg-white text-gray-500 hover:bg-gray-100 rounded-full p-1 h-6 w-6 flex items-center justify-center shadow-sm ${
                  isAnimating ? "animate-bounce-small" : ""
                }`}
                onClick={(e) => toggleSave(post.id, e)}
              >
                <Bookmark className={`h-4 w-4 ${post.saved ? "fill-yellow-500 text-yellow-500" : ""}`} />
              </Button>

              {/* Animación de confirmación */}
              {isAnimating && (
                <div className="absolute top-0 right-0 animate-float-up pointer-events-none">
                  <div className="bg-green-500 rounded-full p-1 text-white">
                    <Check className="h-3 w-3" />
                  </div>
                </div>
              )}
            </div>

            {post.post.options && post.post.options.length > 0 ? (
              <SurveyCard
                title={post.post.title || "Encuesta"}
                options={post.post.options}
                onVote={(option) => console.log(`Voted for: ${option}`)}
              />
            ) : (
              <div className="bg-gray-100 p-4 rounded-xl text-center">
                <p className="text-gray-500">Encuesta no disponible</p>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center text-xs text-gray-500 px-1 mt-3">
            <div className="flex items-center">
              <span className="font-medium">{post.post.category || "Encuesta"}</span>
              <span className="mx-1">•</span>
              <span>
                {post.timestamp || "Hoy"} {post.time || ""}
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0" onClick={(e) => toggleLike(post.id, e)}>
                <Heart className={`h-5 w-5 ${post.liked ? "fill-red-500 text-red-500" : "text-gray-400"}`} />
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                <MessageCircle className="h-5 w-5 text-gray-400" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    )
  }

  // Helper function to get icon for category
  const getIconForCategory = (category) => {
    switch (category) {
      case "Vivienda":
        return (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
            <polyline points="9 22 9 12 15 12 15 22" />
          </svg>
        )
      case "Hogar":
        return (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
          </svg>
        )
      case "Educación":
        return (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
            <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
          </svg>
        )
      case "Tecnología":
        return (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
            <line x1="16" y1="2" x2="16" y2="6" />
            <line x1="8" y1="2" x2="8" y2="6" />
            <line x1="3" y1="10" x2="21" y2="10" />
          </svg>
        )
      case "Eventos":
        return (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
            <line x1="16" y1="2" x2="16" y2="6" />
            <line x1="8" y1="2" x2="8" y2="6" />
            <line x1="3" y1="10" x2="21" y2="10" />
          </svg>
        )
      default:
        return (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="16" />
            <line x1="8" y1="12" x2="16" y2="12" />
          </svg>
        )
    }
  }

  // Función para activar/desactivar el audio de un video
  const toggleAudio = (videoId) => {
    // Si ya está activo, desactivarlo
    if (activeAudioVideoId === videoId) {
      setActiveAudioVideoId(null)
      return
    }

    // Desactivar el audio del video anterior si existe
    if (activeAudioVideoId) {
      const prevVideo = document.getElementById(`video-${activeAudioVideoId}`)
      if (prevVideo) {
        prevVideo.muted = true
      }
    }

    // Activar el audio del nuevo video
    setActiveAudioVideoId(videoId)
    const video = document.getElementById(`video-${videoId}`)
    if (video) {
      video.muted = false

      // Intentar reproducir con audio (puede requerir interacción del usuario en algunos navegadores)
      const playPromise = video.play()
      if (playPromise !== undefined) {
        playPromise.catch((error) => {
          console.log("Error al reproducir con audio:", error)
          // Mostrar un mensaje al usuario indicando que debe interactuar con el video
          // para habilitar el audio en algunos navegadores
        })
      }
    }
  }

  const optimizeVideoPlayback = () => {
    // Usar requestIdleCallback si está disponible, o setTimeout como fallback
    const scheduleTask = window.requestIdleCallback || ((cb) => setTimeout(cb, 1))

    scheduleTask(() => {
      const videoElements = document.querySelectorAll("video")
      videoElements.forEach((video) => {
        // Configurar atributos para reproducción óptima
        video.setAttribute("playsinline", "")
        video.setAttribute("webkit-playsinline", "")

        // Mantener el estado de muted según si es el video activo o no
        const videoId = video.id.replace("video-", "")
        video.muted = activeAudioVideoId !== Number.parseInt(videoId)

        video.preload = "auto"
        video.loop = true // Asegurar que los videos se reproduzcan en bucle

        // Crear un IntersectionObserver para cada video
        const observer = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                // Intentar reproducir el video varias veces si falla
                const playVideo = () => {
                  const playPromise = video.play()
                  if (playPromise !== undefined) {
                    playPromise.catch((err) => {
                      console.log("Error al reproducir:", err)
                      // Reintentar después de un breve retraso
                      setTimeout(playVideo, 300)
                    })
                  }
                }
                playVideo()
              } else {
                video.pause()

                // Si este video tenía el audio activo y ya no está visible, desactivar el audio
                const videoId = video.id.replace("video-", "")
                if (activeAudioVideoId === Number.parseInt(videoId)) {
                  setActiveAudioVideoId(null)
                }
              }
            })
          },
          { threshold: 0.5 },
        )

        observer.observe(video)
      })
    })
  }

  useEffect(() => {
    optimizeVideoPlayback()
  }, [activeAudioVideoId])

  return (
    <>
      <div
        ref={parentRef}
        className="flex-1 overflow-auto h-[calc(100vh-180px)]"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Pull to refresh indicator */}
        {pullDistance > 0 && (
          <div
            className="flex justify-center items-center text-gray-500"
            style={{ height: `${pullDistance}px`, marginTop: `-${pullDistance}px` }}
          >
            {isRefreshing ? (
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
            ) : (
              <span>
                {pullDistance > minPullToRefreshDistance ? "Suelta para actualizar" : "Desliza para actualizar"}
              </span>
            )}
          </div>
        )}

        {/* Search results indicator */}
        {searchQuery && (
          <div className="p-4 bg-yellow-50 border-b border-yellow-100">
            <p className="text-sm text-yellow-800">
              Mostrando resultados para: <span className="font-medium">"{searchQuery}"</span>
            </p>
          </div>
        )}

        {/* Virtual list */}
        <div className="relative px-4 pt-1 pb-16" style={{ height: `${rowVirtualizer.getTotalSize()}px` }}>
          {rowVirtualizer.getVirtualItems().map((virtualRow) => {
            const isLoaderRow = virtualRow.index >= (posts?.length || 0)
            const post = !isLoaderRow && posts ? posts[virtualRow.index] : null

            return (
              <div
                key={virtualRow.key}
                className="absolute top-0 left-0 right-0 px-4"
                style={{
                  height: `${virtualRow.size}px`,
                  transform: `translateY(${virtualRow.start}px)`,
                }}
              >
                {isLoaderRow ? (
                  hasMore ? (
                    <div className="p-4 flex justify-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                    </div>
                  ) : (
                    <div className="p-4 text-center text-gray-500 text-sm">No hay más anuncios para mostrar</div>
                  )
                ) : (
                  post && renderPost(post, virtualRow.index)
                )}
              </div>
            )
          })}
        </div>

        {/* Empty state */}
        {(!posts || posts.length === 0) && !loading && (
          <div className="flex flex-col items-center justify-center p-8 text-center h-[50vh]">
            <div className="bg-gray-100 rounded-full p-4 mb-4">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
            </div>
            <h3 className="text-lg font-medium mb-2">No se encontraron anuncios</h3>
            <p className="text-gray-500 text-sm mb-4">
              No hay anuncios que coincidan con tu búsqueda. Intenta con otros filtros o términos.
            </p>
            <Button onClick={onRefresh}>Actualizar</Button>
          </div>
        )}

        {/* Loading state */}
        {(!posts || posts.length === 0) && loading && (
          <div className="p-4 space-y-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="mb-3 overflow-hidden border rounded-xl">
                <div className="p-3">
                  <div className="flex items-center mb-3">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="ml-3 space-y-2">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-3 w-32" />
                    </div>
                  </div>
                  <Skeleton className="h-40 w-full rounded-xl mb-3" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-3 w-20" />
                    <div className="flex space-x-2">
                      <Skeleton className="h-6 w-6 rounded-full" />
                      <Skeleton className="h-6 w-6 rounded-full" />
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </>
  )
}
