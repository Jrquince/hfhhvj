"use client"

import type React from "react"
import { useState } from "react"
import { Star, Award, ThumbsUp, BadgeCheck, Clock, Zap, Users, ArrowLeft, ChevronRight, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import ShareModal from "./share-modal"

interface SwipeableCardProps {
  children: React.ReactNode
  stats: {
    rating: number | string
    badges: number
    recommendations: number
  }
  postTitle?: string
  postId?: string | number
  userId?: string | number
  username?: string
}

export default function SwipeableCard({
  children,
  stats,
  postTitle = "Anuncio",
  postId = "123",
  userId = "1",
  username = "",
}: SwipeableCardProps) {
  const [isFlipped, setIsFlipped] = useState(false)
  const [isHovering, setIsHovering] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)

  // Convertir rating a número para operaciones y comparaciones
  const ratingValue = typeof stats.rating === "number" ? stats.rating : Number.parseFloat(stats.rating || "0")

  // Formatear rating para mostrar
  const formattedRating = typeof stats.rating === "number" ? stats.rating.toFixed(1) : stats.rating

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return "text-green-600"
    if (rating >= 3.5) return "text-amber-600"
    return "text-red-500"
  }

  return (
    <div className="relative w-full overflow-hidden rounded-lg">
      <div className="relative">
        {/* Front of card (original content) */}
        <div className={`bg-white rounded-lg transition-all duration-300 ${isFlipped ? "hidden" : "block"}`}>
          {children}

          {/* Botón de compartir */}
          <button
            onClick={(e) => {
              e.stopPropagation()
              e.preventDefault()
              setShowShareModal(true)
            }}
            className="absolute bottom-2.5 right-2.5 text-gray-500 p-1 hover:text-gray-700 transition-colors z-10"
            aria-label="Compartir anuncio"
          >
            <Send className="h-3 w-3" />
          </button>

          {/* Flecha minimalista para deslizar */}
          <div
            className="absolute right-0 top-1/2 -translate-y-1/2 flex items-center"
            onMouseEnter={() => setIsHovering(true)}
            onMouseLeave={() => setIsHovering(false)}
          >
            <button
              onClick={() => setIsFlipped(true)}
              className="bg-gray-100 text-gray-600 shadow-sm rounded-l-md p-2 transition-all duration-300 z-10 hover:bg-gray-200 group border-l border-t border-b border-gray-200"
              aria-label="Ver más información"
            >
              <div className="flex items-center">
                <span
                  className={`mr-1 font-medium text-xs whitespace-nowrap overflow-hidden transition-all duration-300 ${isHovering ? "w-auto opacity-100" : "w-0 opacity-0"}`}
                >
                  Más
                </span>
                <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </div>
            </button>
          </div>

          {/* Indicador sutil de deslizamiento */}
          <div className="absolute bottom-2 right-2 flex space-x-1">
            <div className="w-1.5 h-1.5 rounded-full bg-gray-400"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-gray-200"></div>
          </div>
        </div>

        {/* Back of card (stats) */}
        <div
          className={`bg-white rounded-lg shadow-sm overflow-hidden transition-all duration-300 border border-gray-100 ${isFlipped ? "block" : "hidden"}`}
        >
          {/* Header minimalista */}
          <div className="bg-gray-50 p-3 flex justify-between items-center border-b border-gray-100">
            <h3 className="text-base font-medium text-gray-700">Perfil Profesional</h3>
            <Button
              onClick={() => setIsFlipped(false)}
              variant="ghost"
              size="sm"
              className="text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-md p-1 h-auto"
              aria-label="Volver"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              <span className="text-xs font-medium">Volver</span>
            </Button>
          </div>

          {/* Content con mejor espaciado */}
          <div className="p-4 space-y-5">
            {/* Rating - Diseño minimalista */}
            <div className="bg-white rounded-lg p-3 border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-gray-50 rounded-full p-2 border border-gray-100">
                    <Star className="h-5 w-5 text-amber-500" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-gray-500">Valoración</p>
                    <p className={`text-2xl font-semibold ${getRatingColor(ratingValue)}`}>
                      {formattedRating || "N/A"}
                    </p>
                  </div>
                </div>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-4 w-4 ${
                        star <= Math.floor(ratingValue)
                          ? "text-amber-400 fill-amber-400"
                          : star <= ratingValue
                            ? "text-amber-400 fill-amber-400 opacity-50"
                            : "text-gray-200"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Recomendaciones - Diseño minimalista */}
            <div className="bg-white rounded-lg p-3 border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-gray-50 rounded-full p-2 border border-gray-100">
                    <Users className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-gray-500">Recomendaciones</p>
                    <p className="text-2xl font-semibold text-green-600">{stats.recommendations}</p>
                  </div>
                </div>
                <div className="bg-gray-50 px-2 py-1 rounded-md text-xs font-medium text-gray-600 border border-gray-100">
                  {stats.recommendations > 20 ? "Muy popular" : stats.recommendations > 10 ? "Popular" : "Recomendado"}
                </div>
              </div>
            </div>

            {/* Divider sutil */}
            <div className="h-px bg-gray-100" />

            {/* Stats en grid minimalista */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-3 border border-gray-100 shadow-sm">
                <div className="flex items-center gap-2 mb-1">
                  <Award className="h-4 w-4 text-blue-500" />
                  <p className="text-xs font-medium text-gray-600">Insignias</p>
                </div>
                <p className="text-xl font-semibold text-gray-800">{stats.badges}</p>
                <div className="mt-1 flex gap-1">
                  {Array(Math.min(stats.badges, 5))
                    .fill(0)
                    .map((_, i) => (
                      <BadgeCheck key={i} className="h-3 w-3 text-blue-400" />
                    ))}
                </div>
              </div>

              <div className="bg-white rounded-lg p-3 border border-gray-100 shadow-sm">
                <div className="flex items-center gap-2 mb-1">
                  <ThumbsUp className="h-4 w-4 text-purple-500" />
                  <p className="text-xs font-medium text-gray-600">Satisfacción</p>
                </div>
                <p className="text-xl font-semibold text-gray-800">98%</p>
                <p className="text-xs text-gray-500 mt-1">{Math.floor(stats.recommendations * 1.5)} opiniones</p>
              </div>
            </div>

            {/* Additional stats minimalistas */}
            <div className="space-y-2 mt-1">
              <div className="flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <Clock className="h-3.5 w-3.5 text-gray-500" />
                  <span className="text-xs text-gray-600">Tiempo de respuesta</span>
                </div>
                <span className="text-xs font-medium text-gray-700">{"< 1 hora"}</span>
              </div>

              <div className="flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <Zap className="h-3.5 w-3.5 text-gray-500" />
                  <span className="text-xs text-gray-600">Tasa de finalización</span>
                </div>
                <span className="text-xs font-medium text-gray-700">98%</span>
              </div>
            </div>

            {/* Social proof minimalista */}
            <div className="bg-gray-50 rounded-lg p-3 border border-gray-100 mt-2">
              <p className="text-center text-sm text-gray-600">
                <span className="font-medium text-gray-700">{stats.recommendations} usuarios</span> recomiendan este
                profesional
              </p>
            </div>

            {/* Botón de volver minimalista */}
            <div className="flex justify-center mt-1">
              <Button
                onClick={() => setIsFlipped(false)}
                variant="outline"
                size="sm"
                className="rounded-md border-gray-200 text-gray-600 hover:bg-gray-50 text-xs h-8"
              >
                <ArrowLeft className="h-3.5 w-3.5 mr-1" />
                Volver a la tarjeta
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Modal de compartir */}
      <ShareModal
        open={showShareModal}
        onClose={() => setShowShareModal(false)}
        postTitle={postTitle}
        postId={postId}
      />
    </div>
  )
}
