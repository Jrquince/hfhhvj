"use client"

import { useRouter } from "next/navigation"
import { useModal } from "@/hooks/use-modal-store"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { X, MessageSquare, Star, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useState } from "react"

const ProfileModal = () => {
  const { isOpen, onClose, type, data } = useModal()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const isModalOpen = isOpen && type === "profile"
  const { profile } = data

  const handleContact = () => {
    setIsLoading(true)
    // Cerrar el modal primero
    onClose()
    // Pequeño retraso para asegurar que el modal se cierre antes de navegar
    setTimeout(() => {
      router.push(`/chat-detail/${profile?.id || "1"}`)
      setIsLoading(false)
    }, 300)
  }

  if (!profile) {
    return null
  }

  // Iconos para especialidades
  const specialtyIcons: Record<string, JSX.Element> = {
    Limpieza: <Star className="h-3 w-3 text-yellow-500" />,
    Fontanería: <Star className="h-3 w-3 text-blue-500" />,
    Electricidad: <Star className="h-3 w-3 text-amber-500" />,
    Carpintería: <Star className="h-3 w-3 text-orange-500" />,
    Pintura: <Star className="h-3 w-3 text-purple-500" />,
    Jardinería: <Star className="h-3 w-3 text-green-500" />,
    Mudanzas: <Star className="h-3 w-3 text-indigo-500" />,
    Montaje: <Star className="h-3 w-3 text-pink-500" />,
  }

  return (
    <Dialog open={isModalOpen} onOpenChange={onClose}>
      <DialogContent className="p-0 overflow-hidden max-w-[280px] rounded-xl max-h-[85vh]">
        <div className="relative">
          {/* Imagen de perfil con overlay */}
          <div className="relative h-28 bg-gray-100 overflow-hidden">
            {profile.image && (
              <img
                src={profile.image || "/placeholder.svg"}
                alt={`Foto de perfil de ${profile.name}`}
                className="w-full h-full object-cover"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute top-2 right-2">
              <Button
                onClick={onClose}
                variant="ghost"
                className="h-6 w-6 p-0 rounded-full bg-black/20 hover:bg-black/40"
              >
                <X className="h-3 w-3 text-white" />
                <span className="sr-only">Cerrar</span>
              </Button>
            </div>
            <div className="absolute top-2 left-2">
              <Badge variant="secondary" className="flex items-center gap-1 bg-black/20 text-white border-none">
                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                <span className="text-xs">{profile.rating || "4.8"}</span>
              </Badge>
            </div>
            <div className="absolute bottom-3 left-3 right-3">
              <div className="flex items-center gap-1">
                <h2 className="text-base font-semibold text-white">{profile.name}</h2>
                {profile.verified && <CheckCircle className="h-3 w-3 text-blue-400 fill-blue-400" />}
              </div>
            </div>
          </div>

          {/* Contenido del perfil */}
          <div className="p-3">
            {/* Estadísticas */}
            <div className="grid grid-cols-2 gap-2 mb-2.5">
              <div className="bg-gray-50 p-2 rounded-md text-center">
                <p className="text-xs text-gray-500">Servicios</p>
                <p className="text-base font-semibold">{profile.services || "124"}</p>
              </div>
              <div className="bg-gray-50 p-2 rounded-md text-center">
                <p className="text-xs text-gray-500">Satisfacción</p>
                <p className="text-base font-semibold">{profile.satisfaction || "98%"}</p>
              </div>
            </div>

            {/* Especialidades */}
            <div className="mb-2.5">
              <p className="text-xs font-medium text-gray-500 mb-1">Especialidades</p>
              <div className="flex flex-wrap gap-1">
                {(profile.specialties || ["Limpieza", "Fontanería", "Electricidad"]).map((specialty) => (
                  <Badge
                    key={specialty}
                    variant="outline"
                    className="text-[10px] py-0 h-5 flex items-center gap-1 border-gray-200"
                  >
                    {specialtyIcons[specialty] || <Star className="h-3 w-3 text-gray-400" />}
                    {specialty}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Botón de acción */}
            <Button onClick={handleContact} disabled={isLoading} className="w-full flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              {isLoading ? "Conectando..." : "Contactar ahora"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default ProfileModal
