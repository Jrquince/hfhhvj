"use client"

import { useState } from "react"
import { Award, Star, Trophy, Zap, ChevronUp, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"

interface EnhancedGamificationBarProps {
  current?: number
  total?: number
  message?: string
}

export default function EnhancedGamificationBar({
  current = 4,
  total = 5,
  message = "Vas por muy buen camino",
}: EnhancedGamificationBarProps) {
  const [expanded, setExpanded] = useState(false)
  const percentage = (current / total) * 100

  const badges = [
    { name: "Principiante", icon: <Star className="h-4 w-4" />, achieved: true },
    { name: "Confiable", icon: <Award className="h-4 w-4" />, achieved: true },
    { name: "Experto", icon: <Trophy className="h-4 w-4" />, achieved: true },
    { name: "Profesional", icon: <Zap className="h-4 w-4" />, achieved: current >= 4 },
    { name: "Maestro", icon: <Award className="h-4 w-4 fill-yellow-500" />, achieved: false },
  ]

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-1">
        <h3 className="text-sm font-semibold">AYUDAS REALIZADAS</h3>
        <span className="text-sm font-medium">
          {current}/{total}
        </span>
      </div>

      <div className="relative h-8 bg-gray-200 rounded-full overflow-hidden">
        <div
          className="absolute inset-y-0 left-0 bg-amber-400 rounded-full flex items-center justify-center"
          style={{ width: `${percentage}%` }}
        >
          <span className="text-white font-medium text-sm z-10">
            {current}/{total}
          </span>
        </div>

        {/* Marcadores de progreso */}
        <div className="absolute inset-0 flex items-center justify-between px-2">
          {[...Array(total)].map((_, i) => (
            <div key={i} className={`h-4 w-1 rounded-full ${i < current ? "bg-white opacity-50" : "bg-gray-300"}`} />
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between mt-1">
        <p className="text-sm">
          {current === total
            ? "¡Felicidades! Has completado todas las ayudas"
            : `${message} - ${total - current} más para completar`}
        </p>
        <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setExpanded(!expanded)}>
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>
      </div>

      {expanded && (
        <div className="bg-yellow-50 rounded-lg p-4 mt-2 border border-yellow-100 animate-fadeIn">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">Detalles de progreso</h3>
            <button className="text-xs text-yellow-600" onClick={() => setExpanded(false)}>
              Cerrar
            </button>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Estrellas actuales:</span>
              <div className="flex items-center">
                <span className="font-medium mr-1">{current * 5}</span>
                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm">Ayudas realizadas:</span>
              <span className="font-medium">23</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm">Para siguiente nivel:</span>
              <div className="flex items-center">
                <span className="font-medium mr-1">{(total - current) * 5}</span>
                <Star className="h-4 w-4 text-yellow-500" />
              </div>
            </div>
          </div>

          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2">Insignias</h4>
            <div className="grid grid-cols-5 gap-2">
              {badges.map((badge, index) => (
                <div key={index} className="flex flex-col items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      badge.achieved ? "bg-yellow-100 text-yellow-600" : "bg-gray-100 text-gray-400"
                    }`}
                  >
                    {badge.icon}
                  </div>
                  <span className="text-xs mt-1 text-center">{badge.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
