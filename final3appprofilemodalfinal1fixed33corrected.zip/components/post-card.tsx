"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  BookmarkPlus,
  Heart,
  MapPin,
  AlertCircle,
  Clock,
  Home,
  PenToolIcon as Tool,
  Book,
  Laptop,
  Car,
  Dog,
  Briefcase,
  Paintbrush,
  Music,
  Bike,
  Plane,
  ShoppingBag,
  Users,
  Wrench,
  Hammer,
  Truck,
  Smartphone,
  Leaf,
  Baby,
  GraduationCap,
  Key,
  Bed,
  Wifi,
  Droplet,
  Trash,
  Printer,
  FileText,
  Calendar,
  Globe,
  Zap,
  CheckCircle,
} from "lucide-react"
import SwipeableCard from "@/components/swipeable-card"
import SurveyCard from "@/components/survey-card"
import UserProfilePlaceholder from "@/components/user-profile-placeholder"
import { useToast } from "@/hooks/use-toast"

interface PostCardProps {
  post: any
  onSave?: (id: number, event: React.MouseEvent) => void
  onLike?: (id: number, event: React.MouseEvent) => void
}

// Función para determinar el icono basado en el título del anuncio
const getIconForTitle = (title: string) => {
  const titleLower = title.toLowerCase()

  // Vivienda y alojamiento
  if (
    titleLower.includes("piso") ||
    titleLower.includes("apartamento") ||
    titleLower.includes("vivienda") ||
    titleLower.includes("casa")
  )
    return <Home className="h-3 w-3 mr-1" />
  if (titleLower.includes("habitación") || titleLower.includes("compañero") || titleLower.includes("roommate"))
    return <Bed className="h-3 w-3 mr-1" />
  if (titleLower.includes("alquiler") || titleLower.includes("alquilar")) return <Key className="h-3 w-3 mr-1" />
  if (titleLower.includes("mudanza")) return <Truck className="h-3 w-3 mr-1" />

  // Servicios profesionales
  if (titleLower.includes("fontaner") || titleLower.includes("agua") || titleLower.includes("fuga"))
    return <Droplet className="h-3 w-3 mr-1" />
  if (titleLower.includes("electric") || titleLower.includes("enchufe") || titleLower.includes("luz"))
    return <Zap className="h-3 w-3 mr-1" />
  if (titleLower.includes("pintur") || titleLower.includes("pintar")) return <Paintbrush className="h-3 w-3 mr-1" />
  if (titleLower.includes("carpinter") || titleLower.includes("mueble") || titleLower.includes("madera"))
    return <Hammer className="h-3 w-3 mr-1" />
  if (titleLower.includes("jardiner") || titleLower.includes("jardín") || titleLower.includes("plantas"))
    return <Leaf className="h-3 w-3 mr-1" />
  if (titleLower.includes("limpieza") || titleLower.includes("limpiar")) return <Trash className="h-3 w-3 mr-1" />
  if (titleLower.includes("reforma")) return <Tool className="h-3 w-3 mr-1" />
  if (titleLower.includes("reparación") || titleLower.includes("arreglar") || titleLower.includes("reparar"))
    return <Wrench className="h-3 w-3 mr-1" />

  // Educación y formación
  if (
    titleLower.includes("profesor") ||
    titleLower.includes("clase") ||
    titleLower.includes("enseñar") ||
    titleLower.includes("matemáticas")
  )
    return <Book className="h-3 w-3 mr-1" />
  if (titleLower.includes("curso") || titleLower.includes("formación") || titleLower.includes("estudiar"))
    return <GraduationCap className="h-3 w-3 mr-1" />
  if (titleLower.includes("idioma") || titleLower.includes("inglés") || titleLower.includes("español"))
    return <Globe className="h-3 w-3 mr-1" />

  // Tecnología
  if (titleLower.includes("ordenador") || titleLower.includes("portátil") || titleLower.includes("pc"))
    return <Laptop className="h-3 w-3 mr-1" />
  if (titleLower.includes("móvil") || titleLower.includes("teléfono") || titleLower.includes("smartphone"))
    return <Smartphone className="h-3 w-3 mr-1" />
  if (titleLower.includes("wifi") || titleLower.includes("internet") || titleLower.includes("red"))
    return <Wifi className="h-3 w-3 mr-1" />
  if (titleLower.includes("impresora")) return <Printer className="h-3 w-3 mr-1" />

  // Vehículos
  if (titleLower.includes("coche") || titleLower.includes("auto") || titleLower.includes("vehículo"))
    return <Car className="h-3 w-3 mr-1" />
  if (titleLower.includes("moto") || titleLower.includes("motocicleta")) return <Bike className="h-3 w-3 mr-1" />
  if (titleLower.includes("bicicleta") || titleLower.includes("bici")) return <Bike className="h-3 w-3 mr-1" />

  // Mascotas
  if (titleLower.includes("perro") || titleLower.includes("pasear") || titleLower.includes("mascota"))
    return <Dog className="h-3 w-3 mr-1" />

  // Cuidados
  if (titleLower.includes("niño") || titleLower.includes("canguro") || titleLower.includes("cuidar"))
    return <Baby className="h-3 w-3 mr-1" />
  if (titleLower.includes("mayor") || titleLower.includes("anciano") || titleLower.includes("abuelo"))
    return <Users className="h-3 w-3 mr-1" />

  // Trabajo y empleo
  if (titleLower.includes("trabajo") || titleLower.includes("empleo") || titleLower.includes("oferta"))
    return <Briefcase className="h-3 w-3 mr-1" />
  if (titleLower.includes("cv") || titleLower.includes("currículum") || titleLower.includes("entrevista"))
    return <FileText className="h-3 w-3 mr-1" />

  // Eventos y ocio
  if (titleLower.includes("evento") || titleLower.includes("fiesta") || titleLower.includes("celebración"))
    return <Calendar className="h-3 w-3 mr-1" />
  if (titleLower.includes("viaje") || titleLower.includes("viajar") || titleLower.includes("excursión"))
    return <Plane className="h-3 w-3 mr-1" />
  if (titleLower.includes("música") || titleLower.includes("concierto") || titleLower.includes("instrumento"))
    return <Music className="h-3 w-3 mr-1" />

  // Compras y ventas
  if (titleLower.includes("vendo") || titleLower.includes("venta") || titleLower.includes("vender"))
    return <ShoppingBag className="h-3 w-3 mr-1" />
  if (titleLower.includes("compro") || titleLower.includes("comprar")) return <ShoppingBag className="h-3 w-3 mr-1" />

  // Tiempo y clima
  if (titleLower.includes("urgente") || titleLower.includes("inmediato") || titleLower.includes("ya"))
    return <AlertCircle className="h-3 w-3 mr-1" />
  if (titleLower.includes("hoy") || titleLower.includes("mañana") || titleLower.includes("semana"))
    return <Clock className="h-3 w-3 mr-1" />

  // Por defecto, usar un icono basado en la categoría
  return <Clock className="h-3 w-3 mr-1" />
}

export default function PostCard({ post, onSave, onLike }: PostCardProps) {
  const { toast } = useToast()
  const [showUserProfile, setShowUserProfile] = useState(false)
  const [saveAnimation, setSaveAnimation] = useState(false)

  // Función para abrir el modal de perfil
  const openUserProfile = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setShowUserProfile(true)
  }

  // Función para manejar el guardado con animación
  const handleSave = (id: number, event: React.MouseEvent) => {
    event.preventDefault()
    event.stopPropagation()

    // Mostrar animación
    setSaveAnimation(true)

    // Mostrar toast de confirmación
    toast({
      title: post.saved ? "Anuncio eliminado de guardados" : "Anuncio guardado",
      description: post.saved
        ? "El anuncio ha sido eliminado de tu lista de guardados"
        : "El anuncio ha sido añadido a tu lista de guardados",
      duration: 3000,
    })

    // Llamar al callback original
    if (onSave) {
      onSave(id, event)
    }

    // Quitar la animación después de un tiempo
    setTimeout(() => {
      setSaveAnimation(false)
    }, 1000)
  }

  // Si es una encuesta, renderizar la tarjeta de encuesta en su lugar
  if (post.post.type === "survey") {
    return (
      <SurveyCard
        title={post.post.title}
        options={post.post.options}
        onVote={(option) => {
          toast({
            title: "¡Gracias por tu voto!",
            description: `Has seleccionado: ${option}`,
            duration: 3000,
          })
        }}
      />
    )
  }

  // Si es un video, renderizar la tarjeta de video
  if (post.post.type === "video") {
    return (
      <SwipeableCard
        stats={post.stats}
        postTitle={post.post.title}
        postId={post.id}
        userId={post.user.id}
        username={post.user.name}
      >
        <Card className="overflow-hidden border-0 shadow-sm h-full">
          <CardContent className="p-0 h-full">
            <div className="relative">
              <video
                src={post.post.videoUrl}
                className="w-full h-[400px] object-cover"
                autoPlay
                loop
                muted
                playsInline
                webkit-playsinline="true"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent pointer-events-none" />
            </div>

            {/* Información superpuesta */}
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
              <div className="flex items-start justify-between">
                <div className="flex-1 mr-4">
                  <Badge className="bg-amber-500 hover:bg-amber-600 mb-2">{post.post.category}</Badge>
                  <h3 className="font-bold text-lg mb-1 line-clamp-2">{post.post.title}</h3>
                  <p className="text-sm text-white/90 mb-3 line-clamp-2">{post.post.description}</p>

                  <div className="flex items-center mt-2 mb-1 cursor-pointer" onClick={openUserProfile}>
                    <Avatar className="h-7 w-7 border border-white/50">
                      <AvatarImage
                        src={post.user.image || `/placeholder.svg?height=28&width=28`}
                        alt={post.user.name}
                      />
                      <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="ml-2">
                      <p className="text-sm font-medium line-clamp-1">{post.user.name}</p>
                      <div className="flex items-center text-xs text-white/80">
                        <MapPin className="h-3 w-3 mr-1" />
                        {post.user.location}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Modal de perfil de usuario */}
        <UserProfilePlaceholder
          isOpen={showUserProfile}
          onClose={() => setShowUserProfile(false)}
          user={{
            id: post.user.id,
            name: post.user.name,
            image: post.user.image,
            location: post.user.location,
            verified: post.user.verified,
            rating: post.stats.rating,
            recommendations: post.stats.recommendations,
            badges: post.stats.badges,
            profession: post.post.category,
            experience: post.user.experience || "5+ años",
            description: post.post.description,
          }}
        />
      </SwipeableCard>
    )
  }

  // Para posts regulares
  return (
    <SwipeableCard
      stats={post.stats}
      postTitle={post.post.title}
      postId={post.id}
      userId={post.user.id}
      username={post.user.name}
    >
      <Link href={`/post-detail/${post.id}`}>
        <Card className="overflow-hidden hover:shadow-md transition-shadow">
          <CardContent className="p-0">
            {/* Header */}
            <div className="flex items-center p-3 border-b relative">
              <div className="flex items-center cursor-pointer" onClick={openUserProfile}>
                <Avatar className="h-10 w-10">
                  <AvatarImage src={post.user.image || `/placeholder.svg?height=40&width=40`} alt={post.user.name} />
                  <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="ml-3">
                  <div className="flex items-center">
                    <h3 className="font-medium text-sm">{post.user.name}</h3>
                    {post.user.verified && (
                      <Badge
                        variant="outline"
                        className="ml-2 px-1 py-0 h-4 text-[10px] bg-blue-50 text-blue-600 border-blue-100"
                      >
                        Verificado
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center text-xs text-gray-500">
                    <MapPin className="h-3 w-3 mr-1" />
                    {post.user.location}
                  </div>
                </div>
              </div>
              <div className="text-right text-xs text-gray-500 ml-auto">
                <p>{post.timestamp}</p>
                <p>{post.time}</p>
              </div>
            </div>

            {/* Content */}
            <div className="p-3">
              <div className="flex items-center mb-2">
                <Badge
                  className={`${
                    post.post.urgent ? "bg-red-500 hover:bg-red-600" : "bg-gray-500 hover:bg-gray-600"
                  } mr-2`}
                >
                  {post.post.urgent ? <AlertCircle className="h-3 w-3 mr-1" /> : getIconForTitle(post.post.title)}
                  {post.post.urgent ? "Urgente" : post.post.category}
                </Badge>
                <Badge className="bg-yellow-500 hover:bg-yellow-600">{post.post.category}</Badge>
                {post.post.price && (
                  <Badge className="ml-auto bg-green-500 hover:bg-green-600">{post.post.price}</Badge>
                )}
              </div>

              <h3 className="font-medium text-base mb-2">{post.post.title}</h3>

              <div className="flex justify-between items-center mt-3 text-gray-500">
                <div className="flex items-center">
                  <button
                    className={`p-1 rounded-full hover:bg-gray-100 ${post.liked ? "text-red-500" : ""}`}
                    onClick={(e) => onLike && onLike(post.id, e)}
                    aria-label="Me gusta"
                  >
                    <Heart className="h-5 w-5" fill={post.liked ? "currentColor" : "none"} />
                  </button>
                </div>
                <div className="relative">
                  {saveAnimation && (
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 animate-fade-up">
                      <CheckCircle className="h-6 w-6 text-green-500" />
                    </div>
                  )}
                  <button
                    className={`p-1 rounded-full hover:bg-gray-100 ${post.saved ? "text-blue-500" : ""} ${
                      saveAnimation ? "animate-bounce-once" : ""
                    }`}
                    onClick={(e) => handleSave(post.id, e)}
                    aria-label="Guardar"
                  >
                    <BookmarkPlus className="h-5 w-5" fill={post.saved ? "currentColor" : "none"} />
                  </button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>

      {/* Modal de perfil de usuario */}
      <UserProfilePlaceholder
        isOpen={showUserProfile}
        onClose={() => setShowUserProfile(false)}
        user={{
          id: post.user.id,
          name: post.user.name,
          image: post.user.image,
          location: post.user.location,
          verified: post.user.verified,
          rating: post.stats.rating,
          recommendations: post.stats.recommendations,
          badges: post.stats.badges,
          profession: post.post.category,
          description: post.post.title,
        }}
      />
    </SwipeableCard>
  )
}
