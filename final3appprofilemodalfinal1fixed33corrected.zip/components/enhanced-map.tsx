"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { MinusIcon, PlusIcon } from "lucide-react"

interface EnhancedMapProps {
  initialZoom?: number
  minZoom?: number
  maxZoom?: number
  mapImage?: string
}

export default function EnhancedMap({
  initialZoom = 1,
  minZoom = 0.5,
  maxZoom = 2,
  mapImage = "/placeholder.svg?height=600&width=800",
}: EnhancedMapProps) {
  const [zoom, setZoom] = useState(initialZoom)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const mapContainerRef = useRef<HTMLDivElement>(null)

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.1, maxZoom))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.1, minZoom))
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setDragStart({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    })
  }

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true)
      setDragStart({
        x: e.touches[0].clientX - position.x,
        y: e.touches[0].clientY - position.y,
      })
    }
  }

  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      })
    }
  }

  const handleTouchMove = (e: TouchEvent) => {
    if (isDragging && e.touches.length === 1) {
      setPosition({
        x: e.touches[0].clientX - dragStart.x,
        y: e.touches[0].clientY - dragStart.y,
      })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleWheel = (e: WheelEvent) => {
    e.preventDefault()
    const delta = -e.deltaY * 0.01
    const newZoom = Math.max(minZoom, Math.min(maxZoom, zoom + delta))
    setZoom(newZoom)
  }

  useEffect(() => {
    const mapContainer = mapContainerRef.current

    if (mapContainer) {
      mapContainer.addEventListener("wheel", handleWheel, { passive: false })
      window.addEventListener("mousemove", handleMouseMove)
      window.addEventListener("mouseup", handleMouseUp)
      window.addEventListener("touchmove", handleTouchMove)
      window.addEventListener("touchend", handleMouseUp)
    }

    return () => {
      if (mapContainer) {
        mapContainer.removeEventListener("wheel", handleWheel)
      }
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("mouseup", handleMouseUp)
      window.removeEventListener("touchmove", handleTouchMove)
      window.removeEventListener("touchend", handleMouseUp)
    }
  }, [isDragging, dragStart, zoom])

  return (
    <div className="relative h-[calc(100vh-120px)] overflow-hidden bg-gray-100 rounded-lg">
      <div
        ref={mapContainerRef}
        className="h-full w-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
        style={{
          overflow: "hidden",
          touchAction: "none",
        }}
      >
        <div
          style={{
            transform: `translate(${position.x}px, ${position.y}px) scale(${zoom})`,
            transformOrigin: "center",
            transition: isDragging ? "none" : "transform 0.1s ease-out",
            height: "100%",
            width: "100%",
            backgroundImage: `url(${mapImage})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
      </div>

      <div className="absolute bottom-6 right-6 flex flex-col gap-2">
        <Button variant="secondary" size="icon" className="rounded-full bg-white shadow-md" onClick={handleZoomIn}>
          <PlusIcon className="h-5 w-5" />
        </Button>
        <Button variant="secondary" size="icon" className="rounded-full bg-white shadow-md" onClick={handleZoomOut}>
          <MinusIcon className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
