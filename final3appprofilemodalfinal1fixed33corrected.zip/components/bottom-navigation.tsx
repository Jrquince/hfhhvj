"use client"

import Link from "next/link"
import { Home, Search, PlusCircle, MessageCircle, User } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { usePathname } from "next/navigation"

interface BottomNavigationProps {
  activeItem?: "home" | "search" | "create" | "chats" | "profile"
  unreadMessages?: number
  newSavedRequests?: boolean
  refreshHome?: () => void
  onNotificationClick?: () => void
  hidden?: boolean
}

export function BottomNavigation({
  activeItem,
  unreadMessages = 0,
  newSavedRequests = false,
  refreshHome,
  onNotificationClick,
  hidden = false,
}: BottomNavigationProps) {
  const { toast } = useToast()
  const pathname = usePathname()

  const handleRefreshHome = () => {
    if (refreshHome && activeItem === "home") {
      refreshHome()
    }
  }

  // Ocultar la barra de navegación en la ruta /chats
  if (hidden || pathname === "/chats") {
    return null
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-2 px-6 z-40 bottom-navigation">
      <div className="max-w-md mx-auto flex justify-between items-center px-4 py-2">
        <Link href="/" onClick={handleRefreshHome}>
          <div
            className={`flex flex-col items-center p-2 ${activeItem === "home" ? "text-yellow-500" : "text-gray-500"}`}
          >
            <Home className="h-6 w-6" />
            <span className="text-xs mt-1">Inicio</span>
          </div>
        </Link>

        <Link href="/map">
          <div
            className={`flex flex-col items-center p-2 ${
              activeItem === "search" ? "text-yellow-500" : "text-gray-500"
            }`}
          >
            <Search className="h-6 w-6" />
            <span className="text-xs mt-1">Explorar</span>
          </div>
        </Link>

        <Link href="/create-post">
          <div
            className={`flex flex-col items-center p-2 ${
              activeItem === "create" ? "text-yellow-500" : "text-gray-500"
            }`}
          >
            <PlusCircle className="h-6 w-6" />
            <span className="text-xs mt-1">Crear</span>
          </div>
        </Link>

        <Link href="/chats">
          <div
            className={`flex flex-col items-center p-2 relative ${
              activeItem === "chats" ? "text-yellow-500" : "text-gray-500"
            }`}
          >
            <MessageCircle className="h-6 w-6" />
            {unreadMessages > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                {unreadMessages}
              </span>
            )}
            <span className="text-xs mt-1">Chats</span>
          </div>
        </Link>

        <Link href="/profile">
          <div
            className={`flex flex-col items-center p-2 relative ${
              activeItem === "profile" ? "text-yellow-500" : "text-gray-500"
            }`}
          >
            <User className="h-6 w-6" />
            {newSavedRequests && <span className="absolute -top-1 -right-1 bg-yellow-500 w-2 h-2 rounded-full"></span>}
            <span className="text-xs mt-1">Perfil</span>
          </div>
        </Link>
      </div>
    </div>
  )
}
