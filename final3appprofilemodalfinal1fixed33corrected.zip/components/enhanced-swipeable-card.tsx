"use client"

import type React from "react"
import { useState, useRef } from "react"
import { motion } from "framer-motion"
import { Star, Award, ThumbsUp, ArrowLeft, BadgeCheck, Clock, Zap } from "lucide-react"

interface EnhancedSwipeableCardProps {
  children: React.ReactNode
  stats: {
    rating: number
    badges: number
    recommendations: number
  }
}

export default function EnhancedSwipeableCard({ children, stats }: EnhancedSwipeableCardProps) {
  const [isFlipped, setIsFlipped] = useState(false)
  const cardRef = useRef<HTMLDivElement>(null)

  const handleDrag = (_: any, info: any) => {
    if (info.offset.x < -100 && !isFlipped) {
      setIsFlipped(true)
    } else if (info.offset.x > 100 && isFlipped) {
      setIsFlipped(false)
    }
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return "text-green-500"
    if (rating >= 3.5) return "text-amber-500"
    return "text-red-500"
  }

  return (
    <div className="relative w-full h-full">
      <motion.div
        className="absolute inset-0 rounded-xl overflow-hidden"
        initial={false}
        animate={{
          rotateY: isFlipped ? 180 : 0,
          zIndex: isFlipped ? 0 : 10,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        onDragEnd={handleDrag}
        dragElastic={0.2}
      >
        <div className="absolute inset-0">
          {children}
          <button
            onClick={() => setIsFlipped(true)}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white shadow-lg hover:shadow-xl rounded-full p-2 transition-all duration-300 transform hover:scale-105 z-10"
            aria-label="Ver estadísticas"
          >
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
        </div>
      </motion.div>

      <motion.div
        className="absolute inset-0 rounded-xl overflow-hidden"
        initial={false}
        animate={{
          rotateY: isFlipped ? 0 : -180,
          zIndex: isFlipped ? 10 : 0,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        style={{ backfaceVisibility: "hidden" }}
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        onDragEnd={handleDrag}
        dragElastic={0.2}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-white to-gray-50 shadow-lg">
          {/* Header */}
          <div className="bg-gradient-to-r from-amber-500 to-orange-500 p-4 flex justify-between items-center">
            <h3 className="text-lg font-bold text-white">Perfil Profesional</h3>
            <button
              onClick={() => setIsFlipped(false)}
              className="bg-white/20 hover:bg-white/40 rounded-full p-2 transition-all duration-300"
              aria-label="Volver"
            >
              <ArrowLeft className="h-5 w-5 text-white" />
            </button>
          </div>

          {/* Content */}
          <div className="p-5 space-y-6">
            {/* Rating */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-br from-amber-400 to-amber-600 rounded-full p-3 shadow-lg">
                  <Star className="h-6 w-6 text-white fill-white" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Valoración</p>
                  <p className={`text-2xl font-bold ${getRatingColor(stats.rating)}`}>{stats.rating.toFixed(1)}</p>
                </div>
              </div>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`h-5 w-5 ${
                      star <= Math.floor(stats.rating)
                        ? "text-amber-400 fill-amber-400"
                        : star <= stats.rating
                          ? "text-amber-400 fill-amber-400 opacity-50"
                          : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Divider */}
            <div className="h-px bg-gradient-to-r from-transparent via-gray-300 to-transparent" />

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 shadow-sm transform transition-transform hover:scale-105 hover:shadow-md">
                <div className="flex items-center gap-3 mb-2">
                  <div className="bg-blue-500 rounded-full p-2">
                    <Award className="h-4 w-4 text-white" />
                  </div>
                  <p className="text-sm font-medium text-blue-700">Insignias</p>
                </div>
                <p className="text-3xl font-bold text-blue-800">{stats.badges}</p>
                <div className="mt-2 flex gap-1">
                  {Array(Math.min(stats.badges, 5))
                    .fill(0)
                    .map((_, i) => (
                      <BadgeCheck key={i} className="h-4 w-4 text-blue-500" />
                    ))}
                </div>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4 shadow-sm transform transition-transform hover:scale-105 hover:shadow-md">
                <div className="flex items-center gap-3 mb-2">
                  <div className="bg-green-500 rounded-full p-2">
                    <ThumbsUp className="h-4 w-4 text-white" />
                  </div>
                  <p className="text-sm font-medium text-green-700">Recomendaciones</p>
                </div>
                <p className="text-3xl font-bold text-green-800">{stats.recommendations}</p>
                <p className="text-xs text-green-600 mt-2">
                  {stats.recommendations > 10 ? "Altamente recomendado" : "Recomendado"}
                </p>
              </div>
            </div>

            {/* Additional stats */}
            <div className="space-y-4 mt-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-purple-500" />
                  <span className="text-sm text-gray-600">Tiempo de respuesta</span>
                </div>
                <span className="text-sm font-bold text-purple-700">{"< 1 hora"}</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-amber-500" />
                  <span className="text-sm text-gray-600">Tasa de finalización</span>
                </div>
                <span className="text-sm font-bold text-amber-700">98%</span>
              </div>
            </div>

            {/* Social proof */}
            <div className="bg-gradient-to-r from-amber-100 to-orange-100 rounded-xl p-4 border border-amber-200 mt-4">
              <p className="text-center text-amber-800 font-medium">
                <span className="font-bold">{stats.recommendations} usuarios</span> recomiendan este profesional
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
