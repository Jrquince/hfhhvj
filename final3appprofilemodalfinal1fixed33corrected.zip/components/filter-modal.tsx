"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Filter, MapPin, Euro, Star, Clock, X } from "lucide-react"

interface FilterModalProps {
  isOpen: boolean
  onClose: () => void
  onApplyFilters: (filters: any) => void
  initialFilters?: any
  filterType?: "home" | "map" | "search"
}

export function FilterModal(props: FilterModalProps) {
  // Extraer props para mayor claridad
  const { isOpen, onClose, onApplyFilters, initialFilters = {}, filterType = "home" } = props

  // Estados locales
  const [activeCategory, setActiveCategory] = useState(initialFilters.category || "Todos")
  const [priceRange, setPriceRange] = useState(initialFilters.priceRange || [0, 100])
  const [rating, setRating] = useState(initialFilters.rating || 0)
  const [distance, setDistance] = useState(initialFilters.distance || 10)
  const [availability, setAvailability] = useState(initialFilters.availability || "Cualquier momento")

  // Función para aplicar filtros
  const handleApplyFilters = () => {
    const filters = {
      category: activeCategory,
      priceRange,
      rating,
      distance,
      availability,
    }
    onApplyFilters(filters)
    onClose()
  }

  // Función para resetear filtros
  const handleResetFilters = () => {
    setActiveCategory("Todos")
    setPriceRange([0, 100])
    setRating(0)
    setDistance(10)
    setAvailability("Cualquier momento")
  }

  // Categorías para filtros
  const categories = [
    "Todos",
    "Limpieza",
    "Fontanería",
    "Electricidad",
    "Pintura",
    "Carpintería",
    "Jardinería",
    "Mudanzas",
    "Reformas",
  ]

  const availabilityOptions = ["Hoy", "Mañana", "Esta semana", "Este mes", "Cualquier momento"]
  const timeSlots = ["Mañana", "Tarde", "Noche", "Cualquier hora"]

  // Si no está abierto, no renderizar nada
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Overlay - capa oscura de fondo */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />

      {/* Contenido del modal */}
      <div className="relative w-[90%] max-w-md bg-white rounded-xl shadow-2xl border border-gray-200 flex flex-col max-h-[85vh] overflow-hidden">
        {/* Botón X para cerrar - diseño limpio */}
        <button
          type="button"
          onClick={onClose}
          className="absolute right-3 top-3 p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors z-10"
          aria-label="Cerrar modal"
        >
          <X className="h-4 w-4 text-gray-700" />
        </button>

        <div className="p-4 border-b">
          <div className="text-lg font-semibold flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-black flex items-center justify-center text-white">
              <Filter className="h-3.5 w-3.5" />
            </div>
            <span>Filtros avanzados</span>
          </div>
          <p className="text-xs text-gray-500 mt-1 ml-9">Personaliza tu búsqueda con filtros específicos</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Categoría */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-1.5">Categoría</h3>
            <p className="text-xs text-gray-500 mb-2">Selecciona la categoría de servicios que estás buscando</p>
            <div className="grid grid-cols-2 gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant="outline"
                  size="sm"
                  className={`rounded-full text-xs ${
                    activeCategory === category
                      ? "bg-black text-white border-transparent hover:bg-gray-800"
                      : "border-gray-200 text-gray-700"
                  }`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Ubicación */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
              <MapPin className="h-4 w-4 mr-1 text-gray-400" />
              Ubicación
            </h3>
            <p className="text-xs text-gray-500 mb-3">Filtra por ubicación o establece un radio de distancia</p>
            <Input placeholder="Cualquier ubicación" className="rounded-lg text-sm mb-2 border-gray-200" />
            <div className="mt-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-gray-700">Radio de distancia: {distance} km</span>
              </div>
              <input
                type="range"
                min="1"
                max="50"
                value={distance}
                onChange={(e) => setDistance(Number.parseInt(e.target.value))}
                className="w-full accent-black"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>1 km</span>
                <span>50 km</span>
              </div>
            </div>
          </div>

          {/* Precio */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
              <Euro className="h-4 w-4 mr-1 text-gray-400" />
              Precio
            </h3>
            <p className="text-xs text-gray-500 mb-3">Filtra por rango de precios o nivel de precio</p>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                className={`rounded-full text-xs flex-1 ${
                  priceRange[1] <= 25 ? "bg-black text-white border-transparent" : ""
                }`}
                onClick={() => setPriceRange([0, 25])}
              >
                €
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={`rounded-full text-xs flex-1 ${
                  priceRange[0] >= 25 && priceRange[1] <= 50 ? "bg-black text-white border-transparent" : ""
                }`}
                onClick={() => setPriceRange([25, 50])}
              >
                €€
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={`rounded-full text-xs flex-1 ${
                  priceRange[0] >= 50 ? "bg-black text-white border-transparent" : ""
                }`}
                onClick={() => setPriceRange([50, 100])}
              >
                €€€
              </Button>
            </div>
            <div className="mt-3">
              <div className="flex justify-between">
                <Input
                  placeholder="Min €"
                  type="number"
                  value={priceRange[0]}
                  onChange={(e) => setPriceRange([Number.parseInt(e.target.value) || 0, priceRange[1]])}
                  className="w-[48%] rounded-lg text-sm border-gray-200"
                />
                <Input
                  placeholder="Max €"
                  type="number"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], Number.parseInt(e.target.value) || 100])}
                  className="w-[48%] rounded-lg text-sm border-gray-200"
                />
              </div>
            </div>
          </div>

          {/* Valoración */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
              <Star className="h-4 w-4 mr-1 text-gray-400" />
              Valoración
            </h3>
            <p className="text-xs text-gray-500 mb-3">Filtra por valoración mínima de los usuarios</p>
            <div className="flex space-x-2">
              {[1, 2, 3, 4, 5].map((value) => (
                <Button
                  key={value}
                  variant="outline"
                  size="sm"
                  className={`rounded-full text-xs flex-1 ${
                    rating === value ? "bg-black text-white border-transparent" : ""
                  }`}
                  onClick={() => setRating(value)}
                >
                  {value}★
                </Button>
              ))}
            </div>
          </div>

          {/* Disponibilidad */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
              <Clock className="h-4 w-4 mr-1 text-gray-400" />
              Disponibilidad
            </h3>
            <p className="text-xs text-gray-500 mb-3">Filtra por disponibilidad de fecha y hora</p>
            <div className="grid grid-cols-2 gap-2 mb-3">
              {availabilityOptions.map((option) => (
                <Button
                  key={option}
                  variant="outline"
                  size="sm"
                  className={`rounded-full text-xs ${
                    availability === option ? "bg-black text-white border-transparent" : ""
                  }`}
                  onClick={() => setAvailability(option)}
                >
                  {option}
                </Button>
              ))}
            </div>
            <h4 className="text-xs text-gray-700 mb-1">Franja horaria</h4>
            <div className="grid grid-cols-2 gap-2">
              {timeSlots.map((slot) => (
                <Button key={slot} variant="outline" size="sm" className="rounded-full text-xs">
                  {slot}
                </Button>
              ))}
            </div>
          </div>
        </div>

        <div className="p-4 border-t">
          <div className="flex space-x-3">
            <Button
              variant="outline"
              className="flex-1 rounded-lg border-gray-200 text-sm py-1.5"
              onClick={handleResetFilters}
            >
              Limpiar filtros
            </Button>
            <Button
              className="flex-1 rounded-lg bg-yellow-500 hover:bg-yellow-600 text-white text-sm py-1.5"
              onClick={handleApplyFilters}
            >
              Aplicar filtros
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default FilterModal
