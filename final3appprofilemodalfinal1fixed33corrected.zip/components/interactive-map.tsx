"use client"

import { useEffect, useRef, useState, forwardRef, useImperativeHandle } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { MapContainer, TileLayer, Marker, useMap, ZoomControl } from "react-leaflet"

// Definir tipos para los marcadores
type MarkerUser = {
  id: number
  name: string
  verified: boolean
  image: string
}

type MapMarker = {
  id: number
  type: "ad" | "service" | "need" | "user"
  lat: number
  lng: number
  title: string
  price: number | string
  rating?: number
  reviews?: number
  user: MarkerUser
  location: string
  category: string
  description: string
  icon?: string
}

// Props para el componente
interface InteractiveMapProps {
  markers: MapMarker[]
  onMarkerClick?: (markerId: number) => void
  selectedMarkerId?: number | null
  showPopupOnMap?: boolean
  enableZoom?: boolean
  enableDrag?: boolean
}

// Componente para centrar el mapa en una ubicación específica
function SetViewOnClick({ coords }: { coords: [number, number] }) {
  const map = useMap()
  useEffect(() => {
    map.setView(coords, map.getZoom())
  }, [coords, map])
  return null
}

// Componente para el popup personalizado
function CustomPopup({ marker, onClose }: { marker: MapMarker; onClose: () => void }) {
  if (!marker) return null

  return (
    <div
      className="absolute top-1/4 left-1/2 transform -translate-x-1/2 z-30 bg-yellow-400 rounded-xl shadow-lg p-3"
      style={{ minWidth: "250px", maxWidth: "80%" }}
    >
      <div className="flex items-center gap-2 mb-1">
        <div className="h-10 w-10 rounded-full overflow-hidden bg-gray-200">
          <img
            src={marker.user.image || "/placeholder.svg"}
            alt={marker.user.name}
            className="h-full w-full object-cover"
          />
        </div>
        <div>
          <h3 className="font-bold">{marker.user.name}</h3>
          <div className="flex">{"★★★★★"}</div>
        </div>
      </div>
      <p className="text-sm">{marker.description}</p>
      <p className="text-sm font-medium mt-1">{marker.location}</p>
    </div>
  )
}

// Update the component definition to use forwardRef
const InteractiveMap = forwardRef<any, InteractiveMapProps>(
  ({ markers, onMarkerClick, selectedMarkerId, showPopupOnMap = false, enableZoom = true, enableDrag = true }, ref) => {
    const [center, setCenter] = useState<[number, number]>([43.263, -2.935]) // Bilbao
    const mapRef = useRef<L.Map | null>(null)
    const [mapReady, setMapReady] = useState(false)
    const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null)

    // Expose the map instance to parent components
    useImperativeHandle(ref, () => ({
      getMap: () => mapRef.current,
      getCenter: () => mapRef.current?.getCenter(),
      getBounds: () => mapRef.current?.getBounds(),
    }))

    // Actualizar el marcador seleccionado cuando cambia el ID
    useEffect(() => {
      if (selectedMarkerId) {
        const marker = markers.find((m) => m.id === selectedMarkerId) || null
        setSelectedMarker(marker)
      } else {
        setSelectedMarker(null)
      }
    }, [selectedMarkerId, markers])

    // Crear iconos personalizados para los marcadores
    useEffect(() => {
      if (typeof window !== "undefined" && !mapReady) {
        setMapReady(true)
      }
    }, [mapReady])

    // Manejar el clic en un marcador
    const handleMarkerClick = (markerId: number) => {
      if (onMarkerClick) {
        onMarkerClick(markerId)
      }
    }

    // Función para obtener el icono según el tipo de servicio
    const getIconForMarker = (marker: MapMarker) => {
      // Determinar el color de fondo según el tipo de marcador
      let bgColor = "#4B5563" // Color gris neutro por defecto

      if (marker.type === "ad")
        bgColor = "#6366F1" // Indigo para anuncios
      else if (marker.type === "service")
        bgColor = "#10B981" // Verde para servicios
      else if (marker.type === "need") bgColor = "#F59E0B" // Ámbar para necesidades

      // Obtener el SVG correspondiente al icono
      let iconSvg = ""

      switch (marker.icon) {
        case "tool":
          iconSvg =
            '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>'
          break
        case "scissors":
          iconSvg =
            '<circle cx="6" cy="6" r="3"></circle><circle cx="6" cy="18" r="3"></circle><line x1="20" y1="4" x2="8.12" y2="15.88"></line><line x1="14.47" y1="14.48" x2="20" y2="20"></line><line x1="8.12" y1="8.12" x2="12" y2="12"></line>'
          break
        case "book":
          iconSvg =
            '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>'
          break
        case "heart":
          iconSvg =
            '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>'
          break
        case "palette":
          iconSvg =
            '<circle cx="13.5" cy="6.5" r=".5"></circle><circle cx="17.5" cy="10.5" r=".5"></circle><circle cx="8.5" cy="7.5" r=".5"></circle><circle cx="6.5" cy="12.5" r=".5"></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path>'
          break
        case "briefcase":
          iconSvg =
            '<rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>'
          break
        case "home":
          iconSvg =
            '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>'
          break
        case "education":
          iconSvg = '<path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path>'
          break
        default:
          // Icono de ubicación por defecto
          iconSvg =
            '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle>'
      }

      return L.divIcon({
        html: `
          <div style="
            background-color: ${bgColor}; 
            width: 32px; 
            height: 32px; 
            border-radius: 50%; 
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
            border: 2px solid white;
          ">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              ${iconSvg}
            </svg>
          </div>
        `,
        className: "",
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32],
      })
    }

    if (typeof window === "undefined") {
      return null // No renderizar en el servidor
    }

    return (
      <div className="h-full w-full relative">
        {mapReady && (
          <MapContainer
            center={center}
            zoom={14}
            style={{ height: "100%", width: "100%" }}
            zoomControl={false}
            attributionControl={false}
            dragging={enableDrag}
            touchZoom={enableZoom}
            doubleClickZoom={enableZoom}
            scrollWheelZoom={enableZoom}
            boxZoom={enableZoom}
            keyboard={enableZoom}
            whenReady={(map) => {
              mapRef.current = map.target
            }}
          >
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            {enableZoom && <ZoomControl position="bottomright" />}
            <SetViewOnClick coords={center} />

            {markers.map((marker) => (
              <Marker
                key={marker.id}
                position={[marker.lat, marker.lng]}
                icon={getIconForMarker(marker)}
                eventHandlers={{
                  click: () => handleMarkerClick(marker.id),
                }}
              />
            ))}
          </MapContainer>
        )}

        {/* Popup personalizado */}
        {showPopupOnMap && selectedMarker && (
          <CustomPopup marker={selectedMarker} onClose={() => onMarkerClick && onMarkerClick(selectedMarker.id)} />
        )}
      </div>
    )
  },
)

// Add display name
InteractiveMap.displayName = "InteractiveMap"

export default InteractiveMap
