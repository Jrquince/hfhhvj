"use client"

import { X } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

interface MessageNotificationProps {
  sender: {
    name: string
    image: string
    id: string
  }
  message: string
  onClose: () => void
}

export default function MessageNotification({ sender, message, onClose }: MessageNotificationProps) {
  return (
    <div className="fixed top-20 left-0 right-0 mx-4 bg-white rounded-xl p-4 shadow-lg border z-30 animate-slideDown">
      <div className="flex justify-between items-start">
        <Link href={`/chat-detail/${sender.id}`} className="flex items-center flex-1">
          <div className="relative w-10 h-10 rounded-full overflow-hidden">
            <Image
              src={sender.image || "/placeholder.svg"}
              alt={sender.name}
              width={40}
              height={40}
              className="object-cover"
            />
          </div>
          <div className="ml-3 flex-1">
            <h3 className="font-medium text-sm">{sender.name}</h3>
            <p className="text-xs text-gray-600 line-clamp-1">{message}</p>
          </div>
        </Link>
        <Button variant="ghost" size="sm" className="h-6 w-6 p-0 ml-2" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div className="flex space-x-2 mt-3">
        <Link href={`/chat-detail/${sender.id}`} className="flex-1">
          <Button size="sm" className="w-full rounded-full text-xs bg-yellow-500 hover:bg-yellow-600">
            Responder
          </Button>
        </Link>
      </div>
    </div>
  )
}
