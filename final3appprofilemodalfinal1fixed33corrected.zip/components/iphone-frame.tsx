import type React from "react"

interface IPhoneFrameProps {
  children: React.ReactNode
}

export function IPhoneFrame({ children }: IPhoneFrameProps) {
  return (
    <div className="relative mx-auto my-8 w-[390px]">
      {/* iPhone frame */}
      <div className="rounded-[50px] bg-black p-2 shadow-xl">
        <div className="rounded-[44px] overflow-hidden border-[12px] border-black bg-white">
          {/* Notch */}
          <div className="relative">
            <div className="absolute left-1/2 top-0 z-50 h-7 w-40 -translate-x-1/2 rounded-b-3xl bg-black"></div>
            {/* Status bar */}
            <div className="flex h-12 w-full items-center justify-between bg-black px-8 pt-1 text-white">
              <span className="text-sm">9:41</span>
              <div className="flex items-center space-x-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 10a6 6 0 0 0-12 0v5a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-5Z" />
                  <path d="M19 8a8 8 0 0 0-16 0" />
                  <path d="M12 18v2" />
                </svg>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M6 18h8" />
                  <path d="M10 22v-4" />
                  <path d="M18 15v3" />
                  <path d="M18 9V6a4 4 0 0 0-4-4H6v8H2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5" />
                </svg>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M5 12.55a11 11 0 0 1 14.08 0" />
                  <path d="M1.42 9a16 16 0 0 1 21.16 0" />
                  <path d="M8.53 16.11a6 6 0 0 1 6.95 0" />
                  <path d="M12 20h.01" />
                </svg>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  stroke="currentColor"
                  strokeWidth="0"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="7" y="4" width="10" height="16" rx="1" />
                  <path d="M7 7h10" stroke="white" strokeWidth="1" />
                  <path d="M7 12h10" stroke="white" strokeWidth="1" />
                  <path d="M7 17h10" stroke="white" strokeWidth="1" />
                </svg>
              </div>
            </div>
          </div>

          {/* App content */}
          <div className="h-[700px] overflow-y-auto">{children}</div>

          {/* Home indicator */}
          <div className="flex h-10 items-center justify-center bg-white">
            <div className="h-1.5 w-32 rounded-full bg-gray-300"></div>
          </div>
        </div>
      </div>
    </div>
  )
}
