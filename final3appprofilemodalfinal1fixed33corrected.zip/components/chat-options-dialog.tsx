"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { RatingDialog } from "@/components/rating-dialog"
import { ReportDialog } from "@/components/report-dialog"

interface ChatOptionsDialogProps {
  isOpen: boolean
  onClose: () => void
}

export const ChatOptionsDialog = ({ isOpen, onClose }: ChatOptionsDialogProps) => {
  const router = useRouter()
  const [showRatingDialog, setShowRatingDialog] = useState(false)
  const [showReportDialog, setShowReportDialog] = useState(false)

  const handleFinishChat = () => {
    router.push("/chat-detail/1/finalizado")
    onClose()
  }

  const handleRateService = () => {
    setShowRatingDialog(true)
    onClose()
  }

  const handleReport = () => {
    setShowReportDialog(true)
    onClose()
  }

  const handleRatingSubmit = (rating: number) => {
    console.log("Rating submitted:", rating)
    setShowRatingDialog(false)
  }

  const handleReportSubmit = (reason: string, details: string) => {
    console.log("Report submitted:", { reason, details })
    setShowReportDialog(false)
  }

  return (
    <>
      <AlertDialog open={isOpen} onOpenChange={onClose}>
        <AlertDialogContent className="bg-white p-4 rounded-lg max-w-md mx-auto max-h-[90vh] overflow-hidden">
          <AlertDialogHeader className="pb-2">
            <AlertDialogTitle className="text-lg font-semibold text-center">Opciones de chat</AlertDialogTitle>
            <AlertDialogDescription className="text-center text-gray-500 text-sm">
              Selecciona una acción para este chat
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex flex-col space-y-2 my-3">
            <button
              onClick={handleFinishChat}
              className="w-full py-3 px-4 bg-gray-100 hover:bg-gray-200 rounded-lg text-left font-medium transition"
            >
              Finalizar servicio
            </button>
            <button
              onClick={handleRateService}
              className="w-full py-3 px-4 bg-gray-100 hover:bg-gray-200 rounded-lg text-left font-medium transition"
            >
              Valorar servicio
            </button>
            <button
              onClick={handleReport}
              className="w-full py-3 px-4 bg-gray-100 hover:bg-gray-200 rounded-lg text-left font-medium text-red-600 transition"
            >
              Reportar problema
            </button>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel className="w-full">Cancelar</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <RatingDialog
        isOpen={showRatingDialog}
        onClose={() => setShowRatingDialog(false)}
        onSubmit={handleRatingSubmit}
      />

      <ReportDialog
        isOpen={showReportDialog}
        onClose={() => setShowReportDialog(false)}
        onSubmit={handleReportSubmit}
      />
    </>
  )
}
