"use client"

import { useModal } from "@/hooks/use-modal-store"
import ProfileModal from "./profile-modal"

export const ModalProvider = () => {
  const { data } = useModal()

  return (
    <>
      <ProfileModal />
      {/* Aquí se pueden añadir otros modales en el futuro */}
    </>
  )
}
