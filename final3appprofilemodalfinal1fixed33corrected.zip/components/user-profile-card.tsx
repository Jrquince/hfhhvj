"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, MapPin, Clock, Award, CheckCircle } from "lucide-react"
import { ProfileAvatar } from "@/components/profile-avatar"
import { getConsistentProfileImage } from "@/utils/profile-images"

interface UserProfileCardProps {
  username: string
  userId: string | number
  profileImage?: string
  rating?: number
  location?: string
  responseTime?: string
  specialties?: string[]
  verified?: boolean
  premium?: boolean
  onContact?: () => void
  onViewProfile?: () => void
}

export function UserProfileCard({
  username,
  userId,
  profileImage,
  rating = 4.8,
  location = "Bilbao",
  responseTime = "< 1 hora",
  specialties = ["Fontanería", "Electricidad", "Carpintería"],
  verified = true,
  premium = true,
  onContact,
  onViewProfile,
}: UserProfileCardProps) {
  // Usar la imagen proporcionada o generar una consistente basada en el userId
  const avatarSrc = profileImage || getConsistentProfileImage(userId)

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <ProfileAvatar
              src={avatarSrc}
              userId={userId}
              fallback={username[0]}
              size="lg"
              className="border-2 border-white shadow-sm"
            />
            <div className="ml-3">
              <div className="flex items-center">
                <h3 className="font-semibold text-lg">{username}</h3>
                {verified && <CheckCircle className="h-4 w-4 text-blue-500 ml-1" />}
                {premium && (
                  <Badge variant="outline" className="ml-2 bg-yellow-100 text-yellow-800 border-yellow-300">
                    Premium
                  </Badge>
                )}
              </div>
              <div className="flex items-center text-sm text-gray-500">
                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                <span>{rating}</span>
                <span className="mx-2">•</span>
                <MapPin className="h-4 w-4 mr-1" />
                <span>{location}</span>
              </div>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="flex items-center text-sm text-gray-600 mb-2">
            <Clock className="h-4 w-4 mr-2" />
            <span>Responde en {responseTime}</span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <Award className="h-4 w-4 mr-2" />
            <span>Especialidades:</span>
          </div>
          <div className="flex flex-wrap gap-1 mt-1">
            {specialties.map((specialty, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {specialty}
              </Badge>
            ))}
          </div>
        </div>
        <div className="flex justify-between gap-2">
          <Button variant="outline" className="flex-1" onClick={onViewProfile}>
            Ver perfil
          </Button>
          <Button className="flex-1 bg-blue-600 hover:bg-blue-700" onClick={onContact}>
            Contactar
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
