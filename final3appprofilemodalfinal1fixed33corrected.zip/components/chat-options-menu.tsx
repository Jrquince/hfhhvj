"use client"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import {
  MoreVertical,
  Flag,
  Share,
  Trash,
  MessageSquareX,
  UserX,
  Volume2Icon as Volume2Off,
  ChevronRight,
} from "lucide-react"
import { useState } from "react"

interface ChatOptionsMenuProps {
  username: string
}

export default function ChatOptionsMenu({ username }: ChatOptionsMenuProps) {
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false)
  const [reportReason, setReportReason] = useState("")
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false)

  const handleReport = () => {
    // Simular envío del reporte
    console.log(`Perfil reportado: ${username}, Motivo: ${reportReason}`)
    setIsReportDialogOpen(false)
  }

  const handleShare = (method: string) => {
    // Simular compartir por el método seleccionado
    console.log(`Perfil compartido: ${username}, Método: ${method}`)
    setIsShareDialogOpen(false)
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
            <span className="sr-only">Más opciones</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setIsReportDialogOpen(true)}>
            <Flag className="h-4 w-4 mr-2 text-red-500" />
            <span>Denunciar perfil</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setIsShareDialogOpen(true)}>
            <Share className="h-4 w-4 mr-2 text-blue-500" />
            <span>Compartir perfil</span>
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem>
            <MessageSquareX className="h-4 w-4 mr-2 text-gray-500" />
            <span>Archivar chat</span>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Volume2Off className="h-4 w-4 mr-2 text-gray-500" />
            <span>Silenciar notificaciones</span>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <UserX className="h-4 w-4 mr-2 text-gray-500" />
            <span>Bloquear usuario</span>
          </DropdownMenuItem>
          <DropdownMenuItem className="text-red-600">
            <Trash className="h-4 w-4 mr-2" />
            <span>Eliminar chat</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Diálogo de denuncia */}
      <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Denunciar perfil</DialogTitle>
            <DialogDescription>
              Por favor, selecciona el motivo de la denuncia. Tu informe será revisado por nuestro equipo.
            </DialogDescription>
          </DialogHeader>

          <RadioGroup value={reportReason} onValueChange={setReportReason}>
            <div className="flex items-center space-x-2 py-2">
              <RadioGroupItem value="spam" id="spam" />
              <Label htmlFor="spam">Spam o contenido engañoso</Label>
            </div>
            <div className="flex items-center space-x-2 py-2">
              <RadioGroupItem value="inappropriate" id="inappropriate" />
              <Label htmlFor="inappropriate">Contenido inapropiado</Label>
            </div>
            <div className="flex items-center space-x-2 py-2">
              <RadioGroupItem value="fraud" id="fraud" />
              <Label htmlFor="fraud">Intento de fraude</Label>
            </div>
            <div className="flex items-center space-x-2 py-2">
              <RadioGroupItem value="fake" id="fake" />
              <Label htmlFor="fake">Perfil falso</Label>
            </div>
            <div className="flex items-center space-x-2 py-2">
              <RadioGroupItem value="other" id="other" />
              <Label htmlFor="other">Otro motivo</Label>
            </div>
          </RadioGroup>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsReportDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleReport} disabled={!reportReason} className="bg-red-500 hover:bg-red-600">
              Denunciar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de compartir */}
      <Dialog open={isShareDialogOpen} onOpenChange={setIsShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Compartir perfil</DialogTitle>
            <DialogDescription>Elige cómo quieres compartir este perfil</DialogDescription>
          </DialogHeader>

          <div className="space-y-2 py-4">
            <Button variant="outline" className="w-full justify-between" onClick={() => handleShare("whatsapp")}>
              <div className="flex items-center">
                <div className="bg-green-500 p-1.5 rounded-full mr-2">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M16.6 14.0001C16.4 13.9001 15.1 13.3001 14.9 13.2001C14.7 13.1001 14.5 13.1001 14.3 13.3001C14.1 13.5001 13.7 14.1001 13.5 14.3001C13.4 14.5001 13.2 14.5001 13 14.4001C12.3 14.1001 11.6 13.7001 11 13.2001C10.5 12.7001 10 12.1001 9.6 11.5001C9.5 11.3001 9.6 11.1001 9.7 11.0001C9.8 10.9001 9.9 10.7001 10.1 10.6001C10.2 10.5001 10.3 10.3001 10.3 10.2001C10.4 10.1001 10.4 9.9001 10.3 9.8001C10.2 9.7001 9.7 8.5001 9.5 8.0001C9.4 7.3001 9.2 7.3001 9 7.3001C8.9 7.3001 8.7 7.3001 8.5 7.3001C8.3 7.3001 8 7.5001 7.9 7.6001C7.3 8.2001 7 8.9001 7 9.7001C7.1 10.6001 7.4 11.5001 8 12.3001C9.1 13.9001 10.5 15.2001 12.2 16.0001C12.7 16.2001 13.1 16.4001 13.6 16.5001C14.1 16.7001 14.6 16.7001 15.2 16.6001C15.9 16.5001 16.5 16.0001 16.9 15.4001C17.1 15.0001 17.1 14.6001 17 14.2001C17 14.2001 16.8 14.1001 16.6 14.0001ZM19.1 4.9001C15.2 1.0001 8.9 1.0001 5 4.9001C1.8 8.1001 1.2 13.0001 3.4 16.9001L2 22.0001L7.3 20.6001C8.8 21.4001 10.4 21.8001 12 21.8001C17.5 21.8001 21.9 17.4001 21.9 11.9001C22 9.3001 20.9 6.8001 19.1 4.9001ZM16.4 18.9001C15.1 19.7001 13.6 20.2001 12 20.2001C10.5 20.2001 9.1 19.8001 7.8 19.1001L7.5 18.9001L4.4 19.7001L5.2 16.7001L5 16.4001C2.6 12.4001 3.8 7.4001 7.7 4.9001C11.6 2.4001 16.6 3.7001 19 7.5001C21.4 11.4001 20.3 16.5001 16.4 18.9001Z"
                      fill="white"
                    />
                  </svg>
                </div>
                <span>Compartir por WhatsApp</span>
              </div>
              <ChevronRight className="h-4 w-4" />
            </Button>

            <Button variant="outline" className="w-full justify-between" onClick={() => handleShare("telegram")}>
              <div className="flex items-center">
                <div className="bg-blue-500 p-1.5 rounded-full mr-2">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M19.2 4.4L2.9 10.7C1.8 11.1 1.8 11.6 2.7 11.9L7.1 13.4L16.5 7.2C16.9 7 17.3 7.1 17 7.4L9.4 14.1L9.1 18.1C9.5 18.1 9.7 17.9 9.9 17.7L12 15.8L16.5 19.1C17.2 19.5 17.7 19.3 17.9 18.5L20.9 5.5C21.2 4.4 20.5 4 19.2 4.4Z"
                      fill="white"
                    />
                  </svg>
                </div>
                <span>Compartir por Telegram</span>
              </div>
              <ChevronRight className="h-4 w-4" />
            </Button>

            <Button variant="outline" className="w-full justify-between" onClick={() => handleShare("email")}>
              <div className="flex items-center">
                <div className="bg-gray-500 p-1.5 rounded-full mr-2">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M20 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4ZM20 18H4V8L12 13L20 8V18ZM12 11L4 6H20L12 11Z"
                      fill="white"
                    />
                  </svg>
                </div>
                <span>Compartir por email</span>
              </div>
              <ChevronRight className="h-4 w-4" />
            </Button>

            <Button variant="outline" className="w-full justify-between" onClick={() => handleShare("copy")}>
              <div className="flex items-center">
                <div className="bg-yellow-500 p-1.5 rounded-full mr-2">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M16 1H4C2.9 1 2 1.9 2 3V17H4V3H16V1ZM19 5H8C6.9 5 6 5.9 6 7V21C6 22.1 6.9 23 8 23H19C20.1 23 21 22.1 21 21V7C21 5.9 20.1 5 19 5ZM19 21H8V7H19V21Z"
                      fill="white"
                    />
                  </svg>
                </div>
                <span>Copiar enlace</span>
              </div>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsShareDialogOpen(false)}>
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
