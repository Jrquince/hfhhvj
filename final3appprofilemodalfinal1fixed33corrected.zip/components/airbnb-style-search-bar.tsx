"use client"

import type React from "react"

import { useState } from "react"
import { MapPin, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { QuickIAModal } from "@/components/quickia-modal"

interface AirbnbStyleSearchBarProps {
  onSearch: (query: string) => void
  onQuickIAClick?: () => void
}

export function AirbnbStyleSearchBar({ onSearch, onQuickIAClick }: AirbnbStyleSearchBarProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [isQuickIAOpen, setIsQuickIAOpen] = useState(false)

  const handleSearch = () => {
    if (searchQuery.trim()) {
      onSearch(searchQuery)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  const handleQuickIAClick = () => {
    if (searchQuery.trim()) {
      onSearch(searchQuery)
    }

    if (onQuickIAClick) {
      onQuickIAClick()
    } else {
      setIsQuickIAOpen(true)
    }
  }

  return (
    <>
      <div className="flex items-center bg-white rounded-full shadow-md h-12 overflow-hidden">
        <div className="flex-1 flex items-center pl-4">
          <MapPin className="h-4 w-4 text-gray-400 mr-2" />
          <input
            type="text"
            placeholder="Buscar servicios, profesionales..."
            className="w-full border-none outline-none text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleKeyDown}
          />
        </div>
        <div className="flex items-center">
          <Button
            variant="ghost"
            size="sm"
            className="h-full rounded-none px-3 text-purple-600 hover:bg-purple-50 hover:text-purple-700 flex items-center gap-1"
            onClick={handleQuickIAClick}
          >
            <Sparkles className="h-4 w-4" />
            <span className="text-xs font-medium">QuickIA</span>
          </Button>
        </div>
      </div>

      <QuickIAModal
        open={isQuickIAOpen}
        onOpenChange={setIsQuickIAOpen}
        onSubmit={(content) => {
          setSearchQuery(content.title)
          onSearch(content.title)
        }}
        mode="map"
      />
    </>
  )
}
