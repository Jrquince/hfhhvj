"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, Check } from "lucide-react"

interface ProfileCardProps {
  service: any
  onClick: () => void
}

export default function ProfileCard({ service, onClick }: ProfileCardProps) {
  return (
    <Card className="overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={onClick}>
      <CardContent className="p-0">
        <div className="flex items-start space-x-3 p-3">
          {/* Imagen de perfil */}
          <div className="relative">
            <div className="h-12 w-12 rounded-full overflow-hidden border-2 border-gray-100 shadow-sm">
              <img
                src={service.image || "/placeholder.svg"}
                alt={`Perfil de ${service.name || "Usuario"}`}
                className="h-full w-full object-cover"
              />
            </div>
            {service.verified && (
              <div className="absolute -bottom-0.5 -right-0.5">
                <div className="bg-blue-500 rounded-full flex items-center justify-center w-4 h-4">
                  <Check className="text-white w-2.5 h-2.5" />
                </div>
              </div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-sm truncate">{service.name || "Usuario"}</h3>

            <div className="flex items-center mt-0.5 text-xs text-gray-500">
              {service.rating && (
                <div className="flex items-center mr-2">
                  <Star className="h-3 w-3 text-amber-500 fill-amber-500 mr-0.5" />
                  <span>{typeof service.rating === "number" ? service.rating.toFixed(1) : service.rating}</span>
                </div>
              )}

              {service.location && (
                <div className="flex items-center truncate">
                  <MapPin className="h-3 w-3 mr-0.5" />
                  <span className="truncate">{service.location}</span>
                </div>
              )}
            </div>

            <p className="text-xs mt-1 line-clamp-2 text-gray-600">
              {service.description || service.category || "Servicio disponible en tu zona"}
            </p>

            {service.category && (
              <Badge variant="outline" className="mt-1.5 text-xs bg-gray-50 font-normal">
                {service.category}
              </Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
