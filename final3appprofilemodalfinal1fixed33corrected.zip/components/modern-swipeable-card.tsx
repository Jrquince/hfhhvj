"use client"

import { useState, useRef, useEffect } from "react"
import { motion, useAnimation } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ChevronRight, Star, ThumbsUp, Send } from "lucide-react"
import ShareModal from "./share-modal"

export default function ModernSwipeableCard({
  children,
  stats,
  postTitle,
  postId,
  userId,
  username,
  isVideo = false,
  hideCenterRightCTA = false,
}) {
  const controls = useAnimation()
  const constraintsRef = useRef(null)
  const [isDragging, setIsDragging] = useState(false)
  const [showDetails, setShowDetails] = useState(false)
  const [startX, setStartX] = useState(0)
  const [showShareModal, setShowShareModal] = useState(false)

  // Reset position when component mounts or when postId changes
  useEffect(() => {
    controls.start({ x: 0 })
    setShowDetails(false)
  }, [postId, controls])

  const handleDragStart = (event, info) => {
    setIsDragging(true)
    setStartX(info.point.x)
  }

  const handleDragEnd = (event, info) => {
    setIsDragging(false)
    const dragDistance = info.point.x - startX

    // If dragged left significantly, show details
    if (dragDistance < -50) {
      setShowDetails(true)
      controls.start({ x: -80 })
    } else {
      setShowDetails(false)
      controls.start({ x: 0 })
    }
  }

  const handleTap = () => {
    if (showDetails) {
      setShowDetails(false)
      controls.start({ x: 0 })
    }
  }

  return (
    <div className="relative overflow-visible shadow-lg rounded-xl" ref={constraintsRef}>
      {/* Panel trasero con sombra */}
      <div className="absolute top-0 right-0 bottom-0 w-20 bg-white rounded-r-xl z-0 border-l border-gray-100"></div>

      <motion.div
        drag="x"
        dragConstraints={constraintsRef}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        animate={controls}
        onTap={handleTap}
        className="relative z-10 bg-white rounded-xl"
      >
        {children}

        {/* Botón de compartir */}
        <button
          onClick={(e) => {
            e.stopPropagation()
            e.preventDefault()
            setShowShareModal(true)
          }}
          className="absolute bottom-3 right-3 bg-white text-gray-600 p-1.5 rounded-full shadow-sm hover:bg-gray-50 hover:text-gray-800 transition-colors z-20"
          aria-label="Compartir anuncio"
        >
          <Send className="h-4 w-4" />
        </button>
      </motion.div>

      {/* Right side actions that appear when swiped */}
      <div className="absolute top-0 right-0 bottom-0 flex flex-col justify-between py-8 pr-2 z-5">
        {/* Valoración con estrellas - Movido mucho más arriba */}
        <div className="flex flex-col items-center mt-4">
          <Star className="h-5 w-5 text-yellow-500" />
          <span className="text-xs font-medium">{stats?.rating || "4.8"}</span>
        </div>

        {/* Espacio vacío para separar los elementos */}
        <div className="flex-grow"></div>

        {/* Recomendaciones - Movido más abajo */}
        <div className="flex flex-col items-center mb-4">
          <ThumbsUp className="h-5 w-5 text-green-500" />
          <span className="text-xs font-medium">{stats?.recommendations || "12"}</span>
        </div>
      </div>

      {/* Center-right CTA button */}
      {!hideCenterRightCTA && (
        <div className="absolute top-1/2 right-0 transform -translate-y-1/2 z-20">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 rounded-full bg-white shadow-md hover:bg-gray-100"
            onClick={(e) => {
              e.stopPropagation()
              setShowDetails(!showDetails)
              controls.start({ x: showDetails ? 0 : -80 })
            }}
          >
            <ChevronRight className="h-5 w-5 text-gray-600" />
          </Button>
        </div>
      )}

      {/* Swipe hint - only show briefly on first render */}
      <div
        className={`absolute top-1/2 right-4 transform -translate-y-1/2 text-xs text-gray-400 animate-pulse ${
          showDetails ? "opacity-0" : "opacity-100"
        }`}
      >
        {!isDragging && !showDetails && <span>← Desliza</span>}
      </div>

      {/* Modal de compartir */}
      <ShareModal
        open={showShareModal}
        onClose={() => setShowShareModal(false)}
        postTitle={postTitle}
        postId={postId}
      />
    </div>
  )
}
