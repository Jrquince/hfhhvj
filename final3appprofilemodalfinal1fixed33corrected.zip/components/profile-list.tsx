import type React from "react"
import Image from "next/image"
import { getAvatarByUserId } from "@/lib/avatar-utils"

interface Profile {
  id: string
  name: string
  description?: string
  location?: string
  image?: string
  verified?: boolean
}

interface ProfileListProps {
  profiles: Profile[]
}

const ProfileList: React.FC<ProfileListProps> = ({ profiles }) => {
  return (
    <div>
      {profiles.map((profile) => (
        <div key={profile.id} className="flex items-center p-3 border-b last:border-b-0">
          <div className="relative mr-3">
            <div className="h-10 w-10 rounded-full overflow-hidden border-2 border-gray-100 shadow-sm">
              <Image
                src={profile.image || getAvatarByUserId(profile.id) || "/placeholder.svg?height=40&width=40"}
                alt={`Perfil de ${profile.name}`}
                width={40}
                height={40}
                className="h-full w-full object-cover"
              />
            </div>
            {profile.verified && (
              <div className="absolute -bottom-0.5 -right-0.5">
                <div className="bg-blue-500 rounded-full flex items-center justify-center w-4 h-4">
                  <svg
                    className="text-white w-2.5 h-2.5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
              </div>
            )}
          </div>
          <div className="flex-1">
            <h4 className="font-medium text-sm">{profile.name}</h4>
            <p className="text-xs text-gray-500">{profile.description || profile.location}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

export default ProfileList
