"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/router"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, X, Sparkles, Clock, TrendingUp } from "lucide-react"
import { QuickIAModal } from "@/components/quickia-modal"

interface SearchModalProps {
  isOpen: boolean
  onClose: () => void
  onSearch: (query: string) => void
  placeholder?: string
  initialQuery?: string
}

export function SearchModal({
  isOpen,
  onClose,
  onSearch,
  placeholder = "Buscar...",
  initialQuery = "",
}: SearchModalProps) {
  const router = useRouter()
  const [query, setQuery] = useState(initialQuery)
  const [recentSearches, setRecentSearches] = useState([
    "Fontanero urgente",
    "Electricista Bilbao",
    "Limpieza hogar",
    "Profesor matemáticas",
  ])
  const [trendingSearches, setTrendingSearches] = useState([
    "Fontanería",
    "Electricidad",
    "Limpieza",
    "Clases particulares",
    "Mudanzas",
    "Reformas",
  ])
  const inputRef = useRef<HTMLInputElement>(null)
  const [showQuickIAModal, setShowQuickIAModal] = useState(false)

  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => {
        inputRef.current?.focus()
      }, 100)
    }
  }, [isOpen])

  const handleSearch = () => {
    if (query.trim()) {
      onSearch(query)
      // Añadir a búsquedas recientes si no existe ya
      if (!recentSearches.includes(query)) {
        setRecentSearches([query, ...recentSearches].slice(0, 5))
      }
      onClose()
    }
  }

  const handleRecentSearch = (search: string) => {
    setQuery(search)
    onSearch(search)
    onClose()
  }

  const handleTrendingSearch = (search: string) => {
    setQuery(search)
    onSearch(search)
    onClose()
  }

  const handleClearRecent = (e: React.MouseEvent, index: number) => {
    e.stopPropagation()
    setRecentSearches(recentSearches.filter((_, i) => i !== index))
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  const handleQuickIASubmit = (content: any) => {
    setQuery(content.title)
    onSearch(content.title)
    setShowQuickIAModal(false)
    onClose()
  }

  if (!isOpen) return null

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50" onClick={onClose} />

      {/* Modal */}
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[90%] max-w-md bg-white rounded-xl shadow-2xl border border-gray-200 flex flex-col max-h-[85vh] overflow-hidden">
        {/* Botón X para cerrar */}
        <button
          onClick={onClose}
          className="absolute right-3 top-3 p-1.5 rounded-full hover:bg-gray-100 transition-colors z-10"
          aria-label="Cerrar"
        >
          <X className="h-4 w-4 text-gray-500" />
        </button>

        <div className="p-4 border-b">
          <div className="text-lg font-semibold flex items-center gap-2">
            <Search className="h-5 w-5 text-gray-700" />
            <span>Búsqueda</span>
          </div>
          <p className="text-xs text-gray-500 mt-1 ml-7">Encuentra servicios, profesionales y anuncios</p>
        </div>

        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              ref={inputRef}
              type="text"
              className="pl-10 pr-10 py-2 rounded-lg border-gray-200 focus:border-purple-300 focus:ring-purple-300 text-sm"
              placeholder={placeholder}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="mt-3 flex items-center justify-between">
            <div>
              <Button
                onClick={(e) => {
                  e.stopPropagation()
                  setQuery("")
                  onClose()
                }}
                variant="outline"
                size="sm"
                className="mr-2 rounded-full text-xs border-gray-200 py-1"
              >
                Cancelar
              </Button>
              <Button
                onClick={(e) => {
                  e.stopPropagation()
                  handleSearch()
                }}
                size="sm"
                className="rounded-full text-xs bg-black hover:bg-gray-800 text-white py-1"
              >
                Buscar
              </Button>
            </div>
            <Button
              onClick={(e) => {
                e.stopPropagation()
                setShowQuickIAModal(true)
              }}
              size="sm"
              className="rounded-full text-xs flex items-center bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white py-1"
            >
              <Sparkles className="h-3 w-3 mr-1" />
              QuickIA
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-4">
          {/* Búsquedas recientes */}
          {recentSearches.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                <Clock className="h-4 w-4 mr-2 text-gray-400" />
                Búsquedas recientes
              </h3>
              <div className="space-y-2">
                {recentSearches.map((search, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg cursor-pointer"
                    onClick={() => handleRecentSearch(search)}
                  >
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm">{search}</span>
                    </div>
                    <button
                      onClick={(e) => handleClearRecent(e, index)}
                      className="text-gray-400 hover:text-gray-600"
                      aria-label="Eliminar búsqueda reciente"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Búsquedas populares */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
              <TrendingUp className="h-4 w-4 mr-2 text-gray-400" />
              Búsquedas populares
            </h3>
            <div className="flex flex-wrap gap-2">
              {trendingSearches.map((search, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="rounded-full text-xs border-gray-200"
                  onClick={() => handleTrendingSearch(search)}
                >
                  {search}
                </Button>
              ))}
            </div>
          </div>

          {/* Sugerencia de QuickIA */}
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
            <div className="flex items-center mb-2">
              <div className="w-6 h-6 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center text-white mr-2">
                <Sparkles className="h-3 w-3" />
              </div>
              <h3 className="text-sm font-medium">Prueba QuickIA</h3>
            </div>
            <p className="text-xs text-gray-600 mb-3">
              Pregúntale a QuickIA para obtener recomendaciones personalizadas y encontrar exactamente lo que buscas.
            </p>
            <Button
              size="sm"
              className="w-full rounded-lg text-xs bg-black hover:bg-gray-800 text-white"
              onClick={(e) => {
                e.stopPropagation()
                setShowQuickIAModal(true)
                onClose()
              }}
            >
              Preguntar a QuickIA
            </Button>
          </div>
        </div>
        {/* Modal de QuickIA */}
        <QuickIAModal
          open={showQuickIAModal}
          onOpenChange={setShowQuickIAModal}
          onSubmit={handleQuickIASubmit}
          mode="map"
        />
      </div>
    </>
  )
}
