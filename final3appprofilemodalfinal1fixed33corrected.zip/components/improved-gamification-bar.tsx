"use client"

import * as React from "react"
import { Progress } from "@/components/ui/progress"
import { Trophy, Star, Info, Award } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface ImprovedGamificationBarProps {
  level?: number
  progress?: number
  points?: number
  nextLevelPoints?: number
  helpsDone?: number
  helpsToNextLevel?: number
}

export default function ImprovedGamificationBar({
  level = 2,
  progress = 80,
  points = 450,
  nextLevelPoints = 500,
  helpsDone = 4,
  helpsToNextLevel = 5,
}: ImprovedGamificationBarProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false)

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center">
            <Trophy className="h-5 w-5 text-yellow-500 mr-2" />
            <span className="font-medium text-gray-700">Ayudas Realizadas</span>
          </div>
          <div className="flex items-center bg-yellow-100 text-yellow-800 rounded-full px-2 py-0.5 text-xs font-medium">
            <Star className="h-3 w-3 mr-1 fill-yellow-500 text-yellow-500" />
            Nivel {level}
          </div>
        </div>

        <div className="relative">
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>
              {helpsDone}/{helpsToNextLevel}
            </span>
            <span>
              {points}/{nextLevelPoints} puntos
            </span>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <button className="w-full focus:outline-none">
                <Progress value={progress} className="h-3 bg-gray-100" />
              </button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="text-center text-xl">Tu progreso</DialogTitle>
                <DialogDescription className="text-center">
                  Información sobre tu nivel y ayudas realizadas
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6 py-4">
                <div className="flex justify-center">
                  <div className="flex flex-col items-center bg-yellow-50 p-5 rounded-full">
                    <Trophy className="h-10 w-10 text-yellow-500 mb-1" />
                    <span className="text-2xl font-bold text-yellow-800">Nivel {level}</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Progreso hacia nivel {level + 1}</span>
                      <span className="text-sm font-medium">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-3 bg-gray-100" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white rounded-lg p-4 border border-gray-200">
                      <div className="flex items-center mb-1">
                        <Award className="h-4 w-4 text-yellow-500 mr-1" />
                        <span className="text-sm font-medium">Ayudas realizadas</span>
                      </div>
                      <p className="text-2xl font-bold">{helpsDone}</p>
                    </div>

                    <div className="bg-white rounded-lg p-4 border border-gray-200">
                      <div className="flex items-center mb-1">
                        <Award className="h-4 w-4 text-green-500 mr-1" />
                        <span className="text-sm font-medium">Próximo nivel</span>
                      </div>
                      <p className="text-2xl font-bold">{helpsToNextLevel}</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg p-4 border border-gray-200">
                    <div className="flex items-center mb-1">
                      <Star className="h-4 w-4 text-yellow-500 mr-1" />
                      <span className="text-sm font-medium">Puntos acumulados</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <p className="text-2xl font-bold">{points}</p>
                      <p className="text-sm text-gray-500">Próximo nivel: {nextLevelPoints}</p>
                    </div>
                    <Progress value={(points / nextLevelPoints) * 100} className="h-2 mt-2 bg-gray-100" />
                  </div>

                  <div className="bg-yellow-50 p-4 rounded-lg">
                    <div className="flex items-start">
                      <Info className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-gray-700">
                        Completa más servicios y obtén buenas valoraciones para subir de nivel. Cada nivel te otorga
                        nuevas ventajas y visibilidad en la plataforma.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </>
  )
}
