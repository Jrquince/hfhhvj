"use client"

import { forwardRef } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { getAvatarByUserId } from "@/lib/avatar-utils"
import { Check } from "lucide-react"

interface ProfileAvatarProps {
  userId: string | number
  username?: string
  size?: "sm" | "md" | "lg" | "xl"
  verified?: boolean
  image?: string
  className?: string
}

const sizeClasses = {
  sm: "h-8 w-8",
  md: "h-10 w-10",
  lg: "h-12 w-12",
  xl: "h-16 w-16",
}

const badgeSizeClasses = {
  sm: "h-3 w-3 -right-0.5 -bottom-0.5",
  md: "h-4 w-4 -right-0.5 -bottom-0.5",
  lg: "h-5 w-5 -right-1 -bottom-1",
  xl: "h-6 w-6 -right-1 -bottom-1",
}

const checkSizeClasses = {
  sm: "h-2 w-2",
  md: "h-2.5 w-2.5",
  lg: "h-3 w-3",
  xl: "h-3.5 w-3.5",
}

export const ProfileAvatar = forwardRef<HTMLDivElement, ProfileAvatarProps>(
  ({ userId, username, size = "md", verified = false, image, className = "" }, ref) => {
    // Obtener las iniciales del nombre de usuario
    const getInitials = () => {
      if (!username) return "?"
      return username
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .substring(0, 2)
    }

    // Obtener la imagen de avatar
    const avatarImage = image || getAvatarByUserId(userId)

    return (
      <div className={`relative ${className}`} ref={ref}>
        <Avatar className={`${sizeClasses[size]} border border-gray-200`}>
          <AvatarImage
            src={avatarImage || "/placeholder.svg"}
            alt={username || "Usuario"}
            className="object-cover"
            onError={(e) => {
              // Si la imagen falla, usar un placeholder
              e.currentTarget.src = `/placeholder.svg?height=100&width=100&text=${getInitials()}`
            }}
          />
          <AvatarFallback className="bg-gray-100 text-gray-600">{getInitials()}</AvatarFallback>
        </Avatar>

        {verified && (
          <div
            className={`absolute ${badgeSizeClasses[size]} flex items-center justify-center rounded-full bg-blue-500 text-white border border-white`}
          >
            <Check className={checkSizeClasses[size]} />
          </div>
        )}
      </div>
    )
  },
)

ProfileAvatar.displayName = "ProfileAvatar"
