"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { SurveyCompletionDialog } from "@/components/survey-completion-dialog"

interface SurveyModalProps {
  isOpen: boolean
  onClose: () => void
}

export const SurveyModal = ({ isOpen, onClose }: SurveyModalProps) => {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [showCompletionDialog, setShowCompletionDialog] = useState(false)
  const [responses, setResponses] = useState({
    satisfaction: "",
    usability: "",
    features: "",
    improvement: "",
  })

  const totalSteps = 3

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1)
    } else {
      setShowCompletionDialog(true)
      onClose()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleResponseChange = (field: keyof typeof responses, value: string) => {
    setResponses({
      ...responses,
      [field]: value,
    })
  }

  const isNextDisabled = () => {
    if (currentStep === 1) {
      return !responses.satisfaction
    }
    if (currentStep === 2) {
      return !responses.usability
    }
    return false
  }

  return (
    <>
      <AlertDialog open={isOpen} onOpenChange={onClose}>
        <AlertDialogContent className="bg-white p-4 rounded-lg max-w-md mx-auto max-h-[90vh] overflow-hidden">
          <AlertDialogHeader className="pb-2">
            <AlertDialogTitle className="text-lg font-semibold">Encuesta de satisfacción</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-500 text-sm">
              Tu opinión nos ayuda a mejorar. Paso {currentStep} de {totalSteps}
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="my-3 overflow-y-auto max-h-[50vh]">
            {currentStep === 1 && (
              <div className="space-y-4">
                <h3 className="font-medium">¿Cómo calificarías tu experiencia general con la aplicación?</h3>
                <RadioGroup
                  value={responses.satisfaction}
                  onValueChange={(value) => handleResponseChange("satisfaction", value)}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="very-satisfied" id="very-satisfied" />
                    <Label htmlFor="very-satisfied">Muy satisfecho</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="satisfied" id="satisfied" />
                    <Label htmlFor="satisfied">Satisfecho</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="neutral" id="neutral" />
                    <Label htmlFor="neutral">Neutral</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dissatisfied" id="dissatisfied" />
                    <Label htmlFor="dissatisfied">Insatisfecho</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="very-dissatisfied" id="very-dissatisfied" />
                    <Label htmlFor="very-dissatisfied">Muy insatisfecho</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-4">
                <h3 className="font-medium">¿Cómo de fácil te resulta usar la aplicación?</h3>
                <RadioGroup
                  value={responses.usability}
                  onValueChange={(value) => handleResponseChange("usability", value)}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="very-easy" id="very-easy" />
                    <Label htmlFor="very-easy">Muy fácil</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="easy" id="easy" />
                    <Label htmlFor="easy">Fácil</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="neutral" id="neutral-usability" />
                    <Label htmlFor="neutral-usability">Neutral</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="difficult" id="difficult" />
                    <Label htmlFor="difficult">Difícil</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="very-difficult" id="very-difficult" />
                    <Label htmlFor="very-difficult">Muy difícil</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-4">
                <h3 className="font-medium">¿Qué características te gustaría ver en futuras actualizaciones?</h3>
                <Textarea
                  placeholder="Escribe tus sugerencias aquí..."
                  value={responses.features}
                  onChange={(e) => handleResponseChange("features", e.target.value)}
                  className="min-h-[100px]"
                />

                <h3 className="font-medium mt-4">¿Cómo podríamos mejorar tu experiencia?</h3>
                <Textarea
                  placeholder="Comparte tus ideas para mejorar..."
                  value={responses.improvement}
                  onChange={(e) => handleResponseChange("improvement", e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
            )}
          </div>

          <AlertDialogFooter className="flex-col space-y-2 sm:space-y-0">
            <div className="flex w-full justify-between">
              {currentStep > 1 ? (
                <button onClick={handlePrevious} className="text-sm text-gray-500 hover:text-gray-800">
                  Anterior
                </button>
              ) : (
                <div></div>
              )}
              <div className="flex space-x-1">
                {Array.from({ length: totalSteps }).map((_, index) => (
                  <div
                    key={index}
                    className={`h-1 w-4 rounded-full ${index + 1 <= currentStep ? "bg-black" : "bg-gray-200"}`}
                  ></div>
                ))}
              </div>
            </div>
            <AlertDialogCancel className="mt-2 sm:mt-0">Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleNext}
              disabled={isNextDisabled()}
              className={`${
                isNextDisabled() ? "bg-gray-300 cursor-not-allowed" : "bg-black hover:bg-gray-800"
              } text-white`}
            >
              {currentStep < totalSteps ? "Siguiente" : "Finalizar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <SurveyCompletionDialog isOpen={showCompletionDialog} onClose={() => setShowCompletionDialog(false)} />
    </>
  )
}
