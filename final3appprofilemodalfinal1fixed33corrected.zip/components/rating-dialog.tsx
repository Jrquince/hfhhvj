"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Star } from "lucide-react"

interface RatingDialogProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (rating: number) => void
}

export const RatingDialog = ({ isOpen, onClose, onSubmit }: RatingDialogProps) => {
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const router = useRouter()

  const handleRatingClick = (selectedRating: number) => {
    setRating(selectedRating)
  }

  const handleSubmit = () => {
    onSubmit(rating)
    router.push("/chat-detail/1/valoracion-enviada")
  }

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogContent className="bg-white p-4 rounded-lg max-w-md mx-auto max-h-[90vh] overflow-hidden">
        <AlertDialogHeader className="pb-2">
          <AlertDialogTitle className="text-lg font-semibold text-center">
            ¿Cómo valorarías el servicio?
          </AlertDialogTitle>
          <AlertDialogDescription className="text-center text-gray-500 text-sm">
            Tu opinión nos ayuda a mejorar la calidad de los servicios.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="flex justify-center space-x-2 my-4">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => handleRatingClick(star)}
              onMouseEnter={() => setHoveredRating(star)}
              onMouseLeave={() => setHoveredRating(0)}
              className="focus:outline-none"
            >
              <Star
                className={`h-8 w-8 ${
                  star <= (hoveredRating || rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                } transition-colors`}
              />
            </button>
          ))}
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel className="w-full sm:w-auto border border-gray-300 text-gray-700">
            Cancelar
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleSubmit}
            disabled={rating === 0}
            className={`w-full sm:w-auto ${
              rating === 0 ? "bg-gray-300 cursor-not-allowed" : "bg-black hover:bg-gray-800"
            } text-white`}
          >
            Enviar valoración
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
