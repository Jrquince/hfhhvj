import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, MapPin, CheckCircle } from "lucide-react"
import { ProfileAvatar } from "@/components/profile-avatar"
import { getUniqueProfileImages } from "@/utils/profile-images"

// Datos simulados para los resultados de búsqueda
const searchResults = (() => {
  const results = []
  const profileImages = getUniqueProfileImages(8)

  for (let i = 0; i < 8; i++) {
    results.push({
      id: i + 100,
      username: `experto${i + 1}`,
      profileImage: profileImages[i],
      rating: (4 + Math.random()).toFixed(1),
      location: "Bilbao",
      distance: `${(1 + Math.random() * 5).toFixed(1)} km`,
      specialties: ["Fontanería", "Electricidad", "Carpintería", "Pintura", "Albañilería"].slice(
        0,
        Math.floor(Math.random() * 3) + 1,
      ),
      verified: Math.random() > 0.3,
      premium: Math.random() > 0.7,
    })
  }
  return results
})()

export function SearchResults() {
  return (
    <div className="space-y-4 p-4">
      <h2 className="text-lg font-semibold mb-3">Resultados de búsqueda</h2>

      {searchResults.map((result) => (
        <Card key={result.id} className="w-full">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center">
                <ProfileAvatar src={result.profileImage} userId={result.id} fallback={result.username[0]} size="md" />
                <div className="ml-3">
                  <div className="flex items-center">
                    <h3 className="font-medium">{result.username}</h3>
                    {result.verified && <CheckCircle className="h-4 w-4 text-blue-500 ml-1" />}
                    {result.premium && (
                      <Badge variant="outline" className="ml-2 bg-yellow-100 text-yellow-800 border-yellow-300 text-xs">
                        Pro
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center text-xs text-gray-500">
                    <Star className="h-3 w-3 text-yellow-500 mr-1" />
                    <span>{result.rating}</span>
                    <span className="mx-1">•</span>
                    <MapPin className="h-3 w-3 mr-1" />
                    <span>{result.distance}</span>
                  </div>
                </div>
              </div>
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-xs h-8">
                Ver perfil
              </Button>
            </div>
            <div className="mt-2">
              <div className="flex flex-wrap gap-1">
                {result.specialties.map((specialty, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {specialty}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
