"use client"

import { useRouter } from "next/navigation"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { CheckCircle } from "lucide-react"

interface SurveyCompletionDialogProps {
  isOpen: boolean
  onClose: () => void
}

export const SurveyCompletionDialog = ({ isOpen, onClose }: SurveyCompletionDialogProps) => {
  const router = useRouter()

  const handleContinue = () => {
    router.push("/home-redesigned")
    onClose()
  }

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogContent className="bg-white p-6 rounded-lg max-w-md mx-auto text-center">
        <AlertDialogHeader className="space-y-4">
          <div className="mx-auto bg-green-100 rounded-full p-3 w-16 h-16 flex items-center justify-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <AlertDialogTitle className="text-xl font-semibold">¡Encuesta completada!</AlertDialogTitle>
          <AlertDialogDescription className="text-gray-500">
            Gracias por completar la encuesta. Tus respuestas nos ayudarán a mejorar la experiencia para todos los
            usuarios.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-col space-y-2 sm:space-y-0">
          <AlertDialogAction onClick={handleContinue} className="w-full bg-black hover:bg-gray-800 text-white">
            Continuar
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
