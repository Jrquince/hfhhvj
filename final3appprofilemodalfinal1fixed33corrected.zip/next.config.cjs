/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  webpack(config) {
    config.resolve.fallback = {
      ...config.resolve.fallback,
      '@prisma/client': false,
    };
    return config;
  },
  images: {
    // domains: ['your-domain.com'],
  },
};

module.exports = nextConfig;
