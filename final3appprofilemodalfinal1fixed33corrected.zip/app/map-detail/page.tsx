import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BottomNavigation } from "@/components/bottom-navigation"
import Link from "next/link"
import Image from "next/image"

export default function MapDetailPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/map">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">MAPA</h1>
        <div className="w-8"></div>
      </div>

      {/* Filter tabs */}
      <div className="px-4 py-2 sticky top-16 bg-white z-10 border-b">
        <Tabs defaultValue="anuncios" className="w-full">
          <TabsList className="w-full grid grid-cols-4">
            <TabsTrigger value="anuncios" className="text-xs">
              Anuncios
            </TabsTrigger>
            <TabsTrigger value="profesionales" className="text-xs">
              Profesionales
            </TabsTrigger>
            <TabsTrigger value="vivienda" className="text-xs">
              Vivienda
            </TabsTrigger>
            <TabsTrigger value="motor" className="text-xs">
              Motor
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Map */}
      <div className="relative flex-1">
        <Image
          src="/placeholder.svg?height=600&width=400&text=Mapa"
          alt="Map"
          width={400}
          height={600}
          className="w-full h-[calc(100vh-180px)] object-cover"
        />

        {/* Map pins */}
        {[
          { top: "25%", left: "30%" },
          { top: "35%", left: "20%" },
          { top: "55%", left: "45%" },
          { top: "65%", left: "35%" },
          { top: "70%", left: "50%" },
          { top: "60%", left: "65%" },
          { top: "45%", left: "75%" },
          { top: "30%", left: "50%", active: true },
        ].map((position, index) => (
          <div
            key={index}
            className={`absolute w-9 h-9 ${
              position.active ? "bg-orange-500" : "bg-black"
            } rounded-full flex items-center justify-center transform -translate-x-1/2 -translate-y-1/2`}
            style={{ top: position.top, left: position.left }}
          >
            {position.active ? (
              <Avatar className="h-8 w-8 border-2 border-white">
                <Image
                  src="/placeholder.svg?height=32&width=32&text=AU"
                  alt="User avatar"
                  width={32}
                  height={32}
                  className="rounded-full"
                />
              </Avatar>
            ) : (
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
                <polyline points="9 22 9 12 15 12 15 22" />
              </svg>
            )}
          </div>
        ))}

        {/* User popup */}
        <div className="absolute top-[30%] right-[20%] bg-white rounded-xl p-3 shadow-md border max-w-[60%]">
          <div className="flex items-start">
            <Avatar className="h-10 w-10 border">
              <Image
                src="/placeholder.svg?height=40&width=40&text=AU"
                alt="Ana Urrutia"
                width={40}
                height={40}
                className="rounded-full"
              />
            </Avatar>
            <div className="ml-2">
              <div className="flex items-center">
                <h3 className="font-medium text-sm">Ana Urrutia</h3>
              </div>
              <p className="text-xs text-gray-500">
                Necesito ayuda para montar un mueble de Ikea en mi apartamento en Bagatza
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom user cards */}
      <div className="fixed bottom-20 left-0 right-0 max-w-md mx-auto">
        <div className="bg-orange-500 text-white rounded-xl p-3 flex items-center justify-between mx-4 mb-2">
          <div className="flex items-center">
            <Avatar className="h-12 w-12 border-2 border-white">
              <Image
                src="/placeholder.svg?height=48&width=48&text=AU"
                alt="Ana Urrutia"
                width={48}
                height={48}
                className="rounded-full"
              />
            </Avatar>
            <div className="ml-3">
              <div className="flex items-center">
                <h3 className="font-medium text-sm">Ana Urrutia</h3>
                <div className="flex ml-1">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
              <p className="text-xs">Bilbao, Vizcaya</p>
            </div>
          </div>
          <div className="w-8 h-8 bg-orange-400 rounded-full flex items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
              <polyline points="9 22 9 12 15 12 15 22" />
            </svg>
          </div>
        </div>

        <div className="bg-white border rounded-xl p-3 flex items-center justify-between mx-4">
          <div className="flex items-center">
            <Avatar className="h-12 w-12 border">
              <Image
                src="/placeholder.svg?height=48&width=48&text=DG"
                alt="Diego Gómez"
                width={48}
                height={48}
                className="rounded-full"
              />
            </Avatar>
            <div className="ml-3">
              <div className="flex items-center">
                <h3 className="font-medium text-sm">Diego Gómez</h3>
                <div className="flex ml-1">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
              <p className="text-xs text-gray-500">Bilbao, Vizcaya</p>
            </div>
          </div>
          <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" />
              <path d="M12 16L12 12" />
              <path d="M12 8L12.01 8" />
            </svg>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="map" />
    </div>
  )
}
