import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function PrivacidadPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">PRIVACIDAD</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="font-medium text-base">Cuenta</h2>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Cuenta privada</p>
                <p className="text-xs text-gray-500">Solo tus seguidores podrán ver tu perfil</p>
              </div>
              <Switch />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Actividad</p>
                <p className="text-xs text-gray-500">Mostrar cuando estás en línea</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Ubicación</p>
                <p className="text-xs text-gray-500">Mostrar tu ubicación aproximada</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Interacciones</h2>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Menciones</p>
                <p className="text-xs text-gray-500">Quién puede mencionarte</p>
              </div>
              <div className="text-sm text-gray-600">Todos</div>
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Etiquetas</p>
                <p className="text-xs text-gray-500">Quién puede etiquetarte</p>
              </div>
              <div className="text-sm text-gray-600">Seguidores</div>
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Mensajes directos</p>
                <p className="text-xs text-gray-500">Quién puede enviarte mensajes</p>
              </div>
              <div className="text-sm text-gray-600">Todos</div>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Datos</h2>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Historial de búsqueda</p>
                <p className="text-xs text-gray-500">Guardar tus búsquedas recientes</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Datos de uso</p>
                <p className="text-xs text-gray-500">Compartir datos para mejorar la app</p>
              </div>
              <Switch defaultChecked />
            </div>

            <Link href="/configuracion/privacidad/datos">
              <Button variant="outline" className="w-full mt-4 text-sm">
                Descargar mis datos
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
