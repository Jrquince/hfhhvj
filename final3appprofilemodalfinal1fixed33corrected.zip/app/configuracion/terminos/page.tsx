import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function TerminosPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">TÉRMINOS Y CONDICIONES</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <p className="text-sm text-gray-500 mb-6">Última actualización: 15 de mayo de 2023</p>

        <div className="space-y-6 text-sm">
          <section>
            <h2 className="font-bold mb-2">1. Introducción</h2>
            <p className="text-gray-700 mb-2">
              Bienvenido a QuickSer. Estos Términos y Condiciones rigen el uso de nuestra aplicación móvil y sitio web,
              así como cualquier otro servicio relacionado proporcionado por nosotros.
            </p>
            <p className="text-gray-700">
              Al acceder o utilizar nuestros servicios, usted acepta estar sujeto a estos Términos. Si no está de
              acuerdo con alguna parte de estos términos, no podrá acceder a nuestros servicios.
            </p>
          </section>

          <section>
            <h2 className="font-bold mb-2">2. Definiciones</h2>
            <p className="text-gray-700 mb-2">
              <strong>"Servicio"</strong> se refiere a la aplicación móvil QuickSer, el sitio web y cualquier otro
              servicio relacionado.
            </p>
            <p className="text-gray-700 mb-2">
              <strong>"Usuario"</strong> se refiere a cualquier persona que acceda o utilice nuestros servicios.
            </p>
            <p className="text-gray-700">
              <strong>"Contenido"</strong> se refiere a cualquier información, texto, gráficos, fotos u otros materiales
              cargados, descargados o que aparezcan en nuestros servicios.
            </p>
          </section>

          <section>
            <h2 className="font-bold mb-2">3. Registro de cuenta</h2>
            <p className="text-gray-700 mb-2">
              Para utilizar ciertas funciones de nuestro servicio, es posible que deba registrarse y crear una cuenta.
              Usted es responsable de mantener la confidencialidad de su cuenta y contraseña.
            </p>
            <p className="text-gray-700">
              Usted acepta proporcionar información precisa, actual y completa durante el proceso de registro y
              actualizar dicha información para mantenerla precisa, actual y completa.
            </p>
          </section>

          <section>
            <h2 className="font-bold mb-2">4. Uso del servicio</h2>
            <p className="text-gray-700 mb-2">
              Nuestro servicio permite a los usuarios publicar, buscar y contratar servicios ofrecidos por otros
              usuarios. Usted acepta utilizar nuestro servicio solo para fines legales y de acuerdo con estos Términos.
            </p>
            <p className="text-gray-700">
              Usted no debe utilizar nuestro servicio para publicar contenido falso, engañoso, ofensivo o ilegal, ni
              para realizar actividades que puedan dañar, deshabilitar o sobrecargar nuestros sistemas.
            </p>
          </section>

          <section>
            <h2 className="font-bold mb-2">5. Contenido del usuario</h2>
            <p className="text-gray-700">
              Al publicar contenido en nuestro servicio, usted nos otorga una licencia mundial, no exclusiva, libre de
              regalías para usar, reproducir, modificar, adaptar, publicar, traducir, distribuir y mostrar dicho
              contenido en relación con nuestro servicio.
            </p>
          </section>

          <div className="mt-8">
            <Button className="w-full rounded-full bg-blue-600 text-white py-2">Aceptar términos y condiciones</Button>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
