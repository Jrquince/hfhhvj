"use client"

import { useState, useEffect } from "react"
import { useTheme } from "next-themes"
import Link from "next/link"
import {
  ArrowLeft,
  ChevronRight,
  Moon,
  Sun,
  Bell,
  Lock,
  Eye,
  Share2,
  Globe,
  HelpCircle,
  Languages,
  LogOut,
  Sparkles,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { BottomNavigation } from "@/components/bottom-navigation"
import { toast } from "sonner"

export default function ConfiguracionPage() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // Evitar problemas de hidratación
  useEffect(() => {
    setMounted(true)
  }, [])

  const toggleTheme = () => {
    if (theme === "dark") {
      setTheme("light")
    } else {
      setTheme("dark")
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background border-b border-border">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/profile">
              <Button variant="ghost" size="icon" className="mr-2">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-semibold">Configuración</h1>
          </div>
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="transition-transform hover:scale-110">
            {mounted && theme === "dark" ? <Sun className="h-5 w-5 text-yellow-400" /> : <Moon className="h-5 w-5" />}
          </Button>
        </div>
      </header>

      {/* Contenido */}
      <div className="p-4 space-y-6">
        <div className="space-y-2">
          <h2 className="text-lg font-medium">Cuenta</h2>
          <div className="space-y-1">
            <Link href="/configuracion/privacidad">
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                <div className="flex items-center">
                  <Lock className="h-5 w-5 mr-3 text-muted-foreground" />
                  <span>Privacidad</span>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </Link>
            <Link href="/configuracion/seguridad">
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                <div className="flex items-center">
                  <Eye className="h-5 w-5 mr-3 text-muted-foreground" />
                  <span>Seguridad</span>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </Link>
            <Link href="/configuracion/compartir">
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                <div className="flex items-center">
                  <Share2 className="h-5 w-5 mr-3 text-muted-foreground" />
                  <span>Compartir perfil</span>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </Link>
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <h2 className="text-lg font-medium">Preferencias</h2>
          <div className="space-y-1">
            <Link href="/configuracion/notificaciones">
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                <div className="flex items-center">
                  <Bell className="h-5 w-5 mr-3 text-muted-foreground" />
                  <span>Notificaciones</span>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </Link>
            <Link href="/configuracion/preferencias">
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                <div className="flex items-center">
                  <Globe className="h-5 w-5 mr-3 text-muted-foreground" />
                  <span>Preferencias de contenido</span>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </Link>
            <Link href="/configuracion/quickia">
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                <div className="flex items-center">
                  <Sparkles className="h-5 w-5 mr-3 text-muted-foreground" />
                  <span>QuickIA</span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 px-2 py-0.5 rounded-full mr-2">
                    Nuevo
                  </span>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </div>
              </div>
            </Link>
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <h2 className="text-lg font-medium">Aplicación</h2>
          <div className="space-y-1">
            <Link href="/configuracion/idioma">
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                <div className="flex items-center">
                  <Languages className="h-5 w-5 mr-3 text-muted-foreground" />
                  <span>Idioma</span>
                </div>
                <div className="text-sm text-muted-foreground">Español</div>
              </div>
            </Link>
            <Link href="/configuracion/ayuda">
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                <div className="flex items-center">
                  <HelpCircle className="h-5 w-5 mr-3 text-muted-foreground" />
                  <span>Ayuda y soporte</span>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </Link>
            <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
              <div className="flex items-center">
                <Bell className="h-5 w-5 mr-3 text-muted-foreground" />
                <span>Sonidos</span>
              </div>
              <Switch
                onChange={(checked) => {
                  toast({
                    title: checked ? "Sonidos activados" : "Sonidos desactivados",
                    description: checked
                      ? "Has activado los sonidos de la aplicación"
                      : "Has desactivado los sonidos de la aplicación",
                    duration: 2000,
                  })
                }}
              />
            </div>
          </div>
        </div>

        <Separator />

        <Link href="/configuracion/cerrar-sesion">
          <div className="flex items-center p-3 rounded-lg hover:bg-muted text-red-500 dark:text-red-400">
            <LogOut className="h-5 w-5 mr-3" />
            <span>Cerrar sesión</span>
          </div>
        </Link>

        <div className="text-center text-xs text-muted-foreground mt-8">
          <p>Versión 1.0.0</p>
          <p className="mt-1">© 2023 QuickSer. Todos los derechos reservados.</p>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
