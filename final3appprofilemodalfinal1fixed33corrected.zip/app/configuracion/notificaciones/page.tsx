import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function NotificacionesPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">NOTIFICACIONES</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="font-medium text-base">Notificaciones push</h2>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Mensajes</p>
                <p className="text-xs text-gray-500">Notificaciones de mensajes nuevos</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Solicitudes</p>
                <p className="text-xs text-gray-500">Notificaciones de solicitudes de servicio</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Valoraciones</p>
                <p className="text-xs text-gray-500">Notificaciones de nuevas valoraciones</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Menciones</p>
                <p className="text-xs text-gray-500">Notificaciones cuando te mencionan</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Notificaciones por correo</h2>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Resumen semanal</p>
                <p className="text-xs text-gray-500">Recibe un resumen semanal de actividad</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Ofertas y promociones</p>
                <p className="text-xs text-gray-500">Recibe ofertas y promociones especiales</p>
              </div>
              <Switch />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Actualizaciones de la app</p>
                <p className="text-xs text-gray-500">Recibe información sobre actualizaciones</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Horarios</h2>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Modo silencioso</p>
                <p className="text-xs text-gray-500">Silenciar notificaciones en horarios específicos</p>
              </div>
              <Switch />
            </div>

            <div className="border rounded-lg p-3 bg-gray-50">
              <p className="text-sm font-medium mb-2">Horario silencioso</p>
              <div className="flex justify-between">
                <div>
                  <p className="text-xs text-gray-500">Desde</p>
                  <p className="text-sm">22:00</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Hasta</p>
                  <p className="text-sm">08:00</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
