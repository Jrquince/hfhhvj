import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function AnunciosPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">ANUNCIOS</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <p className="text-sm text-gray-500 mb-6">Configura tus preferencias de anuncios y publicidad personalizada.</p>

        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="font-medium text-sm">Preferencias de anuncios</h2>

            <div className="flex justify-between items-center py-3 border-b border-gray-100">
              <div>
                <p className="text-sm font-medium">Anuncios personalizados</p>
                <p className="text-xs text-gray-500">Mostrar anuncios basados en tus intereses</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center py-3 border-b border-gray-100">
              <div>
                <p className="text-sm font-medium">Anuncios basados en ubicación</p>
                <p className="text-xs text-gray-500">Mostrar anuncios relevantes para tu zona</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-sm">Categorías de interés</h2>

            <div className="grid grid-cols-2 gap-2">
              <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                <span className="text-sm">Tecnología</span>
                <Switch size="sm" defaultChecked />
              </div>
              <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                <span className="text-sm">Hogar</span>
                <Switch size="sm" defaultChecked />
              </div>
              <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                <span className="text-sm">Moda</span>
                <Switch size="sm" />
              </div>
              <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                <span className="text-sm">Deportes</span>
                <Switch size="sm" defaultChecked />
              </div>
              <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                <span className="text-sm">Viajes</span>
                <Switch size="sm" defaultChecked />
              </div>
              <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                <span className="text-sm">Comida</span>
                <Switch size="sm" />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-sm">Opciones avanzadas</h2>

            <div className="flex justify-between items-center py-3 border-b border-gray-100">
              <div>
                <p className="text-sm font-medium">Restablecer ID de publicidad</p>
                <p className="text-xs text-gray-500">Elimina tu historial de anuncios</p>
              </div>
              <Button variant="ghost" className="text-blue-600 text-sm">
                Restablecer
              </Button>
            </div>

            <div className="flex justify-between items-center py-3 border-b border-gray-100">
              <div>
                <p className="text-sm font-medium">Descargar datos de anuncios</p>
                <p className="text-xs text-gray-500">Obtén un informe de tus datos</p>
              </div>
              <Button variant="ghost" className="text-blue-600 text-sm">
                Descargar
              </Button>
            </div>
          </div>

          <Button className="w-full rounded-full border border-gray-300 text-sm py-2 mt-2">
            Más información sobre anuncios
          </Button>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
