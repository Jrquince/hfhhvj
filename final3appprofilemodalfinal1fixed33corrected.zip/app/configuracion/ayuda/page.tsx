"use client"

import { useState } from "react"
import { ArrowLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Input } from "@/components/ui/input"
import { HelpModal } from "@/components/help-modal"

export default function AyudaPage() {
  const [activeModal, setActiveModal] = useState<string | null>(null)
  const [activeCategory, setActiveCategory] = useState<number | null>(null)
  const [activeItem, setActiveItem] = useState<number | null>(null)

  const faqCategories = [
    {
      title: "Cuenta y perfil",
      items: [
        "¿Cómo cambio mi contraseña?",
        "¿Cómo edito mi perfil?",
        "¿Cómo elimino mi cuenta?",
        "¿Cómo cambio mi correo electrónico?",
      ],
    },
    {
      title: "Servicios y pagos",
      items: [
        "¿Cómo publico un servicio?",
        "¿Cómo establezco mis tarifas?",
        "¿Cómo recibo pagos?",
        "¿Qué comisiones se aplican?",
      ],
    },
    {
      title: "Mensajes y comunicación",
      items: [
        "¿Cómo contacto con otros usuarios?",
        "¿Puedo bloquear a un usuario?",
        "¿Cómo reporto contenido inapropiado?",
        "¿Mis mensajes son privados?",
      ],
    },
    {
      title: "Problemas técnicos",
      items: [
        "La app no funciona correctamente",
        "No puedo iniciar sesión",
        "No recibo notificaciones",
        "Problemas con los pagos",
      ],
    },
  ]

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">AYUDA</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-6">
          <div className="relative">
            <Input placeholder="Buscar en ayuda" className="pl-10 pr-3 py-1.5 rounded-full border-gray-200" />
            <svg
              className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              ></path>
            </svg>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Preguntas frecuentes</h2>

            {faqCategories.map((category, index) => (
              <div key={index} className="border rounded-lg overflow-hidden">
                <div className="bg-gray-50 p-3 font-medium text-sm">{category.title}</div>
                <div className="divide-y">
                  {category.items.map((item, itemIndex) => (
                    <div
                      key={itemIndex}
                      className="p-3 flex justify-between items-center hover:bg-gray-50 cursor-pointer"
                      onClick={() => {
                        setActiveCategory(index)
                        setActiveItem(itemIndex)
                        setActiveModal("faq")
                      }}
                    >
                      <span className="text-sm">{item}</span>
                      <ChevronRight className="h-4 w-4 text-gray-400" />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Contacto</h2>

            <Button variant="outline" className="w-full justify-between" onClick={() => setActiveModal("contacto")}>
              <span>Contactar con soporte</span>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>

            <Button variant="outline" className="w-full justify-between" onClick={() => setActiveModal("chat")}>
              <span>Chat con soporte</span>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>

            <Button variant="outline" className="w-full justify-between" onClick={() => setActiveModal("reporte")}>
              <span>Reportar un problema</span>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
          </div>
        </div>
      </div>

      {/* Modales de ayuda */}
      <HelpModal
        isOpen={activeModal === "faq" && activeCategory !== null && activeItem !== null}
        onClose={() => setActiveModal(null)}
        title={activeCategory !== null && activeItem !== null ? faqCategories[activeCategory].items[activeItem] : ""}
        description="Información detallada sobre esta pregunta"
        content={
          <div className="space-y-4">
            <p>
              {activeCategory !== null && activeItem !== null
                ? `Respuesta detallada para la pregunta: ${faqCategories[activeCategory].items[activeItem]}`
                : ""}
            </p>
            <p className="text-sm text-gray-600">
              Si necesitas más información, puedes contactar con nuestro equipo de soporte a través de la opción
              "Contactar con soporte".
            </p>
          </div>
        }
      />

      <HelpModal
        isOpen={activeModal === "contacto"}
        onClose={() => setActiveModal(null)}
        title="Contactar con soporte"
        description="Envíanos un mensaje y te responderemos lo antes posible"
        content={
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Asunto</label>
              <Input placeholder="Escribe el asunto de tu consulta" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Mensaje</label>
              <textarea
                className="w-full p-2 border rounded-md min-h-[100px]"
                placeholder="Describe tu problema o consulta con detalle"
              ></textarea>
            </div>
            <Button className="w-full">Enviar mensaje</Button>
          </div>
        }
      />

      <HelpModal
        isOpen={activeModal === "chat"}
        onClose={() => setActiveModal(null)}
        title="Chat con soporte"
        description="Habla en tiempo real con nuestro equipo de soporte"
        content={
          <div className="space-y-4">
            <div className="bg-gray-100 p-3 rounded-lg">
              <p className="text-sm text-center">
                Nuestro horario de atención es de lunes a viernes de 9:00 a 18:00. Tiempo estimado de espera: 5 minutos.
              </p>
            </div>
            <Button className="w-full">Iniciar chat</Button>
          </div>
        }
      />

      <HelpModal
        isOpen={activeModal === "reporte"}
        onClose={() => setActiveModal(null)}
        title="Reportar un problema"
        description="Informa de cualquier error o problema que hayas encontrado"
        content={
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Tipo de problema</label>
              <select className="w-full p-2 border rounded-md">
                <option>Error en la aplicación</option>
                <option>Problema con un usuario</option>
                <option>Problema con un pago</option>
                <option>Contenido inapropiado</option>
                <option>Otro</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Descripción</label>
              <textarea
                className="w-full p-2 border rounded-md min-h-[100px]"
                placeholder="Describe el problema con el mayor detalle posible"
              ></textarea>
            </div>
            <Button className="w-full">Enviar reporte</Button>
          </div>
        }
      />

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
