import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function CambiarCuentaPage() {
  const accounts = [
    { id: 1, name: "Tu Nombre", username: "@tu_usuario", image: "/images/profiles/profile1.jpeg", active: true },
    {
      id: 2,
      name: "Cuenta Profesional",
      username: "@tu_negocio",
      image: "/images/profiles/profile2.jpeg",
      active: false,
    },
  ]

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">CAMBIAR DE CUENTA</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <p className="text-sm text-gray-500 mb-6">
          Selecciona la cuenta con la que deseas iniciar sesión o crea una nueva.
        </p>

        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="font-medium text-sm">Tus cuentas</h2>

            {accounts.map((account) => (
              <div
                key={account.id}
                className={`flex items-center p-4 rounded-lg ${account.active ? "bg-blue-50 border border-blue-200" : "bg-gray-50"}`}
              >
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                  <img
                    src={account.image || "/placeholder.svg"}
                    alt={account.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{account.name}</p>
                  <p className="text-xs text-gray-500">{account.username}</p>
                </div>
                {account.active ? (
                  <span className="text-xs font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded-full">Activa</span>
                ) : (
                  <Button variant="ghost" className="text-blue-600 text-sm">
                    Cambiar
                  </Button>
                )}
              </div>
            ))}
          </div>

          <div className="space-y-4">
            <Button className="w-full rounded-full border border-gray-300 text-sm py-2 flex items-center justify-center gap-2">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="16" />
                <line x1="8" y1="12" x2="16" y2="12" />
              </svg>
              Añadir cuenta
            </Button>

            <Button className="w-full rounded-full border border-gray-300 text-sm py-2 flex items-center justify-center gap-2">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="8.5" cy="7" r="4" />
                <line x1="20" y1="8" x2="20" y2="14" />
                <line x1="23" y1="11" x2="17" y2="11" />
              </svg>
              Crear cuenta nueva
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
