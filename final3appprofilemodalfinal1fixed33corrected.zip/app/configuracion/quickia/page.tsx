"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Sparkles, Search, User, Clock, Filter, Brain, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { toast } from "sonner"

export default function QuickIAPage() {
  const [aiEnabled, setAiEnabled] = useState(true)
  const [smartMatching, setSmartMatching] = useState(true)
  const [marketTrends, setMarketTrends] = useState(true)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background border-b border-border">
        <div className="flex items-center p-4">
          <Link href="/configuracion">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex items-center">
            <h1 className="text-xl font-semibold">QuickIA</h1>
            <Badge variant="outline" className="ml-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white border-0">
              Beta
            </Badge>
          </div>
        </div>
      </header>

      {/* Contenido */}
      <div className="p-4 space-y-6">
        <Card className="border border-purple-100 dark:border-purple-900/30 bg-gradient-to-br from-white to-purple-50 dark:from-background dark:to-purple-950/10">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Brain className="h-5 w-5 mr-2 text-purple-500" />
              ¿Qué es QuickIA?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground leading-relaxed">
              QuickIA es nuestro asistente inteligente que utiliza tecnología de inteligencia artificial para ayudarte a
              encontrar perfiles y servicios que se ajusten perfectamente a tus necesidades. Analiza tus preferencias,
              historial de búsqueda y las tendencias actuales del mercado para ofrecerte resultados personalizados y
              relevantes en tiempo récord.
            </p>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <h2 className="text-lg font-medium flex items-center">
            <Sparkles className="h-5 w-5 mr-2 text-purple-500" />
            Funciones principales
          </h2>

          <div className="grid gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center">
                  <Search className="h-4 w-4 mr-2 text-purple-500" />
                  Búsqueda inteligente
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Encuentra perfiles y servicios utilizando lenguaje natural. Simplemente describe lo que necesitas y
                  QuickIA se encargará del resto.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center">
                  <User className="h-4 w-4 mr-2 text-purple-500" />
                  Coincidencia personalizada
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Recibe recomendaciones basadas en tus preferencias, historial de interacciones y valoraciones previas
                  para encontrar los perfiles más compatibles.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-purple-500" />
                  Predicción de disponibilidad
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Anticipa la disponibilidad de los profesionales según patrones históricos y programación actual para
                  optimizar tus solicitudes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center">
                  <Filter className="h-4 w-4 mr-2 text-purple-500" />
                  Análisis de tendencias
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Mantente al día con las demandas del mercado y descubre servicios emergentes que podrían interesarte
                  según las tendencias actuales.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <h2 className="text-lg font-medium flex items-center">
            <Zap className="h-5 w-5 mr-2 text-purple-500" />
            Configuración
          </h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Activar QuickIA</p>
                <p className="text-sm text-muted-foreground">Habilita las funciones de inteligencia artificial</p>
              </div>
              <Switch
                checked={aiEnabled}
                onCheckedChange={(checked) => {
                  setAiEnabled(checked)
                  toast({
                    title: checked ? "QuickIA activado" : "QuickIA desactivado",
                    description: checked
                      ? "Las funciones de IA están ahora disponibles"
                      : "Las funciones de IA han sido desactivadas",
                    duration: 2000,
                  })
                }}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Coincidencia inteligente</p>
                <p className="text-sm text-muted-foreground">Recomendaciones basadas en tus preferencias</p>
              </div>
              <Switch checked={smartMatching} onCheckedChange={setSmartMatching} disabled={!aiEnabled} />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Análisis de mercado</p>
                <p className="text-sm text-muted-foreground">Sugerencias basadas en tendencias actuales</p>
              </div>
              <Switch checked={marketTrends} onCheckedChange={setMarketTrends} disabled={!aiEnabled} />
            </div>
          </div>
        </div>

        <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg mt-6">
          <p className="text-sm text-center text-purple-700 dark:text-purple-300">
            QuickIA está en fase beta. Tus comentarios nos ayudan a mejorar.
          </p>
          <div className="flex justify-center mt-2">
            <Button
              variant="outline"
              size="sm"
              className="text-xs border-purple-200 dark:border-purple-800 hover:bg-purple-100 dark:hover:bg-purple-900/30"
              onClick={() => {
                toast({
                  title: "¡Gracias por tu interés!",
                  description: "Pronto habilitaremos un formulario para recibir tus comentarios sobre QuickIA.",
                  duration: 3000,
                })
              }}
            >
              Enviar comentarios
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
