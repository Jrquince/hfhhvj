import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header Skeleton */}
      <header className="sticky top-0 z-10 bg-background border-b border-border">
        <div className="flex items-center p-4">
          <Skeleton className="h-10 w-10 rounded-full mr-2" />
          <Skeleton className="h-6 w-32" />
        </div>
      </header>

      {/* Content Skeleton */}
      <div className="p-4 space-y-6">
        <Skeleton className="h-32 w-full rounded-lg" />

        <div className="space-y-4">
          <Skeleton className="h-6 w-40" />

          <div className="grid gap-4">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-24 w-full rounded-lg" />
            ))}
          </div>
        </div>

        <Skeleton className="h-1 w-full" />

        <div className="space-y-4">
          <Skeleton className="h-6 w-40" />

          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between">
                <div>
                  <Skeleton className="h-5 w-32 mb-2" />
                  <Skeleton className="h-4 w-48" />
                </div>
                <Skeleton className="h-6 w-12 rounded-full" />
              </div>
            ))}
          </div>
        </div>

        <Skeleton className="h-24 w-full rounded-lg mt-6" />
      </div>
    </div>
  )
}
