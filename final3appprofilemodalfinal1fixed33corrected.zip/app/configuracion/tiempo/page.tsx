import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function TiempoEnPantallaPage() {
  // Datos de ejemplo para el gráfico
  const weekData = [
    { day: "Lun", hours: 2.5 },
    { day: "Mar", hours: 1.8 },
    { day: "Mié", hours: 3.2 },
    { day: "Jue", hours: 2.1 },
    { day: "Vie", hours: 4.5 },
    { day: "Sáb", hours: 3.7 },
    { day: "Dom", hours: 2.9 },
  ]

  // Encontrar el valor máximo para escalar el gráfico
  const maxHours = Math.max(...weekData.map((d) => d.hours))

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">TIEMPO EN PANTALLA</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <p className="text-sm text-gray-500 mb-6">
          Revisa cuánto tiempo pasas usando la aplicación y establece límites si lo deseas.
        </p>

        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h2 className="font-medium text-sm mb-4">Uso esta semana</h2>

            <div className="flex items-end justify-between h-40 mb-2">
              {weekData.map((item, index) => (
                <div key={index} className="flex flex-col items-center w-8">
                  <div
                    className="w-6 bg-blue-500 rounded-t-md"
                    style={{ height: `${(item.hours / maxHours) * 100}%` }}
                  ></div>
                  <span className="text-xs mt-1">{item.day}</span>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center mt-4">
              <div>
                <p className="text-xs text-gray-500">Promedio diario</p>
                <p className="font-medium">2.9 horas</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Total semanal</p>
                <p className="font-medium">20.7 horas</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-sm">Desglose por secciones</h2>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                  <span className="text-sm">Chat</span>
                </div>
                <span className="text-sm">45%</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                  <span className="text-sm">Explorar servicios</span>
                </div>
                <span className="text-sm">30%</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                  <span className="text-sm">Perfil</span>
                </div>
                <span className="text-sm">15%</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-purple-500 mr-2"></div>
                  <span className="text-sm">Otros</span>
                </div>
                <span className="text-sm">10%</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-sm">Límites de tiempo</h2>

            <Button className="w-full rounded-full border border-gray-300 text-sm py-2">
              Establecer límite diario
            </Button>

            <Button className="w-full rounded-full border border-gray-300 text-sm py-2">
              Establecer recordatorio de descanso
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
