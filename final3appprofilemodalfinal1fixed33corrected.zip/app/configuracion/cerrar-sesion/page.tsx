import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function CerrarSesionPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">CERRAR SESIÓN</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <div className="flex flex-col items-center justify-center py-12">
          <div className="w-24 h-24 bg-gray-200 rounded-full mb-6 overflow-hidden">
            <img src="/images/profiles/profile1.jpeg" alt="Foto de perfil" className="w-full h-full object-cover" />
          </div>
          <h2 className="font-bold text-lg">Tu Nombre</h2>
          <p className="text-sm text-gray-500 mb-8">@tu_usuario</p>

          <div className="space-y-4 w-full">
            <Button className="w-full rounded-full bg-red-600 text-white py-2">Cerrar sesión</Button>

            <p className="text-xs text-gray-500 text-center">
              Al cerrar sesión, no recibirás notificaciones hasta que vuelvas a iniciar sesión.
            </p>
          </div>
        </div>

        <div className="mt-12 space-y-4">
          <h2 className="font-medium text-sm">Opciones adicionales</h2>

          <div className="flex justify-between items-center py-3 border-b border-gray-100">
            <div>
              <p className="text-sm font-medium">Cerrar sesión en todos los dispositivos</p>
              <p className="text-xs text-gray-500">
                Cierra sesión en todos los dispositivos donde hayas iniciado sesión
              </p>
            </div>
            <Button variant="ghost" className="text-blue-600 text-sm">
              Cerrar
            </Button>
          </div>

          <div className="flex justify-between items-center py-3 border-b border-gray-100">
            <div>
              <p className="text-sm font-medium text-red-600">Eliminar cuenta</p>
              <p className="text-xs text-gray-500">Esta acción no se puede deshacer</p>
            </div>
            <Button variant="ghost" className="text-red-600 text-sm">
              Eliminar
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
