import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export default function PreferenciasPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">PREFERENCIAS</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="font-medium text-base">Apariencia</h2>

            <div>
              <p className="text-sm font-medium mb-2">Tema</p>
              <RadioGroup defaultValue="system" className="space-y-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="light" id="light" />
                  <Label htmlFor="light">Claro</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="dark" id="dark" />
                  <Label htmlFor="dark">Oscuro</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="system" id="system" />
                  <Label htmlFor="system">Usar configuración del sistema</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Reducir animaciones</p>
                <p className="text-xs text-gray-500">Reduce las animaciones de la interfaz</p>
              </div>
              <Switch />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Contenido</h2>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Autoplay de vídeos</p>
                <p className="text-xs text-gray-500">Reproducir vídeos automáticamente</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Calidad de imágenes</p>
                <p className="text-xs text-gray-500">Usar imágenes en alta calidad</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div>
              <p className="text-sm font-medium mb-2">Filtro de contenido</p>
              <RadioGroup defaultValue="moderado" className="space-y-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="desactivado" id="desactivado" />
                  <Label htmlFor="desactivado">Desactivado</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="moderado" id="moderado" />
                  <Label htmlFor="moderado">Moderado</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="estricto" id="estricto" />
                  <Label htmlFor="estricto">Estricto</Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Accesibilidad</h2>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Texto a voz</p>
                <p className="text-xs text-gray-500">Activar narración de texto</p>
              </div>
              <Switch />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Tamaño de texto</p>
                <p className="text-xs text-gray-500">Usar tamaño de texto del sistema</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Alto contraste</p>
                <p className="text-xs text-gray-500">Mejorar visibilidad de elementos</p>
              </div>
              <Switch />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
