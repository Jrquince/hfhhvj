import { ArrowLeft, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export default function IdiomaPage() {
  const languages = [
    { code: "es", name: "Español", region: "España" },
    { code: "es-LA", name: "Español", region: "Latinoamérica" },
    { code: "en", name: "English", region: "United States" },
    { code: "en-GB", name: "English", region: "United Kingdom" },
    { code: "fr", name: "Français", region: "France" },
    { code: "de", name: "Deutsch", region: "Deutschland" },
    { code: "it", name: "Italiano", region: "Italia" },
    { code: "pt", name: "Português", region: "Brasil" },
    { code: "pt-PT", name: "Português", region: "Portugal" },
    { code: "ca", name: "Català", region: "Catalunya" },
    { code: "eu", name: "Euskara", region: "Euskadi" },
    { code: "gl", name: "Galego", region: "Galicia" },
  ]

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">IDIOMA</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="font-medium text-base">Selecciona tu idioma</h2>

            <RadioGroup defaultValue="es" className="space-y-2">
              {languages.map((language) => (
                <div key={language.code} className="flex items-center justify-between border rounded-lg p-3">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value={language.code} id={language.code} />
                    <div>
                      <Label htmlFor={language.code} className="font-medium">
                        {language.name}
                      </Label>
                      <p className="text-xs text-gray-500">{language.region}</p>
                    </div>
                  </div>
                  {language.code === "es" && <Check className="h-4 w-4 text-green-500" />}
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Configuración regional</h2>

            <div className="flex justify-between items-center border-b pb-2">
              <div>
                <p className="text-sm font-medium">Formato de fecha</p>
                <p className="text-xs text-gray-500">Cómo se muestran las fechas</p>
              </div>
              <div className="text-sm">DD/MM/AAAA</div>
            </div>

            <div className="flex justify-between items-center border-b pb-2">
              <div>
                <p className="text-sm font-medium">Formato de hora</p>
                <p className="text-xs text-gray-500">Cómo se muestra la hora</p>
              </div>
              <div className="text-sm">24 horas</div>
            </div>

            <div className="flex justify-between items-center border-b pb-2">
              <div>
                <p className="text-sm font-medium">Moneda</p>
                <p className="text-xs text-gray-500">Moneda predeterminada</p>
              </div>
              <div className="text-sm">EUR (€)</div>
            </div>
          </div>

          <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-white">Guardar cambios</Button>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
