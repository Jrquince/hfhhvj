import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Input } from "@/components/ui/input"

export default function SeguridadPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/configuracion">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">SEGURIDAD</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="font-medium text-base">Acceso a la cuenta</h2>

            <div>
              <p className="text-sm font-medium mb-2">Cambiar contraseña</p>
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Contraseña actual</label>
                  <Input type="password" className="border rounded-md" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Nueva contraseña</label>
                  <Input type="password" className="border rounded-md" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Confirmar nueva contraseña</label>
                  <Input type="password" className="border rounded-md" />
                </div>
                <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-white">Actualizar contraseña</Button>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Verificación en dos pasos</h2>

            <div>
              <p className="text-sm font-medium mb-1">Estado</p>
              <p className="text-xs text-red-500 mb-3">No activado</p>
              <p className="text-xs text-gray-500 mb-3">
                La verificación en dos pasos añade una capa adicional de seguridad a tu cuenta. Además de tu contraseña,
                necesitarás un código de verificación para iniciar sesión.
              </p>
              <Button variant="outline" className="w-full text-sm">
                Activar verificación en dos pasos
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-medium text-base">Sesiones activas</h2>

            <div className="border rounded-lg p-3">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium">iPhone 13 Pro</p>
                  <p className="text-xs text-gray-500">Madrid, España • Ahora</p>
                </div>
                <div className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Actual</div>
              </div>
            </div>

            <div className="border rounded-lg p-3">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium">MacBook Pro</p>
                  <p className="text-xs text-gray-500">Madrid, España • Hace 2 horas</p>
                </div>
                <Button variant="ghost" size="sm" className="text-xs text-red-500 h-7">
                  Cerrar
                </Button>
              </div>
            </div>

            <div className="border rounded-lg p-3">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium">iPad Air</p>
                  <p className="text-xs text-gray-500">Barcelona, España • Hace 3 días</p>
                </div>
                <Button variant="ghost" size="sm" className="text-xs text-red-500 h-7">
                  Cerrar
                </Button>
              </div>
            </div>

            <Button variant="outline" className="w-full text-sm text-red-500 border-red-200">
              Cerrar todas las sesiones
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
