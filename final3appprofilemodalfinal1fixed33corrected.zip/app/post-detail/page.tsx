import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, MessageCircle, MapPin, Plus, Bookmark, User, Heart, Send } from "lucide-react"
import { Avatar } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

// Custom Home icon since we need a filled version
const HomeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
    <polyline points="9 22 9 12 15 12 15 22" stroke="white" strokeWidth="2" fill="white" />
  </svg>
)

export default function PostDetailPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col">
      {/* Header with search */}
      <div className="p-4 flex items-center justify-between">
        <div className="relative flex-1 max-w-[85%]">
          <Input placeholder="Search" className="pl-3 pr-8 py-1.5 rounded-full border-gray-200 text-sm h-9" />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
        <Link href="/survey-post">
          <Button
            variant="ghost"
            size="icon"
            className="ml-2 rounded-full bg-black text-white h-9 w-9 flex items-center justify-center"
          >
            <MessageCircle className="h-5 w-5" />
          </Button>
        </Link>
      </div>

      {/* Navigation tabs */}
      <Tabs defaultValue="recientes" className="w-full">
        <TabsList className="w-full justify-between bg-transparent border-b h-10 px-2">
          <TabsTrigger
            value="recientes"
            className="text-xs data-[state=active]:border-b-2 data-[state=active]:border-black data-[state=active]:rounded-none data-[state=active]:shadow-none px-2"
          >
            Recientes
          </TabsTrigger>
          <TabsTrigger
            value="profesionales"
            className="text-xs data-[state=active]:border-b-2 data-[state=active]:border-black data-[state=active]:rounded-none data-[state=active]:shadow-none px-2"
          >
            Profesionales
          </TabsTrigger>
          <TabsTrigger
            value="trabajos"
            className="text-xs data-[state=active]:border-b-2 data-[state=active]:border-black data-[state=active]:rounded-none data-[state=active]:shadow-none px-2"
          >
            Trabajos
          </TabsTrigger>
          <Link href="/map" className="flex-1 text-center">
            <TabsTrigger
              value="mapa"
              className="text-xs data-[state=active]:border-b-2 data-[state=active]:border-black data-[state=active]:rounded-none data-[state=active]:shadow-none px-2 w-full"
            >
              Mapa
            </TabsTrigger>
          </Link>
        </TabsList>
      </Tabs>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {/* User profile */}
        <div className="p-4">
          <div className="flex items-center mb-3">
            <Avatar className="h-10 w-10 border">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="User avatar"
                width={40}
                height={40}
                className="rounded-full"
              />
            </Avatar>
            <div className="ml-3">
              <h3 className="font-medium text-sm">Fernando Gómez</h3>
              <div className="flex items-center">
                <span className="text-xs text-gray-500 mr-2">Sevilla, España</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Flat tire image */}
          <div className="rounded-xl overflow-hidden relative mb-4">
            <Image
              src="/placeholder.svg?height=300&width=400"
              alt="Flat tire"
              width={400}
              height={300}
              className="w-full object-cover"
            />

            <Button variant="ghost" size="icon" className="absolute top-2 right-2 text-white hover:text-gray-200">
              <Bookmark className="h-5 w-5" />
            </Button>

            {/* Pagination dots */}
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-1">
              <div className="w-2 h-2 rounded-full bg-white"></div>
              <div className="w-2 h-2 rounded-full bg-white/50"></div>
              <div className="w-2 h-2 rounded-full bg-white/50"></div>
            </div>
          </div>

          <div className="flex justify-between items-center text-xs text-gray-500 px-1">
            <div className="flex items-center">
              <span className="font-medium">Profesional</span>
              <span className="mx-1">•</span>
              <span>22/05/25</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                <Heart className="h-5 w-5 text-gray-400" />
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                <Send className="h-5 w-5 text-gray-400" />
              </Button>
            </div>
          </div>
        </div>

        {/* Second user post (partial) */}
        <div className="p-4 pt-2">
          <div className="flex items-center mb-3">
            <Avatar className="h-10 w-10 border">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="User avatar"
                width={40}
                height={40}
                className="rounded-full"
              />
            </Avatar>
            <div className="ml-3">
              <h3 className="font-medium text-sm">Ana Urrutia</h3>
              <div className="flex items-center">
                <span className="text-xs text-gray-500 mr-2">Sevilla, España</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Partial post visible */}
          <div className="border rounded-xl overflow-hidden h-24 relative mb-2">
            <Image
              src="/placeholder.svg?height=200&width=400"
              alt="Post image"
              width={400}
              height={200}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <div className="border-t flex justify-around py-3 bg-white">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <HomeIcon />
          </Button>
        </Link>
        <Link href="/map">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <MapPin className="h-6 w-6" />
          </Button>
        </Link>
        <Button
          variant="default"
          size="icon"
          className="h-12 w-12 rounded-full bg-black flex flex-col items-center justify-center"
        >
          <Plus className="h-6 w-6" />
        </Button>
        <Link href="/saved">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <Bookmark className="h-6 w-6" />
          </Button>
        </Link>
        <Link href="/profile">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <User className="h-6 w-6" />
          </Button>
        </Link>
      </div>
    </div>
  )
}
