"use client"

import { useState, useEffect } from "react"
import {
  ArrowLeft,
  Bookmark,
  Share2,
  Star,
  Home,
  MapPin,
  Calendar,
  Clock,
  User,
  MessageCircle,
  X,
  AlertCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import { BottomNavigation } from "@/components/bottom-navigation"
import { ProfileImage } from "@/components/profile-image"
import { toast } from "@/components/ui/use-toast"

// Generador de datos de ejemplo para posts
const generatePostData = (postId: number) => {
  // Categorías
  const categories = ["Vivienda", "Profesionales", "Hogar", "Educación", "Motor", "Tecnología", "Mascotas", "Eventos"]

  // Títulos
  const titles = [
    "Busco un compañero de piso que esté estudiando para el curso 2025/2026 en la zona de Deusto.",
    "Necesito ayuda para montar un mueble de Ikea en mi apartamento en Bagatza",
    "Ofrezco servicios de fontanería en toda la zona de Bilbao",
    "Busco profesor/a particular de matemáticas para nivel universitario",
    "Vendo coche seminuevo en perfecto estado. 50.000km",
    "Necesito reparación urgente de mi ordenador portátil. No enciende",
    "Busco paseador/a para mi perro durante las mañanas",
    "Ofrezco servicios de limpieza por horas. Experiencia demostrable",
    "Vendo moto en perfecto estado. Recién revisada",
    "Busco compañeros para compartir gastos de viaje a Portugal",
    "Se ofrece profesor de inglés nativo para clases particulares",
    "Necesito ayuda con mudanza este fin de semana",
    "Ofrezco servicios de diseño gráfico para pequeñas empresas",
    "Busco canguro para niños de 5 y 7 años, tardes entre semana",
    "Vendo bicicleta de montaña casi sin uso",
  ]

  // Descripciones
  const descriptions = [
    "Soy estudiante de segundo año en la Universidad de Deusto y estoy buscando un compañero para compartir habitación en el barrio de Indautxu, a menos de 10 minutos de la universidad. El piso tiene 3 habitaciones, 2 baños, cocina equipada y salón amplio. El precio es de 350€ al mes por persona, gastos incluidos. Se busca persona responsable, ordenada y tranquila.",
    "Necesito ayuda para montar un armario de Ikea modelo PAX. Tengo todas las piezas y herramientas básicas, pero necesito alguien con experiencia que me ayude a montarlo correctamente. El trabajo no debería llevar más de 2 horas. Ofrezco 30€ por el servicio.",
    "Fontanero profesional con más de 10 años de experiencia. Ofrezco servicios de reparación, instalación y mantenimiento de sistemas de fontanería. Presupuesto sin compromiso. Disponibilidad inmediata para urgencias. Precios competitivos y trabajo garantizado.",
    "Busco profesor/a particular de matemáticas para nivel universitario. Necesito ayuda con cálculo diferencial e integral. Preferiblemente con experiencia en docencia universitaria. Disponibilidad 2 horas semanales, preferiblemente tardes. Presupuesto: 20€/hora.",
    "Vendo Seat León 1.6 TDI del año 2018 con 50.000km. Único propietario, siempre en garaje. Mantenimientos al día en concesionario oficial. Equipamiento: climatizador, navegador, sensores de aparcamiento, llantas de aleación. Precio: 12.500€ negociables.",
    "Necesito técnico informático para reparar mi portátil HP que no enciende. Estaba funcionando perfectamente hasta ayer. Al pulsar el botón de encendido, las luces se encienden brevemente pero luego se apaga. Necesito solución urgente por temas de trabajo.",
    "Busco persona responsable para pasear a mi perro (labrador de 3 años) de lunes a viernes por las mañanas, entre 9:00 y 11:00. El paseo debe durar al menos 45 minutos. Zona: Abando. Ofrezco 8€ por paseo o 150€ mensuales.",
    "Ofrezco servicios de limpieza por horas. Experiencia demostrable en limpieza de hogares y oficinas. Disponibilidad flexible. Productos propios o del cliente según preferencia. Tarifa: 12€/hora. Referencias disponibles.",
    "Vendo Honda CBR 500R del año 2020 con 8.000km. Siempre en garaje, revisiones al día. Estado impecable, sin caídas. Incluye baúl trasero y soporte para móvil. Precio: 5.800€. No acepto cambios.",
    "Busco 3-4 personas para compartir gastos de viaje a Portugal (Lisboa y Oporto) del 15 al 22 de agosto. Tengo coche propio para el desplazamiento. Alojamiento en hostales/apartamentos económicos. Presupuesto aproximado: 400€ por persona (transporte, alojamiento y parte de comidas).",
    "Profesor nativo de inglés (Londres) ofrece clases particulares para todos los niveles. Experiencia en preparación de exámenes oficiales (Cambridge, TOEFL, IELTS). Metodología comunicativa y personalizada. Clases presenciales u online. Tarifa: 25€/hora.",
    "Necesito ayuda con mudanza este fin de semana. Son pocos muebles (cama, sofá, mesa, sillas y unas 10 cajas). La mudanza es dentro de la misma ciudad, de Deusto a Santutxu. Ofrezco 50€ por 2-3 horas de ayuda el sábado por la mañana.",
    "Diseñador gráfico freelance ofrece servicios para pequeñas empresas: logotipos, identidad corporativa, material promocional, diseño web básico. Portfolio disponible. Precios ajustados a cada proyecto. Primera consulta gratuita.",
    "Familia busca canguro para niños de 5 y 7 años. Horario: lunes a jueves de 17:00 a 20:00. Responsabilidades: recoger del colegio, ayudar con deberes, preparar merienda, juegos. Imprescindible experiencia con niños. Zona: Getxo. Salario: 10€/hora.",
    "Vendo bicicleta de montaña Trek Marlin 7 talla M. Comprada hace 6 meses, usada solo 3 veces. Estado impecable, como nueva. Incluyo casco, luces y candado. Precio original 850€, vendo por 650€. No negociable.",
  ]

  // Usuarios
  const users = [
    { name: "Diego Domínguez", avatar: "DD", rating: 4.8, verified: true, location: "Bilbao, Vizcaya", profileId: 1 },
    { name: "Ana Urrutia", avatar: "AU", rating: 4.5, verified: true, location: "Bilbao, Vizcaya", profileId: 2 },
    { name: "Jaime Díaz", avatar: "JD", rating: 4.9, verified: true, location: "Bilbao, Vizcaya", profileId: 3 },
    { name: "María Ruiz", avatar: "MR", rating: 4.7, verified: false, location: "Sevilla, España", profileId: 8 },
    { name: "Pablo Arzar", avatar: "PA", rating: 4.6, verified: true, location: "Madrid, España", profileId: 4 },
    { name: "Lucía Gómez", avatar: "LG", rating: 4.9, verified: true, location: "Valencia, España", profileId: 9 },
    { name: "Carlos Martín", avatar: "CM", rating: 4.4, verified: false, location: "Barcelona, España", profileId: 7 },
    { name: "Elena Sánchez", avatar: "ES", rating: 4.7, verified: true, location: "Málaga, España", profileId: 10 },
    {
      name: "Roberto Fernández",
      avatar: "RF",
      rating: 4.8,
      verified: true,
      location: "Zaragoza, España",
      profileId: 6,
    },
    { name: "Sofía López", avatar: "SL", rating: 4.5, verified: false, location: "Murcia, España", profileId: 5 },
  ]

  // Características según categoría
  const featuresByCategory = {
    Vivienda: [
      { icon: "home", text: "3 habitaciones" },
      { icon: "shower", text: "2 baños" },
      { icon: "utensils", text: "Cocina equipada" },
      { icon: "wifi", text: "WiFi incluido" },
    ],
    Profesionales: [
      { icon: "briefcase", text: "Experiencia: 5+ años" },
      { icon: "clock", text: "Disponibilidad inmediata" },
      { icon: "check-circle", text: "Servicio garantizado" },
      { icon: "credit-card", text: "Múltiples formas de pago" },
    ],
    Hogar: [
      { icon: "tool", text: "Herramientas propias" },
      { icon: "shield", text: "Servicio asegurado" },
      { icon: "clock", text: "Puntualidad garantizada" },
      { icon: "thumbs-up", text: "Satisfacción garantizada" },
    ],
    Educación: [
      { icon: "book", text: "Material incluido" },
      { icon: "users", text: "Individual o grupos" },
      { icon: "video", text: "Clases online disponibles" },
      { icon: "award", text: "Certificación oficial" },
    ],
    Motor: [
      { icon: "calendar", text: "Año: 2020" },
      { icon: "activity", text: "Kilómetros: 50.000" },
      { icon: "tool", text: "Mantenimiento al día" },
      { icon: "shield", text: "Garantía incluida" },
    ],
    Tecnología: [
      { icon: "cpu", text: "Servicio técnico oficial" },
      { icon: "clock", text: "Reparación en 24h" },
      { icon: "home", text: "Servicio a domicilio" },
      { icon: "shield", text: "Garantía de reparación" },
    ],
    Mascotas: [
      { icon: "heart", text: "Trato cariñoso" },
      { icon: "award", text: "Experiencia con animales" },
      { icon: "map", text: "Rutas variadas" },
      { icon: "shield", text: "Seguro de responsabilidad" },
    ],
    Eventos: [
      { icon: "users", text: "Capacidad: 10 personas" },
      { icon: "map-pin", text: "Ubicación céntrica" },
      { icon: "calendar", text: "Fechas flexibles" },
      { icon: "music", text: "Equipo de sonido incluido" },
    ],
  }

  // Seleccionar datos basados en el ID
  const titleIndex = postId % titles.length
  const descriptionIndex = postId % descriptions.length
  const userIndex = postId % users.length
  const categoryIndex = postId % categories.length

  const category = categories[categoryIndex]
  const features = featuresByCategory[category as keyof typeof featuresByCategory] || []

  // Generar fecha aleatoria reciente
  const date = new Date()
  date.setDate(date.getDate() - (postId % 30))
  const formattedDate = date.toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit", year: "2-digit" })

  // Generar hora aleatoria
  const hours = Math.floor(Math.random() * 24)
    .toString()
    .padStart(2, "0")
  const minutes = Math.floor(Math.random() * 60)
    .toString()
    .padStart(2, "0")
  const time = `${hours}:${minutes}`

  // Generar precio aleatorio según categoría
  let price = ""
  if (category === "Vivienda") {
    price = `${300 + (postId % 10) * 50}€/mes`
  } else if (category === "Profesionales" || category === "Hogar" || category === "Educación") {
    price = `${15 + (postId % 20)}€/hora`
  } else if (category === "Motor") {
    price = `${5000 + (postId % 20) * 500}€`
  } else if (category === "Tecnología") {
    price = `${50 + (postId % 10) * 20}€`
  } else {
    price = `${20 + (postId % 15) * 5}€`
  }

  // Seleccionar imágenes según la categoría
  let images = []
  if (category === "Vivienda") {
    images = ["/images/apartment1.png", "/images/apartment2.png", "/images/apartment3.png"]
  } else if (category === "Motor") {
    images = ["/images/car1.png", "/images/car2.png", "/images/car3.png"]
  } else if (category === "Tecnología") {
    images = ["/images/laptop1.png", "/images/laptop2.png", "/images/laptop3.png"]
  } else if (category === "Mascotas") {
    images = ["/images/dog1.png", "/images/dog2.png", "/images/dog3.png"]
  } else {
    images = ["/images/house1.png", "/images/house2.png", "/images/house3.png"]
  }

  return {
    id: postId,
    title: titles[titleIndex],
    description: descriptions[descriptionIndex],
    price,
    location: users[userIndex].location,
    date: formattedDate,
    time,
    category,
    urgent: postId % 3 === 0,
    user: users[userIndex],
    features,
    images,
    timestamp: `Hace ${postId % 24} horas`,
  }
}

// Función para obtener el icono según el tipo de anuncio
const getIconForTitle = (title: string) => {
  const titleLower = title.toLowerCase()

  // Vivienda y alojamiento
  if (
    titleLower.includes("piso") ||
    titleLower.includes("apartamento") ||
    titleLower.includes("vivienda") ||
    titleLower.includes("casa")
  )
    return <Home className="h-3 w-3 mr-1" />

  // Por defecto, usar un icono basado en la categoría
  return <Clock className="h-3 w-3 mr-1" />
}

export default function PostDetailPage({ params }: { params: { id: string } }) {
  const [post, setPost] = useState<any>(null)
  const [isSaved, setIsSaved] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [showUserPanel, setShowUserPanel] = useState(false)
  const [loading, setLoading] = useState(true)

  const postId = Number.parseInt(params.id)

  useEffect(() => {
    // Simular carga de datos
    setLoading(true)
    setTimeout(() => {
      const postData = generatePostData(postId)
      setPost(postData)
      setIsSaved(postId % 4 === 0) // Algunos posts aparecerán guardados inicialmente
      setIsLiked(postId % 5 === 0) // Algunos posts aparecerán con like inicialmente
      setLoading(false)
    }, 500)
  }, [postId])

  const toggleSaved = () => {
    setIsSaved(!isSaved)
  }

  const toggleLiked = () => {
    setIsLiked(!isLiked)
  }

  const nextImage = () => {
    if (!post) return
    setCurrentImageIndex((prev) => (prev + 1) % post.images.length)
  }

  const prevImage = () => {
    if (!post) return
    setCurrentImageIndex((prev) => (prev - 1 + post.images.length) % post.images.length)
  }

  const toggleUserPanel = () => {
    setShowUserPanel(!showUserPanel)
  }

  if (loading) {
    return (
      <div className="max-w-md mx-auto bg-white min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500"></div>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="max-w-md mx-auto bg-white min-h-screen flex items-center justify-center">
        <p>No se encontró el anuncio</p>
      </div>
    )
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={() => {
              navigator.share &&
                navigator
                  .share({
                    title: post.title,
                    text: post.description,
                    url: window.location.href,
                  })
                  .catch((err) => {
                    toast({
                      title: "Compartir",
                      description: "Enlace copiado al portapapeles",
                      duration: 2000,
                    })
                  })
            }}
          >
            <Share2 className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={toggleSaved}>
            <Bookmark className={`h-5 w-5 ${isSaved ? "fill-yellow-500 text-yellow-500" : ""}`} />
          </Button>
        </div>
      </div>

      {/* Tarjeta del anuncio en lugar de la imagen */}
      <div className="p-4">
        <Card className="overflow-hidden shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-0">
            {/* Contenido de la tarjeta - Simplificado sin avatar, nombre, ubicación ni verificación */}
            <div className="p-3">
              <div className="flex items-center mb-2">
                <Badge
                  className={`${post.urgent ? "bg-red-500 hover:bg-red-600" : "bg-black hover:bg-gray-900"} mr-2 text-white`}
                >
                  {post.urgent ? <AlertCircle className="h-3 w-3 mr-1" /> : getIconForTitle(post.title)}
                  {post.urgent ? "Urgente" : post.category}
                </Badge>
                <Badge className="bg-black hover:bg-gray-900 text-white">{post.category}</Badge>
                {post.price && <Badge className="ml-auto bg-black hover:bg-gray-900 text-white">{post.price}</Badge>}
              </div>

              <h3 className="font-medium text-base mb-2">{post.title}</h3>

              {/* Eliminados los botones de guardado y corazón */}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Galería de imágenes */}
      <div className="px-4 mb-4">
        <div className="w-full h-48 bg-gray-200 relative rounded-lg overflow-hidden shadow-md">
          <Image
            src={post.images[currentImageIndex] || "/placeholder.svg"}
            alt={post.title}
            fill
            className="object-cover"
          />

          {/* Image navigation */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-2 top-1/2 transform -translate-y-1/2 h-8 w-8 bg-white/80 rounded-full z-10"
            onClick={prevImage}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M15 18l-6-6 6-6" />
            </svg>
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 bg-white/80 rounded-full z-10"
            onClick={nextImage}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 18l6-6-6-6" />
            </svg>
          </Button>

          {/* Image pagination */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-1">
            {post.images.map((_, index: number) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full ${index === currentImageIndex ? "bg-white" : "bg-white/50"}`}
              ></div>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-4">
        <div className="mb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Calendar className="h-4 w-4 text-gray-500 mr-1" />
              <span className="text-sm text-gray-500">{post.date}</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 text-gray-500 mr-1" />
              <span className="text-sm text-gray-500">Disponible</span>
            </div>
          </div>
        </div>

        {/* User info */}
        <div className="flex items-center mb-6 border-b pb-4">
          <ProfileImage profileId={post.user.profileId} username={post.user.name} size="md" />
          <div className="ml-3">
            <div className="flex items-center">
              <h3 className="font-medium text-sm">{post.user.name}</h3>
              {post.user.verified && (
                <svg className="w-4 h-4 text-blue-500 ml-1" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                    clipRule="evenodd"
                  />
                </svg>
              )}
            </div>
            <div className="flex items-center">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-3 w-3 ${
                      i < Math.floor(post.user.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-xs ml-1">{post.user.rating}</span>
            </div>
          </div>
          <Button variant="outline" size="sm" className="ml-auto rounded-full text-xs" onClick={toggleUserPanel}>
            Ver perfil
          </Button>
        </div>

        {/* Description */}
        <div className="mb-6">
          <h2 className="font-medium text-base mb-2">Descripción</h2>
          <p className="text-sm text-gray-600">{post.description}</p>
        </div>

        {/* Features */}
        <div className="mb-6">
          <h2 className="font-medium text-base mb-3">Características</h2>
          <div className="grid grid-cols-2 gap-3">
            {post.features.map((feature: any, index: number) => (
              <div key={index} className="flex items-center bg-gray-50 p-3 rounded-lg shadow-sm">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mr-2">
                  {getFeatureIcon(feature.icon)}
                </div>
                <span className="text-sm">{feature.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Category */}
        <div className="mb-6">
          <div className="flex items-center bg-gray-50 p-3 rounded-lg shadow-sm">
            <div className="w-8 h-8 bg-black rounded-full flex items-center justify-center mr-2">
              <Home className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm">{post.category}</span>
          </div>
        </div>

        {/* CTA */}
        <div className="flex space-x-3">
          <Link href={`/chat-detail/${postId}`} className="flex-1">
            <Button className="w-full rounded-full bg-black hover:bg-gray-900 text-white">
              <MessageCircle className="h-4 w-4 mr-2" />
              Contactar
            </Button>
          </Link>
          <Button variant="outline" className="rounded-full" onClick={toggleSaved}>
            <Bookmark className={`h-4 w-4 mr-2 ${isSaved ? "fill-yellow-500 text-yellow-500" : ""}`} />
            {isSaved ? "Guardado" : "Guardar"}
          </Button>
        </div>
      </div>

      {/* User panel */}
      {showUserPanel && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-end">
          <div className="bg-white w-4/5 h-full overflow-auto animate-slide-in-right">
            <div className="p-4 border-b sticky top-0 bg-white">
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={toggleUserPanel}>
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="p-6">
              <div className="flex flex-col items-center mb-6">
                <ProfileImage profileId={post.user.profileId} username={post.user.name} size="xl" className="mb-3" />
                <h2 className="font-bold text-lg">{post.user.name}</h2>
                <div className="flex items-center mt-1">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(post.user.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm ml-1">{post.user.rating}</span>
                </div>
                <div className="flex items-center mt-2">
                  <MapPin className="h-4 w-4 text-gray-500 mr-1" />
                  <span className="text-sm text-gray-500">{post.user.location}</span>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <User className="h-5 w-5 text-gray-500 mr-2" />
                    <span className="text-sm">Miembro desde</span>
                  </div>
                  <span className="text-sm font-medium">Marzo 2023</span>
                </div>

                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <MessageCircle className="h-5 w-5 text-gray-500 mr-2" />
                    <span className="text-sm">Tiempo de respuesta</span>
                  </div>
                  <span className="text-sm font-medium">1-2 horas</span>
                </div>

                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-gray-500 mr-2"
                    >
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                    </svg>
                    <span className="text-sm">Verificación</span>
                  </div>
                  <span className="text-sm font-medium">{post.user.verified ? "Verificado" : "No verificado"}</span>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="font-medium text-base mb-3">Otros anuncios de {post.user.name}</h3>
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => {
                    // Generar anuncios ficticios del mismo usuario
                    const otherPost = generatePostData(postId + i * 100)
                    otherPost.user = post.user

                    return (
                      <div key={i} className="border rounded-lg p-3">
                        <h4 className="font-medium text-sm mb-1">{otherPost.title.substring(0, 50)}...</h4>
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-500">{otherPost.category}</span>
                          <span className="text-xs font-medium text-black">{otherPost.price}</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              <Button
                className="w-full rounded-full bg-black hover:bg-gray-900 text-white"
                onClick={() => {
                  window.location.href = `/chat-detail/${postId}`
                }}
              >
                <MessageCircle className="h-4 w-4 mr-2" />
                Contactar
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom navigation */}
      <BottomNavigation />
    </div>
  )
}

// Función para obtener el icono según el tipo
function getFeatureIcon(iconName: string) {
  switch (iconName) {
    case "home":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
          <polyline points="9 22 9 12 15 12 15 22" />
        </svg>
      )
    case "shower":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 22h16" />
          <path d="M8 22v-5" />
          <path d="M16 22v-5" />
          <path d="M3 10h18" />
          <path d="M12 10V3" />
          <path d="M12 3h4" />
        </svg>
      )
    case "utensils":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" />
          <path d="M7 2v20" />
          <path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" />
        </svg>
      )
    case "wifi":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M5 12.55a11 11 0 0 1 14.08 0" />
          <path d="M1.42 9a16 16 0 0 1 21.16 0" />
          <path d="M8.53 16.11a6 6 0 0 1 6.95 0" />
          <path d="M12 20h.01" />
        </svg>
      )
    case "briefcase":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
          <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
        </svg>
      )
    case "clock":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="10" />
          <polyline points="12 6 12 12 16 14" />
        </svg>
      )
    case "check-circle":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
          <polyline points="22 4 12 14.01 9 11.01" />
        </svg>
      )
    case "credit-card":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
          <line x1="1" y1="10" x2="23" y2="10" />
        </svg>
      )
    case "tool":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
        </svg>
      )
    case "shield":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
        </svg>
      )
    case "thumbs-up":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" />
        </svg>
      )
    case "book":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
          <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
        </svg>
      )
    case "users":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      )
    case "video":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polygon points="23 7 16 12 23 17 23 7" />
          <rect x="1" y="5" width="15" height="14" rx="2" ry="2" />
        </svg>
      )
    case "award":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="8" r="7" />
          <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88" />
        </svg>
      )
    case "calendar":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
          <line x1="16" y1="2" x2="16" y2="6" />
          <line x1="8" y1="2" x2="8" y2="6" />
          <line x1="3" y1="10" x2="21" y2="10" />
        </svg>
      )
    case "activity":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
        </svg>
      )
    case "cpu":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="4" y="4" width="16" height="16" rx="2" ry="2" />
          <rect x="9" y="9" width="6" height="6" />
          <line x1="9" y1="1" x2="9" y2="4" />
          <line x1="15" y1="1" x2="15" y2="4" />
          <line x1="9" y1="20" x2="9" y2="23" />
          <line x1="15" y1="20" x2="15" y2="23" />
          <line x1="20" y1="9" x2="23" y2="9" />
          <line x1="20" y1="14" x2="23" y2="14" />
          <line x1="1" y1="9" x2="4" y2="9" />
          <line x1="1" y1="14" x2="4" y2="14" />
        </svg>
      )
    case "heart":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
        </svg>
      )
    case "map":
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polygon points="1 12 3 5 21 5 23 12 21 19 3 19" />
          <line x1="3" y1="5" x2="21" y2="19" />
          <line x1="21" y1="5" x2="3" y2="19" />
        </svg>
      )
    default:
      return (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="12" />
          <line x1="12" y1="16" x2="12.01" y2="16" />
        </svg>
      )
  }
}
