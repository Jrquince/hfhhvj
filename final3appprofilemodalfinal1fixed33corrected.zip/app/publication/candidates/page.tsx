import { ArrowLeft, Bookmark } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import Link from "next/link"
import Image from "next/image"

export default function PublicationCandidatesPage() {
  const candidates = [
    { name: "María Ruiz", type: "Particular", rating: 4.8, image: "/placeholder.svg?height=40&width=40&text=MR" },
    { name: "Pablo Arzar", type: "Particular", rating: 4.8, image: "/placeholder.svg?height=40&width=40&text=PA" },
    { name: "Lucas Gomez", type: "Particular", rating: 4.8, image: "/placeholder.svg?height=40&width=40&text=LG" },
    { name: "Marta Palacio", type: "Particular", rating: 4.8, image: "/placeholder.svg?height=40&width=40&text=MP" },
  ]

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <div className="p-4 flex items-center">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <span className="ml-2 text-sm">Cerrar</span>
      </div>

      <div className="px-6 py-4">
        <div className="bg-gray-50 rounded-xl p-4 mb-6">
          <h1 className="font-bold text-base text-center mb-2">MI PUBLICACIÓN</h1>
          <p className="text-sm text-center">Busco un compañero/a de piso para el año académico 25/26 en Bilbao.</p>
        </div>

        <h2 className="font-medium text-base mb-4">Lista de candidatos apuntados</h2>

        <div className="space-y-4">
          {candidates.map((candidate, index) => (
            <div key={index} className="border rounded-xl p-3 flex items-center justify-between">
              <div className="flex items-center">
                <Avatar className="h-10 w-10 border">
                  <Image
                    src={candidate.image || "/placeholder.svg"}
                    alt={`${candidate.name} avatar`}
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                </Avatar>
                <div className="ml-3">
                  <h3 className="font-medium text-sm">{candidate.name}</h3>
                  <div className="flex items-center">
                    <span className="text-xs text-gray-500">{candidate.type}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="flex items-center">
                  <span className="text-xs mr-1">{candidate.rating}</span>
                  <svg className="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                </div>
                <Link href="/chat-detail/1">
                  <Button className="rounded-full bg-yellow-500 hover:bg-yellow-600 text-white text-xs px-3 py-1 h-7">
                    CHAT
                  </Button>
                </Link>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Bookmark className="h-4 w-4 text-gray-400" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
