import { ArrowLeft, Bookmark } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import Link from "next/link"
import Image from "next/image"

export default function PublicationPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <span className="text-sm font-medium">Cerrar</span>
      </div>

      {/* Publication details */}
      <div className="px-6 pt-2 pb-6">
        <div className="border rounded-xl p-4 mb-8">
          <h1 className="text-lg font-bold text-center mb-2">MI PUBLICACIÓN</h1>
          <p className="text-sm text-center">Busco un compañero/a de piso para el año académico 23/24 en Bilbao.</p>
        </div>

        <h2 className="text-base font-medium mb-4">Lista de candidatos apuntados</h2>

        <div className="space-y-4">
          {[
            { name: "María Ruiz", rating: 4.5, image: "/placeholder.svg?height=40&width=40&text=MR" },
            { name: "Pablo Arzar", rating: 4.3, image: "/placeholder.svg?height=40&width=40&text=PA" },
            { name: "Lucas Gómez", rating: 4.7, image: "/placeholder.svg?height=40&width=40&text=LG" },
            { name: "Marta Palacio", rating: 4.4, image: "/placeholder.svg?height=40&width=40&text=MP" },
          ].map((candidate, index) => (
            <div key={index} className="flex items-center justify-between p-3 border rounded-xl">
              <div className="flex items-center">
                <Avatar className="h-10 w-10 border">
                  <Image
                    src={candidate.image || "/placeholder.svg"}
                    alt={`${candidate.name} avatar`}
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                </Avatar>
                <div className="ml-3">
                  <h3 className="font-medium text-sm">{candidate.name}</h3>
                  <div className="flex items-center">
                    <div className="flex">
                      <span className="text-xs mr-1">{candidate.rating}</span>
                      {[...Array(5)].map((_, i) => (
                        <svg
                          key={i}
                          className="w-3 h-3 text-yellow-400"
                          fill={i < Math.floor(candidate.rating) ? "currentColor" : "none"}
                          stroke="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Link href="/chat-detail">
                  <Button className="rounded-full bg-yellow-500 hover:bg-yellow-600 text-white text-xs px-3 py-1 h-7">
                    Chat
                  </Button>
                </Link>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Bookmark className="h-5 w-5 text-gray-400" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
