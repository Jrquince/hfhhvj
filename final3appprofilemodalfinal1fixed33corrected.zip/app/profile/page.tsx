"use client"

import { useState } from "react"
import {
  ArrowLeft,
  Settings,
  Edit,
  Star,
  Clock,
  Award,
  ChevronRight,
  Bookmark,
  User,
  MapPin,
  Briefcase,
  Shield,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  LogOut,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { BottomNavigation } from "@/components/bottom-navigation"
import { useToast } from "@/hooks/use-toast"
import { getProfileAvatar } from "@/lib/avatar-utils"
import { GamificationModal } from "@/components/gamification-modal"

export default function ProfilePage() {
  const router = useRouter()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("publicaciones")
  const [unreadMessages, setUnreadMessages] = useState(3)
  const [gamificationModalOpen, setGamificationModalOpen] = useState(false)

  // Asegurar que el perfil use la misma imagen
  // Datos de ejemplo para el perfil
  const profile = {
    name: "Diego Domínguez",
    username: "@diegodom",
    bio: "Profesional de la fontanería con más de 10 años de experiencia. Especializado en instalaciones y reparaciones.",
    location: "Bilbao, España",
    memberSince: "Marzo 2023",
    occupation: "Fontanero profesional",
    verified: true,
    premium: true,
    rating: 4.8,
    reviews: 127,
    completedJobs: 215,
    responseRate: 98,
    responseTime: "< 1 hora",
    languages: ["Español", "Inglés", "Euskera"],
    education: "Técnico Superior en Fontanería",
    certifications: ["Certificado de Profesionalidad Nivel 3", "Manipulador de Gases Fluorados"],
    skills: ["Instalaciones", "Reparaciones", "Mantenimiento", "Fontanería", "Calefacción"],
    availability: "Disponible",
    image: getProfileAvatar(), // Usar la función getProfileAvatar para consistencia
  }

  // Datos de ejemplo para publicaciones
  const posts = [
    {
      id: 1,
      title: "Ofrezco servicios de fontanería en toda la zona de Bilbao",
      date: "Hace 2 días",
      views: 156,
      interactions: 23,
      saved: 12,
      category: "Servicios",
      price: "25€/h",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 2,
      title: "Reparación de tuberías y desatascos 24h",
      date: "Hace 1 semana",
      views: 243,
      interactions: 45,
      saved: 18,
      category: "Servicios",
      price: "30€/h",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 3,
      title: "Instalación de calefacción y calderas",
      date: "Hace 2 semanas",
      views: 189,
      interactions: 32,
      saved: 15,
      category: "Servicios",
      price: "Desde 150€",
      image: "/placeholder.svg?height=100&width=100",
    },
  ]

  // Datos de ejemplo para valoraciones
  const ratings = [
    {
      id: 1,
      user: {
        name: "Laura Pérez",
        image:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%286%29.jfif-2N7CGhkzwCvR9V7h8wckVtCaVgBnLD.jpeg",
      },
      rating: 5,
      comment: "Excelente trabajo, muy profesional y puntual. Solucionó el problema rápidamente.",
      date: "Hace 3 días",
    },
    {
      id: 2,
      user: {
        name: "Carlos Martínez",
        image:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%287%29.jfif-ymppqAxBMrDCcfpYae8hqdZfdpHwbd.jpeg",
      },
      rating: 4,
      comment: "Buen servicio, aunque tardó un poco más de lo esperado. El resultado final fue muy bueno.",
      date: "Hace 1 semana",
    },
    {
      id: 3,
      user: {
        name: "Ana García",
        image:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%281%29.jfif-togashgF7m10GyOiYVlmWbOMn5s2bP.jpeg",
      },
      rating: 5,
      comment: "Muy recomendable. Trabajo impecable y precio justo.",
      date: "Hace 2 semanas",
    },
  ]

  // Datos de ejemplo para actividad
  const activity = [
    {
      id: 1,
      type: "job_completed",
      title: "Trabajo completado",
      description: "Reparación de fuga en baño",
      date: "Hace 1 día",
      client: "Miguel Torres",
      amount: "45€",
    },
    {
      id: 2,
      type: "new_review",
      title: "Nueva valoración",
      description: "Has recibido una valoración de 5 estrellas",
      date: "Hace 3 días",
      client: "Laura Pérez",
    },
    {
      id: 3,
      type: "job_accepted",
      title: "Trabajo aceptado",
      description: "Instalación de caldera",
      date: "Hace 5 días",
      client: "Javier Ruiz",
      amount: "180€",
    },
  ]

  // Datos de ejemplo para estadísticas
  const stats = {
    views: 1245,
    interactions: 342,
    saved: 87,
    messages: 156,
    earnings: {
      total: "2.450€",
      thisMonth: "450€",
      lastMonth: "380€",
    },
    completion: {
      rate: 97,
      onTime: 95,
      satisfaction: 98,
    },
  }

  // Datos de ejemplo para logros
  const achievements = [
    {
      id: 1,
      title: "Profesional destacado",
      description: "Entre el top 10% de profesionales en tu categoría",
      icon: Award,
      unlocked: true,
    },
    {
      id: 2,
      title: "Respuesta rápida",
      description: "Respondes a los mensajes en menos de 1 hora",
      icon: Clock,
      unlocked: true,
    },
    {
      id: 3,
      title: "Alta valoración",
      description: "Mantienes una valoración superior a 4.5 estrellas",
      icon: Star,
      unlocked: true,
    },
    {
      id: 4,
      title: "Experto verificado",
      description: "Has verificado tus credenciales profesionales",
      icon: Shield,
      unlocked: true,
    },
    {
      id: 5,
      title: "100 trabajos completados",
      description: "Has completado más de 100 trabajos con éxito",
      icon: CheckCircle,
      unlocked: true,
    },
  ]

  // Datos de ejemplo para nivel y puntos
  const level = {
    current: 8,
    points: 1750,
    nextLevel: 2000,
    benefits: [
      "Posicionamiento destacado en búsquedas",
      "Insignia de profesional nivel 8",
      "Comisiones reducidas al 8%",
    ],
    progress: 87,
  }

  // Función para navegar a edit-profile
  const handleEditProfile = () => {
    router.push("/edit-profile")
  }

  // Función para manejar la navegación a guardados
  const handleNavigateToSaved = () => {
    router.push("/saved")
    toast({
      title: "Navegando a guardados",
      description: "Accediendo a tus elementos guardados",
      duration: 2000,
    })
  }

  // Función para abrir el modal de gamificación
  const handleOpenGamificationModal = () => {
    setGamificationModalOpen(true)
  }

  return (
    <div className="max-w-md mx-auto bg-white dark:bg-gray-950 min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white dark:bg-gray-950 z-10 border-b dark:border-gray-800">
        <div className="flex items-center">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold dark:text-white">Mi Perfil</h1>
        </div>
        <div className="flex items-center space-x-2">
          <Link href="/profile/settings">
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
          </Link>
          <Button variant="ghost" size="icon" onClick={handleEditProfile}>
            <Edit className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Perfil */}
      <div className="p-4">
        <div className="flex items-start">
          <div className="relative">
            <Image
              src={profile.image || "/placeholder.svg"}
              alt={profile.name}
              width={80}
              height={80}
              className="w-20 h-20 rounded-full object-cover border-2 border-gray-200 dark:border-gray-700"
            />
            {profile.verified && (
              <div className="absolute bottom-0 right-0 bg-blue-500 rounded-full p-1">
                <CheckCircle className="h-4 w-4 text-white" />
              </div>
            )}
          </div>
          <div className="ml-4 flex-1">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold dark:text-white">{profile.name}</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">{profile.username}</p>
              </div>
              {profile.premium && (
                <Badge variant="outline" className="border-yellow-500 text-yellow-500">
                  Premium
                </Badge>
              )}
            </div>
            <div className="flex items-center mt-1">
              <MapPin className="h-4 w-4 text-gray-500 dark:text-gray-400 mr-1" />
              <span className="text-sm text-gray-500 dark:text-gray-400">{profile.location}</span>
            </div>
            <div className="flex items-center mt-1">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="text-sm font-medium dark:text-gray-200">{profile.rating}</span>
              <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">({profile.reviews} valoraciones)</span>
            </div>
          </div>
        </div>

        <p className="mt-4 text-sm text-gray-700 dark:text-gray-300">{profile.bio}</p>

        <div className="mt-4 flex space-x-3">
          <Button className="flex-1 rounded-full bg-black hover:bg-gray-800 text-white" onClick={handleEditProfile}>
            <Edit className="h-4 w-4 mr-2" />
            Editar
          </Button>
          <Link href="/saved" className="flex-1">
            <Button
              variant="outline"
              className="w-full rounded-full dark:border-gray-700 dark:text-gray-200"
              onClick={handleNavigateToSaved}
            >
              <Bookmark className="h-4 w-4 mr-2" />
              Guardados
            </Button>
          </Link>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-2">
            <p className="text-lg font-bold dark:text-white">{profile.completedJobs}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Trabajos</p>
          </div>
          <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-2">
            <p className="text-lg font-bold dark:text-white">{profile.responseRate}%</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Respuesta</p>
          </div>
          <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-2">
            <p className="text-lg font-bold dark:text-white">{profile.responseTime}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Tiempo</p>
          </div>
        </div>
      </div>

      {/* Barra de nivel - Ahora clickable */}
      <div className="px-4 mb-4">
        <div
          className="bg-gray-50 dark:bg-gray-900 p-3 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          onClick={handleOpenGamificationModal}
        >
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium dark:text-white">Nivel {level.current}</span>
            <span className="text-xs text-gray-500 dark:text-gray-400">{level.progress}% completado</span>
          </div>
          <Progress value={level.progress} className="h-2 dark:bg-gray-700" />
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 flex items-center justify-center">
            <Award className="h-3 w-3 mr-1 text-yellow-500" />
            {level.points} / {level.nextLevel} puntos para el siguiente nivel
          </p>
        </div>
      </div>

      {/* Modal de Gamificación */}
      <GamificationModal
        open={gamificationModalOpen}
        onOpenChange={setGamificationModalOpen}
        level={level.current}
        points={level.points}
        nextLevelPoints={level.nextLevel}
        completedHelps={profile.completedJobs}
        totalHelps={250}
        rating={profile.rating}
        reviews={profile.reviews}
      />

      {/* Tabs */}
      <Tabs defaultValue="publicaciones" className="w-full" onValueChange={setActiveTab}>
        <div className="px-4">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="publicaciones">Publicaciones</TabsTrigger>
            <TabsTrigger value="valoraciones">Valoraciones</TabsTrigger>
            <TabsTrigger value="actividad">Actividad</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="publicaciones" className="mt-4">
          <div className="px-4 space-y-4">
            {posts.map((post) => (
              <Card key={post.id} className="overflow-hidden dark:border-gray-800 dark:bg-gray-900">
                <CardContent className="p-0">
                  <div className="flex items-start p-4">
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <Badge variant="outline" className="mb-2 dark:border-gray-700 dark:text-gray-300">
                          {post.category}
                        </Badge>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{post.date}</span>
                      </div>
                      <h3 className="font-medium text-sm mb-1 dark:text-white">{post.title}</h3>
                      <p className="text-sm font-bold text-gray-900 dark:text-gray-200">{post.price}</p>
                      <div className="flex items-center mt-2 text-xs text-gray-500 dark:text-gray-400">
                        <div className="flex items-center mr-3">
                          <Eye className="h-3 w-3 mr-1" />
                          {post.views}
                        </div>
                        <div className="flex items-center mr-3">
                          <MessageSquare className="h-3 w-3 mr-1" />
                          {post.interactions}
                        </div>
                        <div className="flex items-center">
                          <Bookmark className="h-3 w-3 mr-1" />
                          {post.saved}
                        </div>
                      </div>
                    </div>
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={64}
                      height={64}
                      className="w-16 h-16 rounded-md object-cover ml-3"
                    />
                  </div>
                  <div className="flex border-t dark:border-gray-800">
                    <Button
                      variant="ghost"
                      className="flex-1 rounded-none py-2 h-auto text-xs dark:text-gray-300 dark:hover:bg-gray-800"
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Editar
                    </Button>
                    <Separator orientation="vertical" className="dark:bg-gray-800" />
                    <Button
                      variant="ghost"
                      className="flex-1 rounded-none py-2 h-auto text-xs dark:text-gray-300 dark:hover:bg-gray-800"
                    >
                      <Eye className="h-3 w-3 mr-1" />
                      Estadísticas
                    </Button>
                    <Separator orientation="vertical" className="dark:bg-gray-800" />
                    <Button
                      variant="ghost"
                      className="flex-1 rounded-none py-2 h-auto text-xs dark:text-gray-300 dark:hover:bg-gray-800"
                    >
                      <AlertCircle className="h-3 w-3 mr-1" />
                      Pausar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            <Button
              variant="outline"
              className="w-full rounded-full dark:border-gray-700 dark:text-gray-200 dark:hover:bg-gray-800"
            >
              Ver todas mis publicaciones
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="valoraciones" className="mt-4">
          <div className="px-4 space-y-4">
            <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-2xl dark:text-white">{profile.rating}</h3>
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${i < Math.floor(profile.rating) ? "text-yellow-500" : "text-gray-300 dark:text-gray-600"}`}
                        fill={i < Math.floor(profile.rating) ? "currentColor" : "none"}
                      />
                    ))}
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{profile.reviews} valoraciones</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center justify-end mb-1">
                    <span className="text-xs mr-2 dark:text-gray-400">5</span>
                    <Progress value={85} className="h-2 w-24 dark:bg-gray-700" />
                  </div>
                  <div className="flex items-center justify-end mb-1">
                    <span className="text-xs mr-2 dark:text-gray-400">4</span>
                    <Progress value={12} className="h-2 w-24 dark:bg-gray-700" />
                  </div>
                  <div className="flex items-center justify-end mb-1">
                    <span className="text-xs mr-2 dark:text-gray-400">3</span>
                    <Progress value={3} className="h-2 w-24 dark:bg-gray-700" />
                  </div>
                  <div className="flex items-center justify-end mb-1">
                    <span className="text-xs mr-2 dark:text-gray-400">2</span>
                    <Progress value={0} className="h-2 w-24 dark:bg-gray-700" />
                  </div>
                  <div className="flex items-center justify-end">
                    <span className="text-xs mr-2 dark:text-gray-400">1</span>
                    <Progress value={0} className="h-2 w-24 dark:bg-gray-700" />
                  </div>
                </div>
              </div>
            </div>

            {ratings.map((rating) => (
              <Card key={rating.id} className="dark:border-gray-800 dark:bg-gray-900">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start">
                      <Image
                        src={rating.user.image || "/placeholder.svg"}
                        alt={rating.user.name}
                        width={40}
                        height={40}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="ml-3">
                        <h4 className="font-medium dark:text-white">{rating.user.name}</h4>
                        <div className="flex items-center mt-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-3 w-3 ${i < rating.rating ? "text-yellow-500" : "text-gray-300 dark:text-gray-600"}`}
                              fill={i < rating.rating ? "currentColor" : "none"}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500 dark:text-gray-400">{rating.date}</span>
                  </div>
                  <p className="mt-3 text-sm text-gray-700 dark:text-gray-300">{rating.comment}</p>
                </CardContent>
              </Card>
            ))}
            <Button
              variant="outline"
              className="w-full rounded-full dark:border-gray-700 dark:text-gray-200 dark:hover:bg-gray-800"
            >
              Ver todas las valoraciones
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="actividad" className="mt-4">
          <div className="px-4 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Card className="dark:border-gray-800 dark:bg-gray-900">
                <CardContent className="p-3">
                  <h4 className="text-xs text-gray-500 dark:text-gray-400 mb-1">Visualizaciones</h4>
                  <p className="text-xl font-bold dark:text-white">{stats.views}</p>
                  <span className="text-xs text-green-500">+12% esta semana</span>
                </CardContent>
              </Card>
              <Card className="dark:border-gray-800 dark:bg-gray-900">
                <CardContent className="p-3">
                  <h4 className="text-xs text-gray-500 dark:text-gray-400 mb-1">Interacciones</h4>
                  <p className="text-xl font-bold dark:text-white">{stats.interactions}</p>
                  <span className="text-xs text-green-500">+8% esta semana</span>
                </CardContent>
              </Card>
              <Card className="dark:border-gray-800 dark:bg-gray-900">
                <CardContent className="p-3">
                  <h4 className="text-xs text-gray-500 dark:text-gray-400 mb-1">Guardados</h4>
                  <p className="text-xl font-bold dark:text-white">{stats.saved}</p>
                  <span className="text-xs text-green-500">+5% esta semana</span>
                </CardContent>
              </Card>
              <Card className="dark:border-gray-800 dark:bg-gray-900">
                <CardContent className="p-3">
                  <h4 className="text-xs text-gray-500 dark:text-gray-400 mb-1">Mensajes</h4>
                  <p className="text-xl font-bold dark:text-white">{stats.messages}</p>
                  <span className="text-xs text-green-500">+15% esta semana</span>
                </CardContent>
              </Card>
            </div>

            <Card className="dark:border-gray-800 dark:bg-gray-900">
              <CardContent className="p-4">
                <h3 className="font-medium mb-3 dark:text-white">Ganancias</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm dark:text-gray-300">Total</span>
                    <span className="font-bold dark:text-white">{stats.earnings.total}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm dark:text-gray-300">Este mes</span>
                    <span className="font-bold dark:text-white">{stats.earnings.thisMonth}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm dark:text-gray-300">Mes pasado</span>
                    <span className="font-bold dark:text-white">{stats.earnings.lastMonth}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="dark:border-gray-800 dark:bg-gray-900">
              <CardContent className="p-4">
                <h3 className="font-medium mb-3 dark:text-white">Rendimiento</h3>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm dark:text-gray-300">Tasa de finalización</span>
                      <span className="text-sm font-medium dark:text-white">{stats.completion.rate}%</span>
                    </div>
                    <Progress value={stats.completion.rate} className="h-2 dark:bg-gray-700" />
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm dark:text-gray-300">Puntualidad</span>
                      <span className="text-sm font-medium dark:text-white">{stats.completion.onTime}%</span>
                    </div>
                    <Progress value={stats.completion.onTime} className="h-2 dark:bg-gray-700" />
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm dark:text-gray-300">Satisfacción del cliente</span>
                      <span className="text-sm font-medium dark:text-white">{stats.completion.satisfaction}%</span>
                    </div>
                    <Progress value={stats.completion.satisfaction} className="h-2 dark:bg-gray-700" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <h3 className="font-medium px-1 dark:text-white">Actividad reciente</h3>
            {activity.map((item) => (
              <Card key={item.id} className="dark:border-gray-800 dark:bg-gray-900">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium dark:text-white">{item.title}</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">{item.description}</p>
                      <div className="flex items-center mt-2">
                        <User className="h-3 w-3 text-gray-500 dark:text-gray-400 mr-1" />
                        <span className="text-xs text-gray-500 dark:text-gray-400">{item.client}</span>
                        {item.amount && (
                          <>
                            <span className="mx-1 text-gray-500 dark:text-gray-400">•</span>
                            <span className="text-xs font-medium dark:text-gray-300">{item.amount}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <span className="text-xs text-gray-500 dark:text-gray-400">{item.date}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
            <Button
              variant="outline"
              className="w-full rounded-full dark:border-gray-700 dark:text-gray-200 dark:hover:bg-gray-800"
            >
              Ver toda la actividad
            </Button>
          </div>
        </TabsContent>
      </Tabs>

      {/* Logros */}
      {activeTab === "actividad" && (
        <div className="mt-6 px-4">
          <h3 className="font-medium mb-3 dark:text-white">Logros desbloqueados</h3>
          <div className="space-y-3">
            {achievements
              .filter((a) => a.unlocked)
              .map((achievement) => (
                <div key={achievement.id} className="flex items-center bg-gray-50 dark:bg-gray-900 rounded-lg p-3">
                  <div className="bg-yellow-100 dark:bg-yellow-900/30 rounded-full p-2">
                    <achievement.icon className="h-5 w-5 text-yellow-600 dark:text-yellow-500" />
                  </div>
                  <div className="ml-3">
                    <h4 className="font-medium text-sm dark:text-white">{achievement.title}</h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{achievement.description}</p>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Configuración rápida */}
      <div className="mt-6 px-4 mb-20">
        <h3 className="font-medium mb-3 dark:text-white">Configuración rápida</h3>
        <Card className="dark:border-gray-800 dark:bg-gray-900">
          <CardContent className="p-0">
            <Link href="/profile/professional-settings">
              <div className="flex items-center justify-between p-4 border-b dark:border-gray-800">
                <div className="flex items-center">
                  <Briefcase className="h-5 w-5 text-gray-500 dark:text-gray-400 mr-3" />
                  <span className="dark:text-gray-200">Configuración profesional</span>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </Link>
            <Link href="/profile/premium">
              <div className="flex items-center justify-between p-4 border-b dark:border-gray-800">
                <div className="flex items-center">
                  <Award className="h-5 w-5 text-yellow-500 mr-3" />
                  <span className="dark:text-gray-200">QuickSer Premium</span>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </Link>
            <Link href="/configuracion/ayuda">
              <div className="flex items-center justify-between p-4 border-b dark:border-gray-800">
                <div className="flex items-center">
                  <HelpCircle className="h-5 w-5 text-gray-500 dark:text-gray-400 mr-3" />
                  <span className="dark:text-gray-200">Ayuda y soporte</span>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </Link>
            <Link href="/configuracion/cerrar-sesion">
              <div className="flex items-center justify-between p-4">
                <div className="flex items-center">
                  <LogOut className="h-5 w-5 text-red-500 mr-3" />
                  <span className="text-red-500">Cerrar sesión</span>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" unreadMessages={unreadMessages} />
    </div>
  )
}

function Eye(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

function MessageSquare(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  )
}
