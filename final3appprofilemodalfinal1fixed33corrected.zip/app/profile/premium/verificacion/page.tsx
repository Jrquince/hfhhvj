"use client"

import { ArrowLeft, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function VerificacionPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">VERIFICACIÓN</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">Verifica tu identidad y tus credenciales para generar más confianza.</p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Estado de verificación</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mr-3">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                  <span className="text-sm">Correo electrónico</span>
                </div>
                <span className="text-xs text-green-600">Verificado</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mr-3">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                  <span className="text-sm">Teléfono</span>
                </div>
                <span className="text-xs text-green-600">Verificado</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                    <span className="text-xs text-gray-600">?</span>
                  </div>
                  <span className="text-sm">Documento de identidad</span>
                </div>
                <Button variant="outline" size="sm">
                  Verificar
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                    <span className="text-xs text-gray-600">?</span>
                  </div>
                  <span className="text-sm">Titulación profesional</span>
                </div>
                <Button variant="outline" size="sm">
                  Verificar
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                    <span className="text-xs text-gray-600">?</span>
                  </div>
                  <span className="text-sm">Seguro de responsabilidad</span>
                </div>
                <Button variant="outline" size="sm">
                  Verificar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Beneficios de la verificación</h2>
            <div className="space-y-4">
              <p>Al verificar tu perfil obtienes:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Insignia de verificación en tu perfil</li>
                <li>Mayor visibilidad en los resultados de búsqueda</li>
                <li>Aumento del 70% en la tasa de respuesta</li>
                <li>Acceso a clientes premium</li>
                <li>Mayor confianza de los usuarios</li>
              </ul>
              <Button className="w-full mt-4 bg-yellow-500 hover:bg-yellow-600 text-white">
                Completar verificación
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
