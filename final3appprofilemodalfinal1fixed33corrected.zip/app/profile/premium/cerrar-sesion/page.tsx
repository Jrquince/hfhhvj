"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function CerrarSesionPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">CERRAR SESIÓN</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <Card className="mb-6">
          <CardContent className="p-6 text-center">
            <h2 className="text-lg font-bold mb-4">¿Estás seguro de que quieres cerrar sesión?</h2>
            <p className="text-gray-600 mb-6">Tendrás que volver a iniciar sesión para acceder a tu cuenta.</p>

            <div className="space-y-4">
              <Button className="w-full bg-red-500 hover:bg-red-600 text-white">Cerrar sesión</Button>
              <Button variant="outline" className="w-full">
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Otras opciones</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Cambiar de cuenta</h3>
                <p className="text-xs text-gray-500 mb-2">Cambia a otra cuenta sin cerrar sesión</p>
                <Link href="/profile/premium/cambiar-cuenta">
                  <Button variant="outline" size="sm" className="w-full">
                    Cambiar cuenta
                  </Button>
                </Link>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Modo privado</h3>
                <p className="text-xs text-gray-500 mb-2">Navega sin que se registre tu actividad</p>
                <Button variant="outline" size="sm" className="w-full">
                  Activar modo privado
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
