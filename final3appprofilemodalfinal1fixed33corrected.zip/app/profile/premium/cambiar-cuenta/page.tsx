"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function CambiarCuentaPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">CAMBIAR CUENTA</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">Gestiona tus cuentas y cambia entre perfiles personales y profesionales.</p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Cuenta actual</h2>
            <div className="flex items-center p-3 border rounded-lg bg-yellow-50">
              <Avatar className="h-12 w-12 mr-3">
                <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Avatar" />
                <AvatarFallback>JP</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium">Juan Pérez</p>
                <p className="text-xs text-gray-500">Cuenta profesional</p>
                <div className="flex items-center mt-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                  <span className="text-xs text-green-600">Activa</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Otras cuentas</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Avatar" />
                    <AvatarFallback>JP</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">Juan Pérez</p>
                    <p className="text-xs text-gray-500">Cuenta personal</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  Cambiar
                </Button>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Avatar" />
                    <AvatarFallback>RP</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">Reformas Pérez</p>
                    <p className="text-xs text-gray-500">Cuenta de empresa</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  Cambiar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Opciones de cuenta</h2>
            <div className="space-y-4">
              <Button variant="outline" className="w-full">
                Crear nueva cuenta
              </Button>
              <Button variant="outline" className="w-full">
                Vincular cuentas existentes
              </Button>
              <Button variant="outline" className="w-full text-red-500 hover:text-red-600 hover:bg-red-50">
                Eliminar cuenta
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
