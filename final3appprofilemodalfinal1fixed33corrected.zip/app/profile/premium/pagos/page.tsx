"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function PagosPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">PAGOS</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">Gestiona tus métodos de pago y revisa tu historial de transacciones.</p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Métodos de pago</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-6 bg-blue-100 rounded flex items-center justify-center mr-3">
                    <span className="text-xs font-bold text-blue-800">VISA</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Visa terminada en 4582</p>
                    <p className="text-xs text-gray-500">Expira: 05/26</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  Editar
                </Button>
              </div>

              <div className="p-3 border rounded-lg flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-6 bg-red-100 rounded flex items-center justify-center mr-3">
                    <span className="text-xs font-bold text-red-800">MC</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Mastercard terminada en 7891</p>
                    <p className="text-xs text-gray-500">Expira: 09/25</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  Editar
                </Button>
              </div>

              <Button variant="outline" className="w-full">
                Añadir método de pago
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Historial de pagos</h2>
            <div className="space-y-4">
              <div className="p-3 border-b">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium">Suscripción Premium</p>
                    <p className="text-xs text-gray-500">19 Mar 2023</p>
                  </div>
                  <span className="text-sm font-bold">9,99 €</span>
                </div>
              </div>

              <div className="p-3 border-b">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium">Anuncio destacado</p>
                    <p className="text-xs text-gray-500">15 Feb 2023</p>
                  </div>
                  <span className="text-sm font-bold">4,99 €</span>
                </div>
              </div>

              <div className="p-3 border-b">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium">Suscripción Premium</p>
                    <p className="text-xs text-gray-500">19 Feb 2023</p>
                  </div>
                  <span className="text-sm font-bold">9,99 €</span>
                </div>
              </div>

              <Button variant="ghost" className="w-full text-yellow-600">
                Ver historial completo
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Facturación</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Datos de facturación</h3>
                <p className="text-xs text-gray-500 mb-2">
                  Nombre: Juan Pérez
                  <br />
                  NIF: 12345678Z
                  <br />
                  Dirección: Calle Principal 123
                  <br />
                  Ciudad: Madrid, 28001
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  Editar datos
                </Button>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Descargar facturas</h3>
                <p className="text-xs text-gray-500 mb-2">Descarga tus facturas en formato PDF</p>
                <Button variant="outline" size="sm" className="w-full">
                  Ver facturas
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
