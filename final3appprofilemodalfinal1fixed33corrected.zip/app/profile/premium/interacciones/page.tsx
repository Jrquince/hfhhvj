"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function InteraccionesPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">INTERACCIONES</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">
          Analiza cómo interactúan los usuarios con tu contenido para mejorar tu estrategia.
        </p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Resumen de interacciones</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm">Guardados</span>
                <span className="font-bold">8</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Compartidos</span>
                <span className="font-bold">3</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Mensajes</span>
                <span className="font-bold">2</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Detalles de interacciones</h2>
            <div className="space-y-4">
              <p>Con la cuenta Premium, puedes ver:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Quién ha guardado tus publicaciones</li>
                <li>Quién ha compartido tu perfil</li>
                <li>Métricas de engagement por publicación</li>
                <li>Comparativas con periodos anteriores</li>
              </ul>
              <p className="text-sm text-gray-500">
                Conoce qué contenido genera más interés para mejorar tu estrategia.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Publicaciones más populares</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg flex justify-between items-center">
                <span className="text-sm font-medium">Fontanería urgente</span>
                <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">5 guardados</span>
              </div>
              <div className="p-3 border rounded-lg flex justify-between items-center">
                <span className="text-sm font-medium">Reparación de electrodomésticos</span>
                <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">3 guardados</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
