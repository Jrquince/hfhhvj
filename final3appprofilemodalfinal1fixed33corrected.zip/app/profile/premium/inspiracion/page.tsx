"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function InspiracionPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">INSPIRACIÓN</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">Descubre ideas y ejemplos de perfiles exitosos para inspirarte.</p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Perfiles destacados</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Carlos Martínez - Electricista</h3>
                <p className="text-xs text-gray-500">Más de 200 valoraciones positivas y 95% de satisfacción</p>
                <div className="mt-2 flex justify-between items-center">
                  <span className="text-xs text-yellow-600">Ver qué hace bien</span>
                  <Button variant="outline" size="sm">
                    Ver perfil
                  </Button>
                </div>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Laura Sánchez - Limpieza</h3>
                <p className="text-xs text-gray-500">Más de 150 clientes recurrentes y excelentes reseñas</p>
                <div className="mt-2 flex justify-between items-center">
                  <span className="text-xs text-yellow-600">Ver qué hace bien</span>
                  <Button variant="outline" size="sm">
                    Ver perfil
                  </Button>
                </div>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Miguel Fernández - Fontanero</h3>
                <p className="text-xs text-gray-500">Respuesta en menos de 5 minutos y disponibilidad 24/7</p>
                <div className="mt-2 flex justify-between items-center">
                  <span className="text-xs text-yellow-600">Ver qué hace bien</span>
                  <Button variant="outline" size="sm">
                    Ver perfil
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Ideas para destacar</h2>
            <div className="space-y-4">
              <p>Consejos para hacer que tu perfil destaque:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Utiliza fotos profesionales de tus trabajos</li>
                <li>Responde rápidamente a los mensajes</li>
                <li>Ofrece presupuestos claros y detallados</li>
                <li>Solicita valoraciones a tus clientes satisfechos</li>
                <li>Mantén tu calendario actualizado</li>
              </ul>
              <p className="text-sm text-gray-500">
                Implementa estas ideas para aumentar tu visibilidad y conseguir más clientes.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
