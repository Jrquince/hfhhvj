"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function VisualizacionesPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">VISUALIZACIONES</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">
          Analiza quién ve tu perfil y tus publicaciones para optimizar tu presencia en la plataforma.
        </p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Resumen de visualizaciones</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm">Últimos 7 días</span>
                <span className="font-bold">42</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Últimos 30 días</span>
                <span className="font-bold">124</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Últimos 90 días</span>
                <span className="font-bold">356</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Detalles de visualizaciones</h2>
            <div className="space-y-4">
              <p>Con la cuenta Premium, puedes ver:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Quién ha visitado tu perfil en los últimos 90 días</li>
                <li>Cuántas veces se han visto tus publicaciones</li>
                <li>Datos demográficos de tus visitantes</li>
                <li>Tendencias de visualización por día y hora</li>
              </ul>
              <p className="text-sm text-gray-500">
                Estos datos te ayudarán a optimizar tu presencia en la plataforma.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Gráfico de tendencias</h2>
            <div className="h-40 bg-gray-100 rounded-lg flex items-center justify-center mb-4">
              <p className="text-gray-500">Gráfico de visualizaciones</p>
            </div>
            <p className="text-sm text-gray-500">
              El gráfico muestra la tendencia de visualizaciones en los últimos 30 días.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
