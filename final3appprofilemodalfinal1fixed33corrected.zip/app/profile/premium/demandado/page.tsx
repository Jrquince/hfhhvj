"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function DemandadoPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">LO MÁS DEMANDADO</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">Descubre los servicios más solicitados en tu zona para adaptar tu oferta.</p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Servicios más demandados</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Fontanería de emergencia</span>
                <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">+45%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Instalación de aire acondicionado</span>
                <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">+38%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Reparación de electrodomésticos</span>
                <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">+32%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Limpieza de hogar</span>
                <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">+28%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Montaje de muebles</span>
                <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">+25%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Tendencias por zona</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Centro</h3>
                <p className="text-xs text-gray-500">Reparaciones rápidas y servicios de limpieza</p>
              </div>
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Norte</h3>
                <p className="text-xs text-gray-500">Jardinería y mantenimiento de piscinas</p>
              </div>
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Sur</h3>
                <p className="text-xs text-gray-500">Reformas y pintores profesionales</p>
              </div>
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Este</h3>
                <p className="text-xs text-gray-500">Electricistas y fontaneros</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Precios medios</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Fontanería</span>
                <span className="text-sm font-bold">35€/h</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Electricidad</span>
                <span className="text-sm font-bold">40€/h</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Limpieza</span>
                <span className="text-sm font-bold">12€/h</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Pintura</span>
                <span className="text-sm font-bold">18€/m²</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Montaje de muebles</span>
                <span className="text-sm font-bold">25€/h</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
