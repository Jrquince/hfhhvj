"use client"

import {
  ArrowLeft,
  Award,
  Eye,
  MessageCircle,
  Star,
  Zap,
  BarChart,
  Shield,
  Clock,
  Users,
  Search,
  Bell,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function PremiumPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">PROFESIONALES</h1>
        <div className="w-8 flex items-center justify-center">
          <div className="w-5 h-5 rounded-full bg-yellow-500"></div>
        </div>
      </div>

      <div className="px-4 py-2 bg-yellow-50">
        <p className="text-sm text-center text-gray-700">Desde el 19 de Marzo</p>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-4">
          <Link href="/profile/premium/visualizaciones">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Eye className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Visualizaciones</span>
              </div>
              <div className="flex items-center">
                <span className="text-sm font-medium mr-2">124</span>
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/interacciones">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Zap className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Interacciones</span>
              </div>
              <div className="flex items-center">
                <span className="text-sm font-medium mr-2">13</span>
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/nuevos-usuarios">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Users className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Nuevos usuarios que confían</span>
              </div>
              <div className="flex items-center">
                <span className="text-sm font-medium mr-2">124</span>
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/notificaciones">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Bell className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Notificaciones</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/herramientas">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Search className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Herramientas de anuncio</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/recomendaciones">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Star className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Recomendaciones</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/inspiracion">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <MessageCircle className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Inspiración</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/demandado">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <BarChart className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Lo más demandado</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/verificacion">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Shield className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Verificación</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/pagos">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <div className="h-5 w-5 flex items-center justify-center text-gray-500 mr-3">€</div>
                <span className="text-sm">Pagos</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/cambiar-cuenta">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Users className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Cambiar de cuenta</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/suscripcion">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Award className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Ver suscripción</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>

          <Link href="/profile/premium/cerrar-sesion">
            <div className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-gray-500 mr-3" />
                <span className="text-sm">Cerrar sesión</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft className="h-4 w-4 text-gray-400 transform rotate-180" />
              </div>
            </div>
          </Link>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
