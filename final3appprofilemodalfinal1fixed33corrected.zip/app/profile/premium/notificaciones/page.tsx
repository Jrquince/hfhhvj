"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

export default function NotificacionesPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">NOTIFICACIONES</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">
          Configura tus notificaciones para estar al día de toda la actividad relevante.
        </p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Configuración de notificaciones</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Nuevas visualizaciones</p>
                  <p className="text-xs text-gray-500">Recibe alertas cuando alguien vea tu perfil</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Nuevos mensajes</p>
                  <p className="text-xs text-gray-500">Recibe alertas de mensajes nuevos</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Nuevas valoraciones</p>
                  <p className="text-xs text-gray-500">Recibe alertas de nuevas valoraciones</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Guardados</p>
                  <p className="text-xs text-gray-500">Recibe alertas cuando guarden tus publicaciones</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Actualizaciones de la app</p>
                  <p className="text-xs text-gray-500">Recibe alertas sobre nuevas funciones</p>
                </div>
                <Switch />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Notificaciones Premium</h2>
            <div className="space-y-4">
              <p>Con la cuenta Premium, recibes notificaciones avanzadas:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Alertas de tendencias en tu sector</li>
                <li>Notificaciones de usuarios premium interesados</li>
                <li>Alertas de oportunidades de negocio</li>
                <li>Recordatorios personalizados</li>
              </ul>
              <p className="text-sm text-gray-500">Mantente siempre informado de las oportunidades más relevantes.</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
