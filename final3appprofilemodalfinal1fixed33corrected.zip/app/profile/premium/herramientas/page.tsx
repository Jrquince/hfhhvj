"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function HerramientasPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">HERRAMIENTAS</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">
          Accede a herramientas avanzadas para mejorar tus anuncios y aumentar tu visibilidad.
        </p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Herramientas disponibles</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Editor de fotos profesional</h3>
                <p className="text-xs text-gray-500">Mejora tus imágenes con filtros y ajustes profesionales</p>
                <Button variant="outline" size="sm" className="mt-2 w-full">
                  Usar herramienta
                </Button>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Generador de descripciones</h3>
                <p className="text-xs text-gray-500">Crea descripciones atractivas para tus servicios</p>
                <Button variant="outline" size="sm" className="mt-2 w-full">
                  Usar herramienta
                </Button>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Anuncios destacados</h3>
                <p className="text-xs text-gray-500">Destaca tus anuncios en los resultados de búsqueda</p>
                <Button variant="outline" size="sm" className="mt-2 w-full">
                  Usar herramienta
                </Button>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Programador de publicaciones</h3>
                <p className="text-xs text-gray-500">Programa tus anuncios para publicarlos en el mejor momento</p>
                <Button variant="outline" size="sm" className="mt-2 w-full">
                  Usar herramienta
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Beneficios Premium</h2>
            <div className="space-y-4">
              <p>Con la cuenta Premium, accedes a herramientas exclusivas:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Análisis de competencia en tu zona</li>
                <li>Recomendaciones de precios según el mercado</li>
                <li>Plantillas profesionales para anuncios</li>
                <li>Posicionamiento prioritario en búsquedas</li>
              </ul>
              <p className="text-sm text-gray-500">Destaca entre la competencia con herramientas profesionales.</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
