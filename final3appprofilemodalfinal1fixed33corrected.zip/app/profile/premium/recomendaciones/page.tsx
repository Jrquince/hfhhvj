"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function RecomendacionesPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">RECOMENDACIONES</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">
          Recibe recomendaciones personalizadas para mejorar tu perfil y aumentar tus oportunidades.
        </p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Recomendaciones para tu perfil</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Añade más fotos de tus trabajos</h3>
                <p className="text-xs text-gray-500">Los perfiles con más de 5 fotos reciben un 40% más de contactos</p>
                <Button variant="outline" size="sm" className="mt-2 w-full">
                  Añadir fotos
                </Button>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Completa tu descripción</h3>
                <p className="text-xs text-gray-500">Una descripción detallada aumenta la confianza de los usuarios</p>
                <Button variant="outline" size="sm" className="mt-2 w-full">
                  Editar descripción
                </Button>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Verifica tu identidad</h3>
                <p className="text-xs text-gray-500">Los perfiles verificados reciben un 60% más de contactos</p>
                <Button variant="outline" size="sm" className="mt-2 w-full">
                  Verificar identidad
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Recomendaciones de servicios</h2>
            <div className="space-y-4">
              <p>Basado en tu perfil, te recomendamos ofrecer:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Reparaciones de emergencia (alta demanda)</li>
                <li>Instalaciones de aire acondicionado (temporada alta)</li>
                <li>Mantenimiento preventivo (servicio recurrente)</li>
                <li>Asesoramiento en eficiencia energética (tendencia)</li>
              </ul>
              <p className="text-sm text-gray-500">
                Estas recomendaciones se basan en las tendencias actuales del mercado.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
