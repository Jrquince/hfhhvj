"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function NuevosUsuariosPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">NUEVOS USUARIOS</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">Conoce a los nuevos usuarios que muestran interés en tus servicios.</p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Usuarios recientes</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Avatar" />
                    <AvatarFallback>MG</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">María García</p>
                    <p className="text-xs text-gray-500">Hace 2 días</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="rounded-full">
                  Ver
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Avatar" />
                    <AvatarFallback>JL</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">Juan López</p>
                    <p className="text-xs text-gray-500">Hace 3 días</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="rounded-full">
                  Ver
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Avatar" />
                    <AvatarFallback>AR</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">Ana Rodríguez</p>
                    <p className="text-xs text-gray-500">Hace 5 días</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="rounded-full">
                  Ver
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Detalles de usuarios</h2>
            <div className="space-y-4">
              <p>Con la cuenta Premium, puedes:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Ver perfiles detallados de usuarios interesados</li>
                <li>Recibir notificaciones de nuevos seguidores</li>
                <li>Analizar patrones de interés por ubicación y categoría</li>
                <li>Contactar directamente con usuarios potenciales</li>
              </ul>
              <p className="text-sm text-gray-500">Amplía tu red de clientes de forma más efectiva.</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
