"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Card, CardContent } from "@/components/ui/card"

export default function SuscripcionPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile/premium">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">SUSCRIPCIÓN</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-6">
        <p className="text-gray-600 mb-6">Gestiona tu suscripción Premium y descubre todas sus ventajas.</p>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Estado de suscripción</h2>
            <div className="p-4 bg-yellow-50 rounded-lg mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold">Plan Premium</span>
                <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full">Activo</span>
              </div>
              <p className="text-sm text-gray-600 mb-2">Renovación: 19 de Abril de 2023</p>
              <p className="text-sm text-gray-600">Precio: 9,99€/mes</p>
            </div>

            <div className="space-y-3">
              <Button variant="outline" className="w-full">
                Cambiar plan
              </Button>
              <Button variant="outline" className="w-full text-red-500 hover:text-red-600 hover:bg-red-50">
                Cancelar suscripción
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Beneficios Premium</h2>
            <div className="space-y-3">
              <div className="flex items-center">
                <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-xs text-yellow-800">✓</span>
                </div>
                <span className="text-sm">Visualizaciones ilimitadas de perfiles</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-xs text-yellow-800">✓</span>
                </div>
                <span className="text-sm">Estadísticas detalladas</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-xs text-yellow-800">✓</span>
                </div>
                <span className="text-sm">Posicionamiento prioritario</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-xs text-yellow-800">✓</span>
                </div>
                <span className="text-sm">Insignia de verificación</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-xs text-yellow-800">✓</span>
                </div>
                <span className="text-sm">Herramientas avanzadas</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-xs text-yellow-800">✓</span>
                </div>
                <span className="text-sm">Soporte prioritario</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-bold mb-4">Otros planes disponibles</h2>
            <div className="space-y-4">
              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Plan Anual</h3>
                <p className="text-xs text-gray-500 mb-2">Ahorra un 20% pagando anualmente</p>
                <div className="flex justify-between items-center">
                  <span className="font-bold">95,88€/año</span>
                  <Button variant="outline" size="sm">
                    Cambiar
                  </Button>
                </div>
              </div>

              <div className="p-3 border rounded-lg">
                <h3 className="text-sm font-bold mb-1">Plan Empresarial</h3>
                <p className="text-xs text-gray-500 mb-2">Para equipos de profesionales</p>
                <div className="flex justify-between items-center">
                  <span className="font-bold">29,99€/mes</span>
                  <Button variant="outline" size="sm">
                    Cambiar
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
