import { ArrowLeft, Sparkles, Zap, Search, User, Clock, Filter, Brain, Shield, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"

export default function QuickIAPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <div className="p-4 flex items-center border-b">
        <Link href="/profile/settings">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <span className="ml-2 text-sm">Volver a Configuración</span>
      </div>

      <div className="px-6 py-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <h1 className="font-bold text-lg">QuickIA</h1>
            <Badge className="ml-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white border-0">Beta</Badge>
          </div>
          <Sparkles className="h-5 w-5 text-purple-500" />
        </div>

        <Card className="mb-6 border border-purple-100 bg-gradient-to-br from-white to-purple-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Brain className="h-5 w-5 mr-2 text-purple-500" />
              ¿Qué es QuickIA?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground leading-relaxed">
              QuickIA es nuestra tecnología de inteligencia artificial diseñada para optimizar tu experiencia en la
              plataforma. Utilizando algoritmos avanzados, QuickIA analiza tus preferencias, comportamiento y las
              tendencias del mercado para ofrecerte recomendaciones personalizadas y mejorar tu visibilidad.
            </p>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <section>
            <h2 className="text-lg font-medium flex items-center mb-4">
              <Zap className="h-5 w-5 mr-2 text-purple-500" />
              Funcionalidades principales
            </h2>

            <div className="grid gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center">
                    <User className="h-4 w-4 mr-2 text-purple-500" />
                    Optimización de perfil
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    QuickIA analiza tu perfil y te sugiere mejoras para destacar tus habilidades y experiencia,
                    aumentando tu visibilidad y atractivo para potenciales clientes.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center">
                    <Search className="h-4 w-4 mr-2 text-purple-500" />
                    Búsqueda inteligente
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Encuentra perfiles y servicios utilizando lenguaje natural. Simplemente describe lo que necesitas y
                    QuickIA te mostrará las mejores opciones disponibles.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center">
                    <Star className="h-4 w-4 mr-2 text-purple-500" />
                    Recomendaciones personalizadas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Recibe sugerencias de servicios, clientes y colaboraciones basadas en tu historial, preferencias y
                    las tendencias actuales del mercado.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center">
                    <Filter className="h-4 w-4 mr-2 text-purple-500" />
                    Análisis de tendencias
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Mantente al día con las demandas del mercado y descubre oportunidades emergentes que podrían
                    interesarte según las tendencias actuales.
                  </p>
                </CardContent>
              </Card>
            </div>
          </section>

          <Separator />

          <section>
            <h2 className="text-lg font-medium flex items-center mb-4">
              <Shield className="h-5 w-5 mr-2 text-purple-500" />
              Beneficios para tu perfil
            </h2>

            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="bg-purple-100 rounded-full p-1.5 mt-0.5">
                  <Zap className="h-4 w-4 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium text-sm">Mayor visibilidad</h3>
                  <p className="text-sm text-muted-foreground">
                    Optimiza tu perfil para aparecer en los primeros resultados de búsqueda relevantes para tus
                    habilidades.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="bg-purple-100 rounded-full p-1.5 mt-0.5">
                  <Clock className="h-4 w-4 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium text-sm">Ahorro de tiempo</h3>
                  <p className="text-sm text-muted-foreground">
                    Automatiza la optimización de tu perfil y la búsqueda de oportunidades, permitiéndote enfocarte en
                    lo que realmente importa.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="bg-purple-100 rounded-full p-1.5 mt-0.5">
                  <User className="h-4 w-4 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium text-sm">Conexiones de calidad</h3>
                  <p className="text-sm text-muted-foreground">
                    Conecta con clientes y colaboradores que realmente se alinean con tus habilidades y objetivos
                    profesionales.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="bg-purple-100 rounded-full p-1.5 mt-0.5">
                  <Search className="h-4 w-4 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium text-sm">Posicionamiento estratégico</h3>
                  <p className="text-sm text-muted-foreground">
                    Recibe insights sobre cómo destacar en tu nicho y diferenciarte de la competencia.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <Separator />

          <section>
            <h2 className="text-lg font-medium flex items-center mb-4">
              <Sparkles className="h-5 w-5 mr-2 text-purple-500" />
              Configuración
            </h2>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Activar QuickIA</p>
                  <p className="text-sm text-muted-foreground">
                    Habilita todas las funciones de inteligencia artificial
                  </p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Sugerencias de perfil</p>
                  <p className="text-sm text-muted-foreground">Recibe recomendaciones para mejorar tu perfil</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Análisis de mercado</p>
                  <p className="text-sm text-muted-foreground">Obtén insights sobre tendencias y oportunidades</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Recomendaciones personalizadas</p>
                  <p className="text-sm text-muted-foreground">Sugerencias basadas en tu actividad</p>
                </div>
                <Switch defaultChecked />
              </div>
            </div>
          </section>

          <div className="bg-purple-50 p-4 rounded-lg mt-6">
            <p className="text-sm text-center text-purple-700">
              QuickIA está en fase beta. Tus comentarios nos ayudan a mejorar.
            </p>
            <div className="flex justify-center mt-2">
              <Button variant="outline" size="sm" className="text-xs border-purple-200 hover:bg-purple-100">
                Enviar comentarios
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
