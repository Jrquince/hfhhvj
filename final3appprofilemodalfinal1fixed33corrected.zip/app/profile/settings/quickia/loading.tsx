import { Skeleton } from "@/components/ui/skeleton"

export default function QuickIALoading() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <div className="p-4 flex items-center border-b">
        <Skeleton className="h-8 w-8 rounded-full" />
        <Skeleton className="ml-2 h-4 w-24" />
      </div>

      <div className="px-6 py-4">
        <div className="flex items-center justify-between mb-6">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-5 w-5 rounded-full" />
        </div>

        <Skeleton className="h-[120px] w-full rounded-lg mb-6" />

        <div className="space-y-6">
          <div>
            <Skeleton className="h-6 w-48 mb-4" />
            <div className="grid gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-[100px] w-full rounded-lg" />
              ))}
            </div>
          </div>

          <Skeleton className="h-[1px] w-full my-6" />

          <div>
            <Skeleton className="h-6 w-48 mb-4" />
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-start space-x-3">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-3/4" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Skeleton className="h-[1px] w-full my-6" />

          <div>
            <Skeleton className="h-6 w-48 mb-4" />
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-48" />
                  </div>
                  <Skeleton className="h-6 w-10 rounded-full" />
                </div>
              ))}
            </div>
          </div>

          <Skeleton className="h-[100px] w-full rounded-lg mt-6" />
        </div>
      </div>
    </div>
  )
}
