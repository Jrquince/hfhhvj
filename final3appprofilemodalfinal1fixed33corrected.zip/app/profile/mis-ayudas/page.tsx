import { ArrowLeft, Clock, Check, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import Link from "next/link"
import Image from "next/image"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function MisAyudasPage() {
  const ayudas = [
    {
      id: 1,
      user: "María Ruiz",
      avatar: "MR",
      date: "15 mayo, 2025",
      description: "Ayuda con mudanza",
      status: "Completada",
      rating: 5,
    },
    {
      id: 2,
      user: "Carlos Martín",
      avatar: "CM",
      date: "10 mayo, 2025",
      description: "Reparación de grifo",
      status: "Completada",
      rating: 4,
    },
    {
      id: 3,
      user: "Elena Sánchez",
      avatar: "ES",
      date: "5 mayo, 2025",
      description: "Clases de matemáticas",
      status: "Completada",
      rating: 5,
    },
    {
      id: 4,
      user: "Pablo Arzar",
      avatar: "PA",
      date: "1 mayo, 2025",
      description: "Montaje de muebles",
      status: "Completada",
      rating: 4,
    },
    {
      id: 5,
      user: "Lucía Gómez",
      avatar: "LG",
      date: "25 abril, 2025",
      description: "Paseo de mascota",
      status: "Completada",
      rating: 5,
    },
  ]

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/profile">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">MIS AYUDAS</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <p className="text-sm text-gray-500 mb-6">Historial de ayudas que has proporcionado a otros usuarios.</p>

        <div className="space-y-6">
          {ayudas.map((ayuda) => (
            <div key={ayuda.id} className="relative">
              {/* Línea de tiempo */}
              {ayuda.id < ayudas.length && <div className="absolute left-5 top-12 bottom-0 w-0.5 bg-gray-200"></div>}

              <div className="flex">
                <div className="relative">
                  <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center z-10 relative">
                    <Clock className="h-5 w-5 text-yellow-500" />
                  </div>
                </div>

                <div className="ml-4 flex-1">
                  <div className="text-xs text-gray-500 mb-1">{ayuda.date}</div>
                  <div className="border rounded-xl p-4">
                    <div className="flex items-center mb-2">
                      <Avatar className="h-8 w-8 border">
                        <Image
                          src={`/placeholder.svg?height=32&width=32&text=${ayuda.avatar}`}
                          alt={ayuda.user}
                          width={32}
                          height={32}
                          className="rounded-full"
                        />
                      </Avatar>
                      <div className="ml-2">
                        <h3 className="font-medium text-sm">{ayuda.user}</h3>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-3 w-3 ${
                                i < ayuda.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <p className="text-sm">{ayuda.description}</p>
                    <div className="flex justify-between items-center mt-2">
                      <div className="flex items-center text-xs text-green-500">
                        <Check className="h-3 w-3 mr-1" />
                        <span>{ayuda.status}</span>
                      </div>
                      <Button className="text-xs rounded-full bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 h-6">
                        Ver detalles
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
