import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center border-b">
        <Skeleton className="h-6 w-6 rounded-full mr-4" />
        <Skeleton className="h-6 w-40" />
      </div>

      {/* Resumen de valoraciones */}
      <div className="p-4 bg-gray-50">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-7 w-10 mb-2" />
            <Skeleton className="h-4 w-24 mb-2" />
            <Skeleton className="h-3 w-32" />
          </div>
          <div className="space-y-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-2 w-40" />
            ))}
          </div>
        </div>
      </div>

      {/* Lista de valoraciones */}
      <div className="p-4">
        <Skeleton className="h-5 w-40 mb-4" />
        <div className="space-y-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="border-b pb-4">
              <div className="flex items-center mb-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="ml-3">
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
              <Skeleton className="h-4 w-full mb-1" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
