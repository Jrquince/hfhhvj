"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Star, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BottomNavigation } from "@/components/bottom-navigation"
import { getAvatarByUserId } from "@/lib/avatar-utils"

export default function ValoracionesPage() {
  const [activeTab, setActiveTab] = useState("recibidas")

  // Datos de ejemplo para valoraciones recibidas
  const valoracionesRecibidas = [
    {
      id: 1,
      userId: 10,
      name: "Laura G.",
      rating: 5,
      comment: "Excelente trabajo, muy profesional y puntual. Lo recomiendo totalmente.",
      date: "hace 2 días",
      service: "Reparación de tubería",
    },
    {
      id: 2,
      userId: 11,
      name: "Miguel R.",
      rating: 5,
      comment: "Solucionó el problema rápidamente. Buen precio y servicio.",
      date: "hace 1 semana",
      service: "Instalación de grifo",
    },
    {
      id: 3,
      userId: 16,
      name: "Elena S.",
      rating: 4,
      comment: "Muy buen trabajo aunque tardó un poco más de lo previsto.",
      date: "hace 2 semanas",
      service: "Reparación de caldera",
    },
    {
      id: 4,
      userId: 13,
      name: "Javier M.",
      rating: 5,
      comment: "Profesional, rápido y eficiente. Volveré a contactar para futuros trabajos.",
      date: "hace 3 semanas",
      service: "Instalación de lavadora",
    },
    {
      id: 5,
      userId: 17,
      name: "Carmen L.",
      rating: 4,
      comment: "Buen servicio en general, recomendable.",
      date: "hace 1 mes",
      service: "Revisión de instalación",
    },
  ]

  // Datos de ejemplo para valoraciones enviadas
  const valoracionesEnviadas = [
    {
      id: 1,
      userId: 18,
      name: "Electricista Express",
      rating: 5,
      comment: "Excelente servicio, muy recomendable para materiales de fontanería.",
      date: "hace 1 semana",
      service: "Compra de materiales",
    },
    {
      id: 2,
      userId: 19,
      name: "Ferretería Central",
      rating: 4,
      comment: "Buenos precios y atención rápida.",
      date: "hace 2 semanas",
      service: "Compra de herramientas",
    },
    {
      id: 3,
      userId: 14,
      name: "Distribuidora López",
      rating: 5,
      comment: "Excelente calidad en los productos y entrega puntual.",
      date: "hace 1 mes",
      service: "Suministros de fontanería",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/profile">
              <Button variant="ghost" size="icon" className="mr-2">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-lg font-semibold">Valoraciones</h1>
          </div>
          <Link href="/filters">
            <Button variant="ghost" size="icon">
              <Filter className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container pb-16">
        <Tabs defaultValue="recibidas" value={activeTab} onValueChange={setActiveTab}>
          <div className="overflow-x-auto">
            <TabsList className="w-full justify-start p-0 h-auto bg-transparent border-b">
              <TabsTrigger
                value="recibidas"
                className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-yellow-500"
              >
                Recibidas
              </TabsTrigger>
              <TabsTrigger
                value="enviadas"
                className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-yellow-500"
              >
                Enviadas
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="recibidas" className="mt-4">
            <div className="space-y-4">
              {valoracionesRecibidas.map((valoracion) => (
                <div key={valoracion.id} className="bg-white rounded-lg border p-4">
                  <div className="flex justify-between">
                    <div className="flex items-center">
                      <div className="relative w-10 h-10 rounded-full overflow-hidden">
                        <Image
                          src={getAvatarByUserId(valoracion.userId) || "/placeholder.svg"}
                          alt={valoracion.name}
                          width={40}
                          height={40}
                          className="object-cover"
                        />
                      </div>
                      <div className="ml-3">
                        <span className="font-medium">{valoracion.name}</span>
                        <div className="flex items-center mt-0.5">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3.5 h-3.5 ${
                                  i < valoracion.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                }`}
                              />
                            ))}
                          <span className="text-xs text-gray-500 ml-1">{valoracion.date}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                        {valoracion.service}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-3">{valoracion.comment}</p>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="enviadas" className="mt-4">
            <div className="space-y-4">
              {valoracionesEnviadas.map((valoracion) => (
                <div key={valoracion.id} className="bg-white rounded-lg border p-4">
                  <div className="flex justify-between">
                    <div className="flex items-center">
                      <div className="relative w-10 h-10 rounded-full overflow-hidden">
                        <Image
                          src={getAvatarByUserId(valoracion.userId) || "/placeholder.svg"}
                          alt={valoracion.name}
                          width={40}
                          height={40}
                          className="object-cover"
                        />
                      </div>
                      <div className="ml-3">
                        <span className="font-medium">{valoracion.name}</span>
                        <div className="flex items-center mt-0.5">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3.5 h-3.5 ${
                                  i < valoracion.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                }`}
                              />
                            ))}
                          <span className="text-xs text-gray-500 ml-1">{valoracion.date}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                        {valoracion.service}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-3">{valoracion.comment}</p>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <BottomNavigation activeItem="profile" />
    </div>
  )
}
