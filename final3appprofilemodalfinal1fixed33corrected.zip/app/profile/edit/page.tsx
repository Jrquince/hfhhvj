"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ChevronLeft, Camera, MapPin, Briefcase, Calendar, Clock, X, Check } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { getProfileAvatar } from "@/lib/avatar-utils"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export default function EditProfilePage() {
  const { toast } = useToast()
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [name, setName] = useState("Carlos Martínez")
  const [bio, setBio] = useState(
    "Fontanero profesional con más de 10 años de experiencia en instalaciones y reparaciones.",
  )
  const [location, setLocation] = useState("Bilbao, España")
  const [profession, setProfession] = useState("Fontanero")
  const [availability, setAvailability] = useState("Lunes a Viernes")
  const [schedule, setSchedule] = useState("9:00 - 18:00")
  const [skills, setSkills] = useState(["Fontanería", "Calefacción", "Instalaciones", "Reparaciones"])
  const [newSkill, setNewSkill] = useState("")
  const [showAvatarDialog, setShowAvatarDialog] = useState(false)
  const [tempSelectedAvatar, setTempSelectedAvatar] = useState<string | null>(null)

  const handleAddSkill = () => {
    if (newSkill.trim() !== "" && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()])
      setNewSkill("")
      toast({
        title: "Habilidad añadida",
        description: `Se ha añadido "${newSkill.trim()}" a tus habilidades`,
        duration: 2000,
      })
    }
  }

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove))
    toast({
      title: "Habilidad eliminada",
      description: `Se ha eliminado "${skillToRemove}" de tus habilidades`,
      duration: 2000,
    })
  }

  // Usar el mismo avatar que en la página de perfil (hombre con traje oscuro)
  const userAvatar = getProfileAvatar()

  // Avatares disponibles para seleccionar
  const availableAvatars = [
    getProfileAvatar(), // Añadir el avatar actual como primera opción
    "/images/avatars/avatar2.jpeg",
    "/images/avatars/avatar5.jpeg",
    "/images/avatars/avatar6.jpeg",
    "/images/avatars/avatar9.jpeg",
    "/images/avatars/avatar11.jpeg",
    "/images/avatars/avatar13.jpeg",
    "/images/avatars/avatar14.jpeg",
    "/images/avatars/avatar18.jpeg",
    "/images/avatars/avatar19.jpeg",
  ]

  const handleSaveProfile = () => {
    toast({
      title: "Perfil actualizado",
      description: "Los cambios han sido guardados correctamente",
      duration: 3000,
    })
  }

  const handleSelectAvatar = (avatar: string) => {
    setTempSelectedAvatar(avatar)
  }

  const handleConfirmAvatar = () => {
    if (tempSelectedAvatar) {
      setSelectedImage(tempSelectedAvatar)
      setShowAvatarDialog(false)
      toast({
        title: "Avatar actualizado",
        description: "Tu foto de perfil ha sido actualizada",
        duration: 2000,
      })
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center justify-between p-4">
          <Link href="/profile">
            <Button variant="ghost" size="icon">
              <ChevronLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-lg font-semibold">Editar perfil</h1>
          <Link href="/profile">
            <Button size="sm" className="bg-yellow-500 hover:bg-yellow-600" onClick={handleSaveProfile}>
              Guardar
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container py-6 space-y-6">
        {/* Foto de perfil */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4">Foto de perfil</h2>
          <div className="flex flex-col items-center">
            <div className="relative mb-4">
              <div className="w-24 h-24 rounded-full overflow-hidden">
                <Image
                  src={selectedImage || userAvatar}
                  alt="Foto de perfil"
                  width={96}
                  height={96}
                  className="object-cover w-full h-full"
                />
              </div>
              <div
                className="absolute bottom-0 right-0 bg-yellow-500 rounded-full p-2 cursor-pointer"
                onClick={() => setShowAvatarDialog(true)}
              >
                <Camera className="h-4 w-4 text-white" />
              </div>
            </div>
            <Button variant="outline" size="sm" className="text-sm" onClick={() => setShowAvatarDialog(true)}>
              Cambiar foto
            </Button>
          </div>
        </div>

        {/* Información personal */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4">Información personal</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Nombre completo</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onBlur={() => {
                  if (name.trim() === "") {
                    setName("Carlos Martínez")
                    toast({
                      title: "Nombre requerido",
                      description: "El nombre no puede estar vacío",
                      duration: 2000,
                    })
                  }
                }}
              />
            </div>
            <div>
              <Label htmlFor="bio">Biografía</Label>
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="min-h-[100px]"
                placeholder="Cuéntanos sobre ti..."
              />
            </div>
            <div>
              <Label htmlFor="location">Ubicación</Label>
              <div className="relative">
                <Input
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="pl-9"
                  placeholder="Ciudad, País"
                />
                <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Información profesional */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4">Información profesional</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="profession">Profesión</Label>
              <div className="relative">
                <Input
                  id="profession"
                  value={profession}
                  onChange={(e) => setProfession(e.target.value)}
                  className="pl-9"
                  placeholder="Tu profesión"
                />
                <Briefcase className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </div>
            </div>
            <div>
              <Label htmlFor="availability">Disponibilidad</Label>
              <div className="relative">
                <Input
                  id="availability"
                  value={availability}
                  onChange={(e) => setAvailability(e.target.value)}
                  className="pl-9"
                  placeholder="Ej: Lunes a Viernes"
                />
                <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </div>
            </div>
            <div>
              <Label htmlFor="schedule">Horario</Label>
              <div className="relative">
                <Input
                  id="schedule"
                  value={schedule}
                  onChange={(e) => setSchedule(e.target.value)}
                  className="pl-9"
                  placeholder="Ej: 9:00 - 18:00"
                />
                <Clock className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Habilidades */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4">Habilidades</h2>
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              {skills.map((skill) => (
                <div
                  key={skill}
                  className="bg-yellow-50 text-yellow-800 px-3 py-1 rounded-full flex items-center text-sm"
                >
                  {skill}
                  <button
                    onClick={() => handleRemoveSkill(skill)}
                    className="ml-2 text-yellow-600 hover:text-yellow-800"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Añadir habilidad"
                className="flex-1"
                onKeyPress={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault()
                    handleAddSkill()
                  }
                }}
              />
              <Button onClick={handleAddSkill} className="bg-yellow-500 hover:bg-yellow-600">
                Añadir
              </Button>
            </div>
          </div>
        </div>
      </main>

      {/* Dialog para seleccionar avatar */}
      <Dialog open={showAvatarDialog} onOpenChange={setShowAvatarDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Selecciona tu avatar</DialogTitle>
            <DialogDescription>Elige una imagen para tu perfil o sube una foto propia.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-3 gap-4 mt-4">
            {availableAvatars.map((avatar, index) => (
              <div
                key={index}
                className={`relative cursor-pointer rounded-lg overflow-hidden border-2 ${
                  tempSelectedAvatar === avatar ? "border-yellow-500" : "border-transparent"
                }`}
                onClick={() => handleSelectAvatar(avatar)}
              >
                <Image
                  src={avatar || "/placeholder.svg"}
                  alt={`Avatar ${index + 1}`}
                  width={80}
                  height={80}
                  className="w-full h-24 object-cover"
                />
                {tempSelectedAvatar === avatar && (
                  <div className="absolute bottom-1 right-1 bg-yellow-500 rounded-full p-1">
                    <Check className="h-3 w-3 text-white" />
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-4">
            <Button variant="outline" onClick={() => setShowAvatarDialog(false)}>
              Cancelar
            </Button>
            <Button
              className="bg-yellow-500 hover:bg-yellow-600"
              onClick={handleConfirmAvatar}
              disabled={!tempSelectedAvatar}
            >
              Confirmar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
