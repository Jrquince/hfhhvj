"use client"

import type React from "react"

import { useState } from "react"
import {
  ArrowLeft,
  Award,
  Calendar,
  CheckCircle,
  Clock,
  Compass,
  FileText,
  Gift,
  HelpCircle,
  Lightbulb,
  MessageCircle,
  Rocket,
  Send,
  Star,
  Target,
  Zap,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { useRouter } from "next/navigation"

export default function LevelTipsPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("daily")

  // Datos de ejemplo del usuario
  const userLevel = {
    current: 3,
    points: 1250,
    nextLevel: 4,
    pointsNeeded: 2000,
    progress: 62.5, // (1250/2000) * 100
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-md mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button variant="ghost" size="icon" onClick={() => router.back()} className="h-9 w-9">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Volver</span>
          </Button>
          <h1 className="text-xl font-bold">Consejos para subir de nivel</h1>
          <div className="w-9"></div> {/* Spacer para centrar el título */}
        </div>

        {/* Resumen de nivel */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">Tu nivel actual</CardTitle>
              <Badge variant="outline" className="font-bold">
                Nivel {userLevel.current}
              </Badge>
            </div>
            <CardDescription>
              Te faltan {userLevel.pointsNeeded - userLevel.points} puntos para el nivel {userLevel.nextLevel}
            </CardDescription>
          </CardHeader>
          <CardContent className="pb-3">
            <Progress value={userLevel.progress} className="h-2 mb-2" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{userLevel.points} pts</span>
              <span>{userLevel.pointsNeeded} pts</span>
            </div>
          </CardContent>
        </Card>

        {/* Pestañas de consejos */}
        <Tabs defaultValue="daily" value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="daily">Diarios</TabsTrigger>
            <TabsTrigger value="general">Generales</TabsTrigger>
            <TabsTrigger value="advanced">Avanzados</TabsTrigger>
          </TabsList>

          {/* Consejos diarios */}
          <TabsContent value="daily" className="space-y-4">
            <TipCard
              icon={<MessageCircle className="h-5 w-5 text-blue-500" />}
              title="Responde rápido a mensajes"
              description="Responder a los mensajes en menos de 1 hora aumenta tu puntuación de respuesta."
              points={15}
              highlighted={true}
            />

            <TipCard
              icon={<CheckCircle className="h-5 w-5 text-green-500" />}
              title="Completa tu perfil"
              description="Añade una foto profesional, descripción y todos tus servicios."
              points={20}
            />

            <TipCard
              icon={<Calendar className="h-5 w-5 text-purple-500" />}
              title="Actualiza tu disponibilidad"
              description="Mantén tu calendario actualizado para recibir más solicitudes compatibles."
              points={10}
            />

            <TipCard
              icon={<Send className="h-5 w-5 text-blue-500" />}
              title="Comparte en redes sociales"
              description="Comparte tu perfil en tus redes sociales para ganar puntos extra."
              points={25}
            />

            <TipCard
              icon={<Star className="h-5 w-5 text-yellow-500" />}
              title="Pide valoraciones"
              description="Solicita a tus clientes que dejen una valoración después del servicio."
              points={30}
              highlighted={true}
            />
          </TabsContent>

          {/* Consejos generales */}
          <TabsContent value="general" className="space-y-4">
            <TipCard
              icon={<FileText className="h-5 w-5 text-blue-500" />}
              title="Crea contenido de calidad"
              description="Publica artículos o consejos relacionados con tus servicios."
              points={40}
              highlighted={true}
            />

            <TipCard
              icon={<Target className="h-5 w-5 text-red-500" />}
              title="Especialízate en nichos"
              description="Define claramente tus especialidades para destacar en búsquedas específicas."
              points={35}
            />

            <TipCard
              icon={<Clock className="h-5 w-5 text-orange-500" />}
              title="Mantén horarios consistentes"
              description="Establece y mantén horarios regulares para aumentar tu fiabilidad."
              points={25}
            />

            <TipCard
              icon={<Compass className="h-5 w-5 text-green-500" />}
              title="Amplía tu zona de servicio"
              description="Aumenta el radio de tu zona de servicio para llegar a más clientes."
              points={30}
            />

            <TipCard
              icon={<Award className="h-5 w-5 text-purple-500" />}
              title="Obtén certificaciones"
              description="Añade certificaciones relevantes a tu perfil para aumentar la confianza."
              points={50}
              highlighted={true}
            />
          </TabsContent>

          {/* Consejos avanzados */}
          <TabsContent value="advanced" className="space-y-4">
            <TipCard
              icon={<Rocket className="h-5 w-5 text-purple-500" />}
              title="Crea paquetes de servicios"
              description="Ofrece paquetes que combinen varios de tus servicios a un precio especial."
              points={60}
              highlighted={true}
            />

            <TipCard
              icon={<Zap className="h-5 w-5 text-yellow-500" />}
              title="Respuesta inmediata"
              description="Mantén un tiempo de respuesta inferior a 15 minutos durante 7 días consecutivos."
              points={75}
            />

            <TipCard
              icon={<Gift className="h-5 w-5 text-red-500" />}
              title="Programa ofertas especiales"
              description="Crea y programa ofertas temporales para momentos de baja demanda."
              points={55}
            />

            <TipCard
              icon={<Lightbulb className="h-5 w-5 text-amber-500" />}
              title="Crea guías y tutoriales"
              description="Desarrolla contenido educativo relacionado con tus servicios."
              points={70}
              highlighted={true}
            />

            <TipCard
              icon={<HelpCircle className="h-5 w-5 text-blue-500" />}
              title="Participa en la comunidad"
              description="Responde preguntas y ayuda a otros profesionales en los foros de la plataforma."
              points={50}
            />
          </TabsContent>
        </Tabs>

        {/* Recursos adicionales */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recursos adicionales</CardTitle>
            <CardDescription>Explora estos recursos para maximizar tu crecimiento</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="bg-primary/10 p-2 rounded-full">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Guía completa de niveles</h3>
                <p className="text-sm text-muted-foreground">Descubre todos los beneficios de cada nivel</p>
              </div>
            </div>

            <Separator />

            <div className="flex items-start gap-3">
              <div className="bg-primary/10 p-2 rounded-full">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Webinars semanales</h3>
                <p className="text-sm text-muted-foreground">Sesiones en vivo con expertos de la plataforma</p>
              </div>
            </div>

            <Separator />

            <div className="flex items-start gap-3">
              <div className="bg-primary/10 p-2 rounded-full">
                <Target className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Programa de mentores</h3>
                <p className="text-sm text-muted-foreground">Conecta con profesionales de alto nivel</p>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" onClick={() => router.push("/profile")}>
              Volver al perfil
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

// Componente para las tarjetas de consejos
function TipCard({
  icon,
  title,
  description,
  points,
  highlighted = false,
}: {
  icon: React.ReactNode
  title: string
  description: string
  points: number
  highlighted?: boolean
}) {
  return (
    <Card
      className={highlighted ? "border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20 dark:border-yellow-900/50" : ""}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <div className="mt-1">{icon}</div>
          <div className="flex-1">
            <h3 className="font-medium mb-1">{title}</h3>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
          <Badge variant="secondary" className="ml-2 shrink-0">
            +{points} pts
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
