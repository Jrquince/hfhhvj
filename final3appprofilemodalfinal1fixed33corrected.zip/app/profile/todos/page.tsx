"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { ProfileImage } from "@/components/profile-image"

// Generador de anuncios para el usuario
const generateUserPosts = (count: number) => {
  const categories = ["Vivienda", "Profesionales", "Hogar", "Educación", "Motor", "Tecnología", "Mascotas", "Eventos"]

  const titles = [
    "Busco un compañero de piso que esté estudiando para el curso 2025/2026 en la zona de Deusto.",
    "Necesito ayuda para montar un mueble de Ikea en mi apartamento en Bagatza",
    "Ofrezco servicios de fontanería en toda la zona de Bilbao",
    "Busco profesor/a particular de matemáticas para nivel universitario",
    "Vendo coche seminuevo en perfecto estado. 50.000km",
    "Necesito reparación urgente de mi ordenador portátil. No enciende",
    "Busco paseador/a para mi perro durante las mañanas",
    "Ofrezco servicios de limpieza por horas. Experiencia demostrable",
    "Vendo moto en perfecto estado. Recién revisada",
    "Busco compañeros para compartir gastos de viaje a Portugal",
    "Se ofrece profesor de inglés nativo para clases particulares",
    "Necesito ayuda con mudanza este fin de semana",
    "Ofrezco servicios de diseño gráfico para pequeñas empresas",
    "Busco canguro para niños de 5 y 7 años, tardes entre semana",
    "Vendo bicicleta de montaña casi sin uso",
    "Necesito un electricista para instalación de luces en terraza",
    "Ofrezco clases de guitarra para principiantes",
    "Busco compañero/a de gimnasio zona centro",
    "Vendo libros universitarios de Derecho en buen estado",
    "Necesito ayuda con reparación de lavadora",
  ]

  const posts = []

  for (let i = 0; i < count; i++) {
    const date = new Date()
    date.setDate(date.getDate() - i * 5) // Cada post es 5 días más antiguo que el anterior

    posts.push({
      id: i + 1,
      title: titles[i % titles.length],
      category: categories[i % categories.length],
      date: date.toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit", year: "2-digit" }),
      views: Math.floor(Math.random() * 50) + 5,
      responses: Math.floor(Math.random() * 10),
      active: i < 5, // Los primeros 5 están activos
    })
  }

  return posts
}

export default function TodosPage() {
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [activeFilter, setActiveFilter] = useState("Todos")

  useEffect(() => {
    // Simular carga de datos
    setLoading(true)
    setTimeout(() => {
      setPosts(generateUserPosts(15))
      setLoading(false)
    }, 1000)
  }, [])

  const filteredPosts =
    activeFilter === "Todos"
      ? posts
      : activeFilter === "Activos"
        ? posts.filter((post) => post.active)
        : posts.filter((post) => !post.active)

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b border-gray-200">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/profile" className="mr-4">
              <ChevronLeft className="w-6 h-6 text-gray-700" />
            </Link>
            <h1 className="text-xl font-semibold">Todos mis anuncios</h1>
          </div>
          <ProfileImage src="/images/profiles/profile1.jpeg" alt="Perfil" size="sm" />
        </div>
      </header>

      {/* Filters */}
      <div className="sticky top-16 z-10 flex p-2 bg-white border-b border-gray-200">
        <button
          onClick={() => setActiveFilter("Todos")}
          className={`flex-1 py-2 text-sm font-medium rounded-md ${
            activeFilter === "Todos" ? "bg-blue-100 text-blue-600" : "text-gray-600"
          }`}
        >
          Todos
        </button>
        <button
          onClick={() => setActiveFilter("Activos")}
          className={`flex-1 py-2 text-sm font-medium rounded-md ${
            activeFilter === "Activos" ? "bg-blue-100 text-blue-600" : "text-gray-600"
          }`}
        >
          Activos
        </button>
        <button
          onClick={() => setActiveFilter("Inactivos")}
          className={`flex-1 py-2 text-sm font-medium rounded-md ${
            activeFilter === "Inactivos" ? "bg-blue-100 text-blue-600" : "text-gray-600"
          }`}
        >
          Inactivos
        </button>
      </div>

      {/* Content */}
      <main className="flex-1 p-4">
        {loading ? (
          // Loading skeleton
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="p-4 bg-white rounded-lg shadow animate-pulse">
                <div className="w-3/4 h-4 mb-2 bg-gray-200 rounded"></div>
                <div className="w-1/2 h-3 mb-4 bg-gray-200 rounded"></div>
                <div className="flex justify-between">
                  <div className="w-1/4 h-3 bg-gray-200 rounded"></div>
                  <div className="w-1/4 h-3 bg-gray-200 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <Link href={`/post-detail/${post.id}`} key={post.id}>
                  <div className={`p-4 bg-white rounded-lg shadow ${!post.active && "opacity-70"}`}>
                    <h3 className="mb-1 text-sm font-medium text-gray-900">{post.title}</h3>
                    <p className="mb-2 text-xs text-gray-500">{post.category}</p>
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>{post.date}</span>
                      <div className="flex space-x-3">
                        <span>{post.views} visitas</span>
                        <span>{post.responses} respuestas</span>
                      </div>
                    </div>
                    {!post.active && <div className="mt-2 text-xs font-medium text-gray-500">Anuncio inactivo</div>}
                  </div>
                </Link>
              ))
            ) : (
              <div className="p-8 text-center text-gray-500">
                No hay anuncios que coincidan con el filtro seleccionado.
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
