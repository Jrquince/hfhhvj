import { ArrowLeft, Home, Wifi, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import Link from "next/link"
import Image from "next/image"

export default function RoommatePostPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M19 21L12 16L5 21V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H17C17.5304 3 18.0391 3.21071 18.4142 3.58579C18.7893 3.96086 19 4.46957 19 5V21Z" />
          </svg>
        </Button>
      </div>

      {/* Post content */}
      <div className="flex-1 px-6 pb-6">
        <div className="text-center mb-4">
          <h1 className="font-bold text-base">Busco un compañero/a de piso para el año académico 25/26 en Bilbao.</h1>
        </div>

        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 bg-yellow-50 rounded-full flex items-center justify-center">
            <Home className="h-8 w-8 text-yellow-500" />
          </div>
        </div>

        <div className="flex justify-center mb-4">
          <div className="w-2 h-2 rounded-full bg-black mx-1"></div>
          <div className="w-2 h-2 rounded-full bg-gray-300 mx-1"></div>
        </div>

        <div className="mb-6">
          <div className="flex items-center mb-2">
            <h2 className="font-bold text-base">Busco un compañero/a de piso para el año académico 25/26 en Bilbao.</h2>
            <Wifi className="h-4 w-4 ml-2" />
          </div>

          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <h3 className="font-medium text-sm mb-2">DESCRIPCIÓN</h3>
            <p className="text-sm text-gray-600">
              Soy estudiante de segundo año en la Universidad de Deusto y estoy buscando un compañero para compartir
              habitación en el barrio de Indautxu, a menos de 10 minutos de la universidad.
            </p>
          </div>

          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <div className="flex">
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
              </div>
              <span className="text-xs ml-1">4.8</span>
            </div>
            <div className="text-xs text-gray-500">Recomendación de los usuarios</div>
            <div className="flex items-center">
              <span className="text-xs mr-1">50</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 20V10" />
                <path d="M18 14L12 20L6 14" />
                <path d="M12 4V6" />
              </svg>
            </div>
          </div>

          <div className="flex items-center mb-4">
            <Avatar className="h-10 w-10 border">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="User avatar"
                width={40}
                height={40}
                className="rounded-full"
              />
            </Avatar>
            <div className="ml-3">
              <h3 className="font-medium text-sm">Nerea</h3>
              <div className="flex items-center">
                <span className="text-xs text-gray-500">Estudiante universitaria</span>
              </div>
            </div>
          </div>

          <div className="flex space-x-2 mb-4">
            <div className="flex items-center text-xs bg-gray-100 rounded-full px-3 py-1">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <path d="M12 8L12 12L16 14" />
              </svg>
              <span className="ml-1">Disponible</span>
            </div>
            <div className="flex items-center text-xs bg-gray-100 rounded-full px-3 py-1">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" />
                <path d="M2 12H22" />
                <path d="M12 2C14.5013 4.73835 15.9228 8.29203 16 12C15.9228 15.708 14.5013 19.2616 12 22C9.49872 19.2616 8.07725 15.708 8 12C8.07725 8.29203 9.49872 4.73835 12 2V2Z" />
              </svg>
              <span className="ml-1">Presencial</span>
            </div>
          </div>
        </div>

        <Link href="/chat-detail">
          <Button className="w-full rounded-full bg-yellow-500 hover:bg-yellow-600 text-white mb-4">APUNTARME</Button>
        </Link>
      </div>

      {/* Bottom navigation */}
      <div className="border-t flex justify-around py-3 bg-white">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <Home className="h-6 w-6" />
          </Button>
        </Link>
        <Link href="/map">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 13C13.6569 13 15 11.6569 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.6569 10.3431 13 12 13Z" />
              <path d="M12 22C16 18 20 14.4183 20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10C4 14.4183 8 18 12 22Z" />
            </svg>
          </Button>
        </Link>
        <Link href="/create-post">
          <Button
            variant="default"
            size="icon"
            className="h-12 w-12 rounded-full bg-black flex flex-col items-center justify-center"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
          </Button>
        </Link>
        <Link href="/saved">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M19 21L12 16L5 21V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H17C17.5304 3 18.0391 3.21071 18.4142 3.58579C18.7893 3.96086 19 4.46957 19 5V21Z" />
            </svg>
          </Button>
        </Link>
        <Link href="/profile">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" />
              <circle cx="12" cy="7" r="4" />
            </svg>
          </Button>
        </Link>
      </div>
    </div>
  )
}
