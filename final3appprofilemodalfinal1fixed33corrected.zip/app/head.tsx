export default function Head() {
  return (
    <>
      <link rel="icon" href="/placeholder-logo.svg" />
      <link rel="shortcut icon" href="/favicon.ico" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
    </>
  )
}
