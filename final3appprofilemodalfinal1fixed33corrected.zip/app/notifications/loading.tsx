import { Skeleton } from "@/components/ui/skeleton"

export default function NotificationsLoading() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center justify-between p-4">
          <div className="flex items-center">
            <Skeleton className="h-10 w-10 rounded-full" />
            <Skeleton className="h-6 w-32 ml-2" />
          </div>
          <div className="flex items-center space-x-2">
            <Skeleton className="h-8 w-40" />
            <Skeleton className="h-10 w-10 rounded-full" />
          </div>
        </div>
      </header>

      <main className="flex-1 container pb-16">
        <div className="overflow-x-auto">
          <div className="flex border-b">
            <Skeleton className="h-10 w-1/4 mx-1" />
            <Skeleton className="h-10 w-1/4 mx-1" />
            <Skeleton className="h-10 w-1/4 mx-1" />
            <Skeleton className="h-10 w-1/4 mx-1" />
          </div>
        </div>

        <div className="divide-y mt-4">
          {Array(8)
            .fill(0)
            .map((_, index) => (
              <div key={index} className="flex items-center py-4 px-2">
                <Skeleton className="h-12 w-12 rounded-full mr-3" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-3 w-48" />
                </div>
                <div className="ml-2">
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
            ))}
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t">
        <div className="max-w-md mx-auto flex justify-between items-center px-4 py-2">
          {Array(5)
            .fill(0)
            .map((_, index) => (
              <Skeleton key={index} className="h-14 w-14" />
            ))}
        </div>
      </div>
    </div>
  )
}
