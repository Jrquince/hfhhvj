import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProfileAvatar } from "@/components/profile-avatar"
import { getUniqueProfileImages } from "@/utils/profile-images"
import { ArrowLeft, Settings } from "lucide-react"
import Link from "next/link"

// Generar datos de notificaciones con imágenes variadas
const generateNotifications = () => {
  const profileImages = getUniqueProfileImages(15)

  return {
    today: [
      {
        id: 1,
        userId: 101,
        username: "Laura_Garcia",
        profileImage: profileImages[0],
        content: "ha aceptado tu solicitud de servicio",
        time: "Hace 30 minutos",
        read: false,
      },
      {
        id: 2,
        userId: 102,
        username: "Carlos_Martinez",
        profileImage: profileImages[1],
        content: "ha valorado tu servicio con 5 estrellas",
        time: "Hace 2 horas",
        read: false,
      },
      {
        id: 3,
        userId: 103,
        username: "Ana_Lopez",
        profileImage: profileImages[2],
        content: "te ha enviado un mensaje",
        time: "Hace 3 horas",
        read: true,
      },
    ],
    earlier: [
      {
        id: 4,
        userId: 104,
        username: "Miguel_Fernandez",
        profileImage: profileImages[3],
        content: "ha solicitado tus servicios",
        time: "Ayer",
        read: true,
      },
      {
        id: 5,
        userId: 105,
        username: "Sofia_Rodriguez",
        profileImage: profileImages[4],
        content: "ha comentado en tu publicación",
        time: "Ayer",
        read: true,
      },
      {
        id: 6,
        userId: 106,
        username: "Pablo_Sanchez",
        profileImage: profileImages[5],
        content: "ha guardado tu perfil",
        time: "Hace 2 días",
        read: true,
      },
      {
        id: 7,
        userId: 107,
        username: "Elena_Gomez",
        profileImage: profileImages[6],
        content: "ha valorado tu servicio con 4 estrellas",
        time: "Hace 3 días",
        read: true,
      },
    ],
    requests: [
      {
        id: 8,
        userId: 108,
        username: "Javier_Diaz",
        profileImage: profileImages[7],
        content: "quiere contactar contigo para un servicio de fontanería",
        time: "Hace 1 hora",
        read: false,
      },
      {
        id: 9,
        userId: 109,
        username: "Carmen_Ruiz",
        profileImage: profileImages[8],
        content: "necesita un presupuesto para un trabajo de electricidad",
        time: "Hace 5 horas",
        read: false,
      },
      {
        id: 10,
        userId: 110,
        username: "David_Moreno",
        profileImage: profileImages[9],
        content: "quiere contratar tus servicios de carpintería",
        time: "Ayer",
        read: true,
      },
    ],
  }
}

const notifications = generateNotifications()

export default function NotificationsPage() {
  return (
    <div className="container max-w-md mx-auto pb-16">
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-semibold">Notificaciones</h1>
        </div>
        <Link href="/notifications/settings">
          <Button variant="ghost" size="icon">
            <Settings className="h-5 w-5" />
          </Button>
        </Link>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="all">Todas</TabsTrigger>
          <TabsTrigger value="unread">No leídas</TabsTrigger>
          <TabsTrigger value="requests">Solicitudes</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="space-y-1">
            <h2 className="text-sm font-medium text-gray-500 px-4 py-2">Hoy</h2>
            {notifications.today.map((notification) => (
              <NotificationItem key={notification.id} notification={notification} />
            ))}

            <h2 className="text-sm font-medium text-gray-500 px-4 py-2 mt-4">Anteriores</h2>
            {notifications.earlier.map((notification) => (
              <NotificationItem key={notification.id} notification={notification} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="unread">
          <div className="space-y-1">
            {[...notifications.today, ...notifications.earlier, ...notifications.requests]
              .filter((notification) => !notification.read)
              .map((notification) => (
                <NotificationItem key={notification.id} notification={notification} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="requests">
          <div className="space-y-1">
            {notifications.requests.map((notification) => (
              <NotificationItem key={notification.id} notification={notification} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface NotificationItemProps {
  notification: {
    id: number
    userId: number
    username: string
    profileImage: string
    content: string
    time: string
    read: boolean
  }
}

function NotificationItem({ notification }: NotificationItemProps) {
  return (
    <Card className={`border-0 shadow-none ${notification.read ? "bg-transparent" : "bg-blue-50"}`}>
      <CardContent className="p-3">
        <div className="flex items-start space-x-3">
          <ProfileAvatar
            src={notification.profileImage}
            userId={notification.userId}
            fallback={notification.username[0]}
          />
          <div className="flex-1">
            <p className="text-sm">
              <span className="font-medium">{notification.username}</span> {notification.content}
            </p>
            <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
          </div>
          {!notification.read && <div className="h-2 w-2 rounded-full bg-blue-500 mt-2"></div>}
        </div>
      </CardContent>
    </Card>
  )
}
