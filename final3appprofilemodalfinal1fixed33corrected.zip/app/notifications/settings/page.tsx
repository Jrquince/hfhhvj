"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { BottomNavigation } from "@/components/bottom-navigation"
import { useToast } from "@/hooks/use-toast"

export default function NotificationSettingsPage() {
  const { toast } = useToast()
  const [settings, setSettings] = useState({
    messages: true,
    mentions: true,
    likes: true,
    comments: true,
    followers: true,
    system: true,
    email: false,
    push: true,
    sound: true,
    vibration: true,
  })

  const handleToggle = (setting: keyof typeof settings) => {
    setSettings((prev) => {
      const newSettings = { ...prev, [setting]: !prev[setting] }

      toast({
        title: "Configuración actualizada",
        description: `Notificaciones de ${setting} ${newSettings[setting] ? "activadas" : "desactivadas"}`,
        duration: 2000,
      })

      return newSettings
    })
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center p-4">
          <Link href="/notifications">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-lg font-semibold">Configuración de notificaciones</h1>
        </div>
      </header>

      <main className="flex-1 container pb-16">
        <div className="bg-white rounded-lg shadow-sm mt-4">
          <div className="p-4 border-b">
            <h2 className="font-medium">Tipos de notificaciones</h2>
          </div>
          <div className="divide-y">
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Mensajes</p>
                <p className="text-sm text-gray-500">Notificaciones de mensajes nuevos</p>
              </div>
              <Switch checked={settings.messages} onCheckedChange={() => handleToggle("messages")} />
            </div>
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Menciones</p>
                <p className="text-sm text-gray-500">Cuando alguien te menciona</p>
              </div>
              <Switch checked={settings.mentions} onCheckedChange={() => handleToggle("mentions")} />
            </div>
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Me gusta</p>
                <p className="text-sm text-gray-500">Cuando alguien da me gusta a tu contenido</p>
              </div>
              <Switch checked={settings.likes} onCheckedChange={() => handleToggle("likes")} />
            </div>
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Comentarios</p>
                <p className="text-sm text-gray-500">Cuando alguien comenta en tu contenido</p>
              </div>
              <Switch checked={settings.comments} onCheckedChange={() => handleToggle("comments")} />
            </div>
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Nuevos seguidores</p>
                <p className="text-sm text-gray-500">Cuando alguien te sigue</p>
              </div>
              <Switch checked={settings.followers} onCheckedChange={() => handleToggle("followers")} />
            </div>
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Sistema</p>
                <p className="text-sm text-gray-500">Actualizaciones y novedades de la aplicación</p>
              </div>
              <Switch checked={settings.system} onCheckedChange={() => handleToggle("system")} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm mt-4">
          <div className="p-4 border-b">
            <h2 className="font-medium">Métodos de notificación</h2>
          </div>
          <div className="divide-y">
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Correo electrónico</p>
                <p className="text-sm text-gray-500">Recibir notificaciones por email</p>
              </div>
              <Switch checked={settings.email} onCheckedChange={() => handleToggle("email")} />
            </div>
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Notificaciones push</p>
                <p className="text-sm text-gray-500">Recibir notificaciones en el dispositivo</p>
              </div>
              <Switch checked={settings.push} onCheckedChange={() => handleToggle("push")} />
            </div>
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Sonido</p>
                <p className="text-sm text-gray-500">Reproducir sonido con las notificaciones</p>
              </div>
              <Switch checked={settings.sound} onCheckedChange={() => handleToggle("sound")} />
            </div>
            <div className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium">Vibración</p>
                <p className="text-sm text-gray-500">Vibrar con las notificaciones</p>
              </div>
              <Switch checked={settings.vibration} onCheckedChange={() => handleToggle("vibration")} />
            </div>
          </div>
        </div>

        <div className="mt-6 px-4">
          <Button
            className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
            onClick={() => {
              toast({
                title: "Configuración guardada",
                description: "Tus preferencias de notificaciones han sido actualizadas",
                duration: 2000,
              })
            }}
          >
            Guardar preferencias
          </Button>
        </div>
      </main>

      <BottomNavigation activeItem="home" />
    </div>
  )
}
