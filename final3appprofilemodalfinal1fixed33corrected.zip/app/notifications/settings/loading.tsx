import { Skeleton } from "@/components/ui/skeleton"

export default function NotificationSettingsLoading() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center p-4">
          <Skeleton className="h-10 w-10 rounded-full mr-2" />
          <Skeleton className="h-6 w-64" />
        </div>
      </header>

      <main className="flex-1 container pb-16">
        <div className="bg-white rounded-lg shadow-sm mt-4">
          <div className="p-4 border-b">
            <Skeleton className="h-5 w-40" />
          </div>
          <div className="divide-y">
            {Array(6)
              .fill(0)
              .map((_, index) => (
                <div key={index} className="flex items-center justify-between p-4">
                  <div className="w-3/4">
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-48" />
                  </div>
                  <Skeleton className="h-6 w-12 rounded-full" />
                </div>
              ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm mt-4">
          <div className="p-4 border-b">
            <Skeleton className="h-5 w-48" />
          </div>
          <div className="divide-y">
            {Array(4)
              .fill(0)
              .map((_, index) => (
                <div key={index} className="flex items-center justify-between p-4">
                  <div className="w-3/4">
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-48" />
                  </div>
                  <Skeleton className="h-6 w-12 rounded-full" />
                </div>
              ))}
          </div>
        </div>

        <div className="mt-6 px-4">
          <Skeleton className="h-10 w-full rounded-full" />
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t">
        <div className="max-w-md mx-auto flex justify-between items-center px-4 py-2">
          {Array(5)
            .fill(0)
            .map((_, index) => (
              <Skeleton key={index} className="h-14 w-14" />
            ))}
        </div>
      </div>
    </div>
  )
}
