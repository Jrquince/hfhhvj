import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"
import Link from "next/link"

export default function ValoracionEnviada() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4">
      <div className="bg-white rounded-xl p-6 shadow-sm max-w-md w-full text-center">
        <div className="flex justify-center mb-4">
          <div className="bg-green-100 p-3 rounded-full">
            <CheckCircle className="h-12 w-12 text-green-600" />
          </div>
        </div>

        <h1 className="text-2xl font-bold mb-2">¡Valoración enviada!</h1>
        <p className="text-gray-600 mb-6">
          Gracias por tu valoración. Tu opinión nos ayuda a mejorar la calidad de los servicios en la plataforma.
        </p>

        <div className="space-y-3">
          <Link href="/chats">
            <Button className="w-full bg-yellow-500 hover:bg-yellow-600">Volver a chats</Button>
          </Link>
          <Link href="/">
            <Button variant="outline" className="w-full">
              Ir al inicio
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
