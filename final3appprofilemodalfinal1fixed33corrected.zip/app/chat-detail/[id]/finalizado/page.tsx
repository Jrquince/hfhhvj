"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, CreditCard, X } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { getAvatarByUserId } from "@/lib/avatar-utils"
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Datos de ejemplo para el servicio finalizado
const serviceData = {
  id: "1",
  user: {
    id: "user123",
    userId: 1,
    name: "María García",
    verified: true,
  },
  service: {
    title: "Limpieza profesional",
    date: "12 de mayo, 2025",
    time: "10:00 - 12:30",
    price: 37.5,
  },
}

export default function ServiceCompleted() {
  const [paymentOpen, setPaymentOpen] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "processing" | "success">("idle")

  // Obtener el avatar del usuario
  const userAvatar = getAvatarByUserId(serviceData.user.userId)

  const handlePayment = () => {
    setPaymentStatus("processing")
    // Simulate payment processing
    setTimeout(() => {
      setPaymentStatus("success")
      // Close dialog after showing success for a moment
      setTimeout(() => {
        setPaymentOpen(false)
        setPaymentStatus("idle")
      }, 2000)
    }, 1500)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-background">
      <main className="flex-1 container p-4 flex flex-col items-center justify-center">
        <div className="w-full max-w-md mx-auto text-center">
          <div className="flex justify-center mb-6">
            <div className="rounded-full bg-teal-100 p-4 dark:bg-teal-900">
              <CheckCircle className="h-16 w-16 text-teal-600 dark:text-teal-400" />
            </div>
          </div>

          <h1 className="text-2xl font-bold mb-2">¡Servicio finalizado!</h1>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            El servicio ha sido completado con éxito. ¿Qué te ha parecido?
          </p>

          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex flex-col items-center mb-4">
                <Avatar className="h-20 w-20 mb-3 rounded-full overflow-hidden">
                  <Image
                    src={userAvatar || "/placeholder.svg"}
                    alt={serviceData.user.name}
                    width={80}
                    height={80}
                    className="object-cover"
                  />
                </Avatar>
                <div className="text-center">
                  <div className="flex items-center justify-center">
                    <p className="font-semibold text-lg">{serviceData.user.name}</p>
                    {serviceData.user.verified && (
                      <Badge
                        variant="outline"
                        className="ml-2 bg-blue-50 text-blue-600 border-blue-200 dark:bg-blue-900 dark:text-blue-300 dark:border-blue-800"
                      >
                        Verificado
                      </Badge>
                    )}
                  </div>
                  <p className="text-gray-600 dark:text-gray-300">{serviceData.service.title}</p>
                </div>
              </div>

              <div className="border-t border-b py-4 my-4">
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600 dark:text-gray-300">Fecha:</span>
                  <span className="font-medium">{serviceData.service.date}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600 dark:text-gray-300">Horario:</span>
                  <span className="font-medium">{serviceData.service.time}</span>
                </div>
                <div className="flex justify-between mb-4">
                  <span className="text-gray-600 dark:text-gray-300">Importe total:</span>
                  <span className="font-bold text-yellow-600 dark:text-yellow-500">{serviceData.service.price}€</span>
                </div>

                {/* Nuevo CTA de pago */}
                <Button
                  onClick={() => setPaymentOpen(true)}
                  className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white"
                >
                  <CreditCard className="mr-2 h-4 w-4" /> Pagar ahora
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            <Link href={`/chat-detail/${serviceData.id}/valorar`} className="w-full">
              <Button className="w-full bg-yellow-500 hover:bg-yellow-600">Valorar servicio</Button>
            </Link>
            <Link href="/chats" className="w-full">
              <Button variant="outline" className="w-full">
                Volver a mis chats
              </Button>
            </Link>
          </div>
        </div>
      </main>

      {/* Modal de pago */}
      <Dialog open={paymentOpen} onOpenChange={setPaymentOpen}>
        <DialogContent className="sm:max-w-md p-0 overflow-hidden border-none shadow-xl">
          <div className="relative">
            <button
              onClick={() => setPaymentOpen(false)}
              className="absolute right-4 top-4 text-gray-400 hover:text-gray-500 z-10 p-1 bg-white dark:bg-gray-800 rounded-full shadow-sm"
              aria-label="Cerrar"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="p-6">
              <DialogTitle className="text-xl mb-1">Realizar pago</DialogTitle>
              <DialogDescription className="mb-4">Pago por servicio de {serviceData.service.title}</DialogDescription>

              {paymentStatus === "idle" && (
                <div className="space-y-4">
                  <div className="rounded-lg p-4 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600 dark:text-gray-300">Servicio:</span>
                      <span>{serviceData.service.title}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600 dark:text-gray-300">Fecha:</span>
                      <span>{serviceData.service.date}</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span>Total a pagar:</span>
                      <span className="text-yellow-600 dark:text-yellow-500">{serviceData.service.price}€</span>
                    </div>
                  </div>

                  <Tabs defaultValue="card" onValueChange={setPaymentMethod}>
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="card">Tarjeta</TabsTrigger>
                      <TabsTrigger value="paypal">PayPal</TabsTrigger>
                      <TabsTrigger value="bizum">Bizum</TabsTrigger>
                    </TabsList>

                    <TabsContent value="card" className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="cardNumber">Número de tarjeta</Label>
                        <Input id="cardNumber" placeholder="1234 5678 9012 3456" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiry">Fecha de caducidad</Label>
                          <Input id="expiry" placeholder="MM/AA" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cvc">CVC</Label>
                          <Input id="cvc" placeholder="123" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="name">Nombre en la tarjeta</Label>
                        <Input id="name" placeholder="Nombre completo" />
                      </div>
                    </TabsContent>

                    <TabsContent value="paypal" className="py-4">
                      <div className="text-center">
                        <p className="mb-4">Serás redirigido a PayPal para completar el pago.</p>
                        <Image
                          src="/placeholder.svg?height=60&width=120"
                          alt="PayPal"
                          width={120}
                          height={60}
                          className="mx-auto mb-4"
                        />
                      </div>
                    </TabsContent>

                    <TabsContent value="bizum" className="py-4">
                      <div className="text-center">
                        <p className="mb-4">Introduce tu número de teléfono para pagar con Bizum</p>
                        <Input placeholder="600 123 456" className="max-w-xs mx-auto mb-4" />
                      </div>
                    </TabsContent>
                  </Tabs>

                  <div className="pt-4 flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setPaymentOpen(false)}>
                      Cancelar
                    </Button>
                    <Button
                      onClick={handlePayment}
                      className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white"
                    >
                      Pagar {serviceData.service.price}€
                    </Button>
                  </div>
                </div>
              )}

              {paymentStatus === "processing" && (
                <div className="py-8 text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-600 mx-auto mb-4"></div>
                  <p className="text-lg">Procesando pago...</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Por favor, no cierres esta ventana</p>
                </div>
              )}

              {paymentStatus === "success" && (
                <div className="py-8 text-center">
                  <div className="rounded-full bg-green-100 dark:bg-green-900 p-3 mx-auto mb-4 w-16 h-16 flex items-center justify-center">
                    <CheckCircle className="h-10 w-10 text-green-600 dark:text-green-400" />
                  </div>
                  <p className="text-lg font-medium text-green-600 dark:text-green-400 mb-2">¡Pago completado!</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Gracias por tu pago. Recibirás un recibo por email.
                  </p>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
