"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import Link from "next/link"
import Image from "next/image"
import { getAvatarByUserId } from "@/lib/avatar-utils"

export default function ValorarPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [rating, setRating] = useState(0)
  const [comment, setComment] = useState("")
  const [hoveredRating, setHoveredRating] = useState(0)

  // Determinar qué perfil mostrar basado en el ID
  let userName = "Usuario"
  let userId = 1 // Default to ID 1 to match the finalizado page

  switch (params.id) {
    case "1":
      userId = 1 // Using ID 1 to match the finalizado page
      userName = "María García"
      break
    case "2":
      userId = 2
      userName = "Carlos Martínez"
      break
    case "3":
      userId = 3
      userName = "Ana Rodríguez"
      break
    case "4":
      userId = 4
      userName = "Miguel Sánchez"
      break
    case "5":
      userId = 5
      userName = "Elena Gómez"
      break
    case "6":
      userId = 6
      userName = "David Torres"
      break
    case "7":
      userId = 7
      userName = "Javier López"
      break
    default:
      userId = 8
      userName = "Usuario"
  }

  // Get avatar using the same method as in finalizado page
  const profileImage = getAvatarByUserId(userId)

  const handleSubmit = () => {
    router.push(`/chat-detail/${params.id}/valoracion-enviada`)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-2 flex items-center sticky top-0 z-10">
        <Link href={`/chat-detail/${params.id}`}>
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-lg font-medium">Valorar servicio</h1>
      </header>

      <div className="flex-1 p-4">
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="flex items-center space-x-4 mb-4">
            <Avatar className="h-16 w-16 border border-gray-200">
              <Image
                src={profileImage || "/placeholder.svg"}
                alt={userName}
                width={64}
                height={64}
                className="object-cover"
              />
              <AvatarFallback>{userName.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-lg font-medium">{userName}</h2>
              <p className="text-sm text-gray-500">Servicio finalizado</p>
            </div>
          </div>

          <div className="border-t border-gray-100 pt-4">
            <p className="text-sm text-gray-600 mb-2">Detalles del servicio:</p>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Reparación de tubería</li>
              <li>• Fecha: 15/05/2023</li>
              <li>• Duración: 2 horas</li>
            </ul>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <h3 className="font-medium mb-4">¿Cómo valorarías el servicio?</h3>
          <div className="flex justify-center mb-6">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                className="mx-1 focus:outline-none"
              >
                <Star
                  className={`h-8 w-8 ${
                    star <= (hoveredRating || rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                  }`}
                />
              </button>
            ))}
          </div>
          <p className="text-center text-sm text-gray-500 mb-4">
            {rating === 1
              ? "Muy insatisfecho"
              : rating === 2
                ? "Insatisfecho"
                : rating === 3
                  ? "Neutral"
                  : rating === 4
                    ? "Satisfecho"
                    : rating === 5
                      ? "Muy satisfecho"
                      : "Selecciona una puntuación"}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <h3 className="font-medium mb-4">Deja un comentario (opcional)</h3>
          <Textarea
            placeholder="Escribe tu opinión sobre el servicio..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="min-h-[100px] mb-2"
          />
        </div>
      </div>

      <div className="p-4 bg-white border-t border-gray-200 sticky bottom-0">
        <Button
          onClick={handleSubmit}
          disabled={rating === 0}
          className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
        >
          Enviar valoración
        </Button>
      </div>
    </div>
  )
}
