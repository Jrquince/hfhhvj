"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Send, Paperclip, ImageIcon, Phone, Video, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { getAvatarByUserId } from "@/lib/avatar-utils"
import { toast } from "sonner"
import { ChatOptionsDialog } from "@/components/chat-options-dialog"

// Respuestas automáticas del bot
const botResponses = [
  "¡Claro! Estoy disponible para ayudarte con eso.",
  "Gracias por tu mensaje. Te responderé lo antes posible.",
  "Entiendo lo que necesitas. ¿Podemos concretar una fecha?",
  "Perfecto, me parece bien. ¿Necesitas algo más?",
  "Estoy de acuerdo con tu propuesta.",
  "Disculpa la demora. He estado muy ocupado últimamente.",
  "¿Podrías darme más detalles sobre lo que necesitas?",
  "Eso suena interesante. Cuéntame más.",
  "Puedo hacerlo por 50€. ¿Te parece bien?",
  "Estaré disponible a partir del lunes. ¿Te viene bien?",
  "Necesitaría ver el espacio antes de darte un presupuesto exacto.",
  "¿Has considerado también renovar la instalación eléctrica?",
  "Tengo experiencia en ese tipo de trabajos, puedes estar tranquilo.",
  "Te enviaré algunas fotos de trabajos similares que he realizado.",
  "¿Prefieres que nos comuniquemos por llamada para concretar los detalles?",
]

export default function ChatDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { id } = params

  // Actualizar la función para usar los nuevos avatares en el chat
  // Determinar qué perfil mostrar basado en el ID
  const profileImage = getAvatarByUserId(Number.parseInt(id))
  let userName = "Usuario"

  switch (id) {
    case "1":
      userName = "María García"
      break
    case "2":
      userName = "Carlos Martínez"
      break
    case "3":
      userName = "Ana Rodríguez"
      break
    case "4":
      userName = "Miguel Sánchez"
      break
    case "5":
      userName = "Elena Gómez"
      break
    case "6":
      userName = "David Torres"
      break
    case "7":
      userName = "Sofía López"
      break
    default:
      userName = "Usuario"
  }
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<any[]>([])
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [showFinishButton, setShowFinishButton] = useState(true)
  const [showOptionsMenu, setShowOptionsMenu] = useState(false)

  // Datos del usuario con el que se está chateando
  const chatUser = {
    id: params.id,
    name: userName,
    image: profileImage,
    status: "En línea",
    lastSeen: "Hace 5 minutos",
    profession: "Fontanero profesional",
    rating: 4.8,
  }

  // Cargar mensajes iniciales
  useEffect(() => {
    const initialMessages = [
      {
        id: 1,
        sender: "other",
        text: "Hola, he visto tu anuncio sobre la reparación de la tubería. ¿Podrías darme más detalles?",
        time: "10:30",
        read: true,
      },
      {
        id: 2,
        sender: "me",
        text: "¡Hola! Claro, tengo una fuga en la tubería del baño que está causando humedad en la pared.",
        time: "10:32",
        read: true,
      },
      {
        id: 3,
        sender: "other",
        text: "Entiendo. ¿Hace cuánto tiempo que notaste la fuga?",
        time: "10:33",
        read: true,
      },
      {
        id: 4,
        sender: "me",
        text: "Hace aproximadamente una semana. Al principio era apenas visible, pero ahora la mancha de humedad es más grande.",
        time: "10:35",
        read: true,
      },
      {
        id: 5,
        sender: "other",
        text: "Vale, podría ser un problema en la junta o en la propia tubería. ¿Estarías disponible mañana para que pase a revisarlo?",
        time: "10:36",
        read: true,
      },
    ]

    setMessages(initialMessages)
  }, [])

  // Scroll al último mensaje
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Enviar mensaje
  const sendMessage = () => {
    if (message.trim() === "") return

    const newMessage = {
      id: messages.length + 1,
      sender: "me",
      text: message,
      time: new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }),
      read: false,
    }

    setMessages([...messages, newMessage])
    setMessage("")

    // Simular respuesta automática
    setIsTyping(true)
    setTimeout(
      () => {
        const randomResponse = botResponses[Math.floor(Math.random() * botResponses.length)]
        const botMessage = {
          id: messages.length + 2,
          sender: "other",
          text: randomResponse,
          time: new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }),
          read: false,
        }
        setMessages((prev) => [...prev, botMessage])
        setIsTyping(false)
      },
      1500 + Math.random() * 2000,
    ) // Tiempo aleatorio entre 1.5 y 3.5 segundos
  }

  // Manejar tecla Enter
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  // Finalizar chat
  const handleFinishChat = () => {
    router.push(`/chat-detail/${params.id}/finalizado`)
  }

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Header - Estilo Instagram */}
      <header className="bg-white border-b border-gray-100 px-4 py-3 flex items-center justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center">
          <Link href="/chats">
            <Button variant="ghost" size="icon" className="h-8 w-8 mr-2 rounded-full hover:bg-gray-100">
              <ArrowLeft className="h-5 w-5 text-gray-700" />
            </Button>
          </Link>
          <div className="flex items-center">
            <div className="relative">
              <div className="h-10 w-10 rounded-full overflow-hidden border-2 border-gray-100">
                <img
                  src={chatUser.image || "/placeholder.svg?height=40&width=40"}
                  alt={chatUser.name}
                  className="h-full w-full object-cover"
                />
              </div>
              {chatUser.status === "En línea" && (
                <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-white"></div>
              )}
            </div>
            <div className="ml-3 flex flex-col">
              <h2 className="text-sm font-semibold">{chatUser.name}</h2>
              <p className="text-xs text-gray-500">
                {chatUser.status === "En línea" ? "Activo ahora" : chatUser.status}
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-full hover:bg-gray-100"
              onClick={() => {
                // Iniciar llamada
                toast({
                  title: "Llamando",
                  description: `Iniciando llamada con ${chatUser.name}`,
                  duration: 2000,
                })
              }}
            >
              <Phone className="h-5 w-5 text-gray-700" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-full hover:bg-gray-100"
              onClick={() => {
                // Iniciar videollamada
                toast({
                  title: "Videollamada",
                  description: `Iniciando videollamada con ${chatUser.name}`,
                  duration: 2000,
                })
              }}
            >
              <Video className="h-5 w-5 text-gray-700" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-full hover:bg-gray-100"
              onClick={() => {
                // Abrir el menú de opciones del chat
                setShowOptionsMenu(true)
              }}
            >
              <Info className="h-5 w-5 text-gray-700" />
            </Button>
          </div>
          {showFinishButton && (
            <Button
              variant="outline"
              size="sm"
              className="text-xs rounded-full px-3 py-1 h-7 mt-2 border-gray-300 text-gray-700 hover:bg-gray-100"
              onClick={handleFinishChat}
            >
              Finalizar servicio
            </Button>
          )}
        </div>
      </header>

      {/* Chat messages - Estilo Instagram con color amarillo anaranjado */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-white">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"} mb-1`}>
            {msg.sender === "other" && (
              <div className="h-8 w-8 rounded-full overflow-hidden mr-2 mt-1 flex-shrink-0">
                <img
                  src={chatUser.image || "/placeholder.svg?height=32&width=32"}
                  alt={chatUser.name}
                  className="h-full w-full object-cover"
                />
              </div>
            )}
            <div
              className={`max-w-[75%] px-4 py-2 ${
                msg.sender === "me"
                  ? "bg-amber-500 text-white rounded-3xl rounded-tr-lg"
                  : "bg-gray-100 text-black rounded-3xl rounded-tl-lg"
              }`}
            >
              <p className="text-sm">{msg.text}</p>
              <div
                className={`text-[10px] mt-1 text-right ${msg.sender === "me" ? "text-amber-100" : "text-gray-500"}`}
              >
                {msg.time}
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="h-8 w-8 rounded-full overflow-hidden mr-2 mt-1 flex-shrink-0">
              <img
                src={chatUser.image || "/placeholder.svg?height=32&width=32"}
                alt={chatUser.name}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="bg-gray-100 rounded-3xl rounded-tl-lg px-4 py-2">
              <div className="flex space-x-1 h-5 items-center">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-75"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150"></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message input - Estilo Instagram */}
      <div className="bg-white border-t border-gray-100 p-3 sticky bottom-0">
        <div className="flex items-center bg-gray-100 rounded-full p-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 rounded-full hover:bg-gray-200"
            onClick={() => {
              // Adjuntar archivo
              const input = document.createElement("input")
              input.type = "file"
              input.onchange = (e) => {
                toast({
                  title: "Archivo adjuntado",
                  description: "El archivo se ha adjuntado correctamente",
                  duration: 2000,
                })
              }
              input.click()
            }}
          >
            <Paperclip className="h-5 w-5 text-gray-500" />
          </Button>
          <Input
            placeholder="Mensaje..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent border-0 focus-visible:ring-0 focus-visible:ring-offset-0 text-sm px-2"
          />
          {message.trim() === "" ? (
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-full hover:bg-gray-200"
              onClick={() => {
                // Adjuntar imagen
                const input = document.createElement("input")
                input.type = "file"
                input.accept = "image/*"
                input.onchange = (e) => {
                  toast({
                    title: "Imagen adjuntada",
                    description: "La imagen se ha adjuntada correctamente",
                    duration: 2000,
                  })
                }
                input.click()
              }}
            >
              <ImageIcon className="h-5 w-5 text-gray-500" />
            </Button>
          ) : (
            <Button
              onClick={sendMessage}
              className="rounded-full bg-amber-500 hover:bg-amber-600 h-8 w-8 p-0 flex items-center justify-center"
            >
              <Send className="h-4 w-4 text-white" />
            </Button>
          )}
        </div>
      </div>
      {/* Menú de opciones del chat */}
      {showOptionsMenu && <ChatOptionsDialog username={chatUser.name} onClose={() => setShowOptionsMenu(false)} />}
    </div>
  )
}
