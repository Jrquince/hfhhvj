"use client"

import { ArrowLeft, Send, Paperclip, Smile } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import Image from "next/image"
import { useState } from "react"

export default function ChatDetailPage() {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState([
    {
      sender: "user",
      text: "Hola, he visto tu anuncio y parece perfecto. Tengo experiencia con mudanzas y podría estar disponible. ¿A qué hora necesitas que vaya?",
      time: "10:30",
      avatar: "/placeholder.svg?height=32&width=32&text=TÚ",
    },
    {
      sender: "other",
      text: "¿Podrías pasarte a ideas en viernes sobre las 15h? ¿Te viene bien?",
      time: "10:32",
      avatar: "/placeholder.svg?height=32&width=32&text=MR",
    },
    {
      sender: "user",
      text: "Hola, he visto tu anuncio y parece perfecto. Tengo experiencia con mudanzas y podría estar disponible. ¿A qué hora necesitas que vaya?",
      time: "10:35",
      avatar: "/placeholder.svg?height=32&width=32&text=TÚ",
    },
    {
      sender: "other",
      text: "¿Podrías pasarte a ideas en viernes sobre las 15h? ¿Te viene bien?",
      time: "10:40",
      avatar: "/placeholder.svg?height=32&width=32&text=MR",
    },
    {
      sender: "user",
      text: "Hola, he visto tu anuncio y parece perfecto. Tengo experiencia con mudanzas y podría estar disponible. ¿A qué hora necesitas que vaya?",
      time: "10:45",
      avatar: "/placeholder.svg?height=32&width=32&text=TÚ",
    },
    {
      sender: "other",
      text: "¿Podrías pasarte a ideas en viernes sobre las 15h? ¿Te viene bien?",
      time: "10:50",
      avatar: "/placeholder.svg?height=32&width=32&text=MR",
    },
  ])

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage = {
        sender: "user",
        text: message,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        avatar: "/placeholder.svg?height=32&width=32&text=TÚ",
      }
      setMessages([...messages, newMessage])
      setMessage("")
    }
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-4 flex items-center justify-between border-b">
        <div className="flex items-center">
          <Link href="/chats">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <Avatar className="h-10 w-10 border ml-2">
            <Image
              src="/placeholder.svg?height=40&width=40&text=MR"
              alt="User avatar"
              width={40}
              height={40}
              className="rounded-full"
            />
          </Avatar>
          <div className="ml-3">
            <h3 className="font-medium text-sm">María Ruiz</h3>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
              <span className="text-xs text-gray-500">En línea</span>
            </div>
          </div>
        </div>
        <div className="flex items-center">
          <Button
            variant="outline"
            size="sm"
            className="rounded-full text-xs mr-2 border-red-300 text-red-500 hover:bg-red-50"
          >
            Finalizar
          </Button>
          <div className="flex">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M15.05 5A5 5 0 0 1 19 8.95M15.05 1A9 9 0 0 1 23 8.94m-1 7.98v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
              </svg>
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 3H3C1.89543 3 1 3.89543 1 5V19C1 20.1046 1.89543 21 3 21H21C22.1046 21 23 20.1046 23 19V5C23 3.89543 22.1046 3 21 3Z" />
                <path d="M9.5 9C10.3284 9 11 8.32843 11 7.5C11 6.67157 10.3284 6 9.5 6C8.67157 6 8 6.67157 8 7.5C8 8.32843 8.67157 9 9.5 9Z" />
                <path d="M13.5833 13.5L10.5 10.5L3.5 17.5" />
                <path d="M13.5 10.5L20.5 17.5" />
              </svg>
            </Button>
          </div>
        </div>
      </div>

      {/* Chat messages */}
      <div className="flex-1 p-4 overflow-auto bg-gray-50">
        <div className="space-y-4">
          {messages.map((message, index) => (
            <div key={index} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
              {message.sender === "other" && (
                <Avatar className="h-8 w-8 border mr-2 self-end">
                  <Image
                    src={message.avatar || "/placeholder.svg"}
                    alt="User avatar"
                    width={32}
                    height={32}
                    className="rounded-full"
                  />
                </Avatar>
              )}
              <div className="max-w-[70%]">
                <div
                  className={`p-3 rounded-lg ${
                    message.sender === "user"
                      ? "bg-yellow-500 text-white rounded-br-none"
                      : "bg-white border rounded-bl-none"
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                </div>
                <p className="text-xs text-gray-500 mt-1">{message.time}</p>
              </div>
              {message.sender === "user" && (
                <Avatar className="h-8 w-8 border ml-2 self-end">
                  <Image
                    src={message.avatar || "/placeholder.svg"}
                    alt="User avatar"
                    width={32}
                    height={32}
                    className="rounded-full"
                  />
                </Avatar>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Message input */}
      <div className="p-3 border-t flex items-center">
        <Button variant="ghost" size="icon" className="h-10 w-10 rounded-full">
          <Paperclip className="h-5 w-5 text-gray-500" />
        </Button>
        <div className="flex-1 mx-2 relative">
          <Input
            placeholder="Escribe algo..."
            className="pl-3 pr-10 py-2 rounded-full border-gray-200"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleSendMessage()
              }
            }}
          />
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 absolute right-1 top-1/2 transform -translate-y-1/2 rounded-full"
          >
            <Smile className="h-5 w-5 text-gray-500" />
          </Button>
        </div>
        <Button
          size="icon"
          className="h-10 w-10 rounded-full bg-yellow-500 hover:bg-yellow-600"
          onClick={handleSendMessage}
        >
          <Send className="h-5 w-5 text-white" />
        </Button>
      </div>
    </div>
  )
}
