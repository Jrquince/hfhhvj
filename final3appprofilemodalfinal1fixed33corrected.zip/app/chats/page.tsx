"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Search, Plus, Bell, Filter, ArrowLeft } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getAvatarByUserId } from "@/lib/avatar-utils"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"
import { FilterModal } from "@/components/filter-modal"

export default function ChatsPage() {
  const [activeTab, setActiveTab] = useState("todos")
  const [searchQuery, setSearchQuery] = useState("")
  const [isNewChatOpen, setIsNewChatOpen] = useState(false)
  const [showFilterModal, setShowFilterModal] = useState(false)

  // Datos de ejemplo para chats
  const chats = [
    {
      id: 1,
      userId: 13, // Using the man in dark suit
      name: "María García",
      lastMessage: "Perfecto, estaré esperando. ¡Gracias!",
      time: "12:30",
      unread: 2,
      status: "pendiente",
    },
    {
      id: 2,
      userId: 11, // Using the young man with wavy brown hair
      name: "Javier López",
      lastMessage: "¿Podrías venir un poco antes?",
      time: "Ayer",
      unread: 0,
      status: "activo",
    },
    {
      id: 3,
      userId: 10, // Using the woman with curly dark hair
      name: "Laura Martínez",
      lastMessage: "El trabajo quedó excelente, muchas gracias",
      time: "Ayer",
      unread: 0,
      status: "finalizado",
    },
    {
      id: 4,
      userId: 14, // Using the young man with short dark hair
      name: "Carlos Rodríguez",
      lastMessage: "¿Cuánto cobrarías por un trabajo similar?",
      time: "Lun",
      unread: 0,
      status: "activo",
    },
    {
      id: 5,
      userId: 17, // Using the woman with brown hair outdoors
      name: "Ana Sánchez",
      lastMessage: "Necesito ayuda con una instalación",
      time: "Dom",
      unread: 0,
      status: "pendiente",
    },
    {
      id: 6,
      userId: 19, // Using the young man with blonde hair outdoors
      name: "Miguel Fernández",
      lastMessage: "¿Tienes disponibilidad este fin de semana?",
      time: "Sáb",
      unread: 0,
      status: "activo",
    },
    {
      id: 7,
      userId: 15, // Using the woman with blonde bob haircut
      name: "Elena Díaz",
      lastMessage: "Gracias por tu ayuda, todo funciona perfectamente",
      time: "Vie",
      unread: 0,
      status: "finalizado",
    },
    {
      id: 8,
      userId: 18, // Using the man with dark hair and beard in suit
      name: "Pablo Ruiz",
      lastMessage: "¿Podrías enviarme un presupuesto?",
      time: "Jue",
      unread: 0,
      status: "pendiente",
    },
    {
      id: 9,
      userId: 16, // Using the woman with black hair
      name: "Lucía Gómez",
      lastMessage: "¿Cuándo podrías venir a revisar la avería?",
      time: "Mié",
      unread: 0,
      status: "activo",
    },
    {
      id: 10,
      userId: 9, // Using the smiling Black man
      name: "Daniel Torres",
      lastMessage: "El presupuesto me parece bien, adelante",
      time: "Mar",
      unread: 0,
      status: "pendiente",
    },
    {
      id: 11,
      userId: 3, // Using the woman with curly red hair
      name: "Carmen Vega",
      lastMessage: "¿Podrías traer también material para la otra habitación?",
      time: "Mar",
      unread: 0,
      status: "activo",
    },
    {
      id: 12,
      userId: 2, // Using the smiling man in dark suit
      name: "Roberto Moreno",
      lastMessage: "Muchas gracias por el trabajo, ha quedado genial",
      time: "Lun",
      unread: 0,
      status: "finalizado",
    },
  ]

  // Usuarios disponibles para nuevo chat
  const availableUsers = [
    { id: 21, userId: 1, name: "Alejandro Vázquez", profession: "Electricista" },
    { id: 22, userId: 5, name: "Isabel Moreno", profession: "Fontanera" },
    { id: 23, userId: 6, name: "David Serrano", profession: "Pintor" },
    { id: 24, userId: 7, name: "Sofía Núñez", profession: "Carpintera" },
    { id: 25, userId: 4, name: "Raúl Iglesias", profession: "Jardinero" },
  ]

  // Filtrar chats según la pestaña activa
  const filteredChats = chats.filter((chat) => {
    if (activeTab === "todos") return true
    if (activeTab === "pendientes") return chat.status === "pendiente"
    if (activeTab === "activos") return chat.status === "activo"
    if (activeTab === "finalizados") return chat.status === "finalizado"
    return true
  })

  // Filtrar por búsqueda
  const searchedChats = filteredChats.filter((chat) => chat.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="icon" className="mr-2">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-lg font-semibold">Mensajes</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Link href="/notifications">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
              </Button>
            </Link>
            <Button variant="ghost" size="icon" onClick={() => setShowFilterModal(true)}>
              <Filter className="h-5 w-5" />
            </Button>
          </div>
        </div>
        <div className="container px-4 pb-3">
          <div className="relative">
            <Search
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4"
              onClick={() => {
                // Implementar búsqueda
                if (searchQuery.trim()) {
                  toast({
                    title: "Buscando",
                    description: `Resultados para "${searchQuery}"`,
                    duration: 2000,
                  })
                }
              }}
            />
            <Input
              className="pl-9 bg-gray-100 border-0"
              placeholder="Buscar en mensajes"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </header>

      <main className="flex-1 container pb-16">
        <Tabs defaultValue="todos" value={activeTab} onValueChange={setActiveTab}>
          <div className="overflow-x-auto">
            <TabsList className="w-full justify-start p-0 h-auto bg-transparent border-b">
              <TabsTrigger
                value="todos"
                className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-yellow-500"
                onClick={() => {
                  // Cargar todos los chats
                }}
              >
                Todos
              </TabsTrigger>
              <TabsTrigger
                value="pendientes"
                className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-yellow-500"
              >
                Pendientes
              </TabsTrigger>
              <TabsTrigger
                value="activos"
                className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-yellow-500"
              >
                Activos
              </TabsTrigger>
              <TabsTrigger
                value="finalizados"
                className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-yellow-500"
              >
                Finalizados
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="todos" className="mt-0">
            <div className="divide-y">
              {searchedChats.length > 0 ? (
                searchedChats.map((chat) => (
                  <Link href={`/chat-detail/${chat.id}`} key={chat.id}>
                    <div className="flex items-center py-3 px-1 hover:bg-gray-50">
                      <div className="relative">
                        <div className="w-12 h-12 rounded-full overflow-hidden">
                          <Image
                            src={getAvatarByUserId(chat.userId) || "/placeholder.svg"}
                            alt={chat.name}
                            width={48}
                            height={48}
                            className="object-cover w-full h-full"
                          />
                        </div>
                        {chat.status === "activo" && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between">
                          <span className="font-medium">{chat.name}</span>
                          <span className="text-xs text-gray-500">{chat.time}</span>
                        </div>
                        <div className="flex justify-between mt-1">
                          <p className="text-sm text-gray-600 truncate max-w-[200px]">{chat.lastMessage}</p>
                          {chat.unread > 0 && (
                            <span className="bg-yellow-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                              {chat.unread}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="py-10 text-center">
                  <p className="text-gray-500">No se encontraron mensajes</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="pendientes" className="mt-0">
            <div className="divide-y">
              {searchedChats.length > 0 ? (
                searchedChats.map((chat) => (
                  <Link href={`/chat-detail/${chat.id}`} key={chat.id}>
                    <div className="flex items-center py-3 px-1 hover:bg-gray-50">
                      <div className="relative">
                        <div className="w-12 h-12 rounded-full overflow-hidden">
                          <Image
                            src={getAvatarByUserId(chat.userId) || "/placeholder.svg"}
                            alt={chat.name}
                            width={48}
                            height={48}
                            className="object-cover w-full h-full"
                          />
                        </div>
                        {chat.status === "activo" && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between">
                          <span className="font-medium">{chat.name}</span>
                          <span className="text-xs text-gray-500">{chat.time}</span>
                        </div>
                        <div className="flex justify-between mt-1">
                          <p className="text-sm text-gray-600 truncate max-w-[200px]">{chat.lastMessage}</p>
                          {chat.unread > 0 && (
                            <span className="bg-yellow-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                              {chat.unread}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="py-10 text-center">
                  <p className="text-gray-500">No se encontraron mensajes pendientes</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="activos" className="mt-0">
            <div className="divide-y">
              {searchedChats.length > 0 ? (
                searchedChats.map((chat) => (
                  <Link href={`/chat-detail/${chat.id}`} key={chat.id}>
                    <div className="flex items-center py-3 px-1 hover:bg-gray-50">
                      <div className="relative">
                        <div className="w-12 h-12 rounded-full overflow-hidden">
                          <Image
                            src={getAvatarByUserId(chat.userId) || "/placeholder.svg"}
                            alt={chat.name}
                            width={48}
                            height={48}
                            className="object-cover w-full h-full"
                          />
                        </div>
                        {chat.status === "activo" && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between">
                          <span className="font-medium">{chat.name}</span>
                          <span className="text-xs text-gray-500">{chat.time}</span>
                        </div>
                        <div className="flex justify-between mt-1">
                          <p className="text-sm text-gray-600 truncate max-w-[200px]">{chat.lastMessage}</p>
                          {chat.unread > 0 && (
                            <span className="bg-yellow-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                              {chat.unread}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="py-10 text-center">
                  <p className="text-gray-500">No se encontraron mensajes activos</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="finalizados" className="mt-0">
            <div className="divide-y">
              {searchedChats.length > 0 ? (
                searchedChats.map((chat) => (
                  <Link href={`/chat-detail/${chat.id}`} key={chat.id}>
                    <div className="flex items-center py-3 px-1 hover:bg-gray-50">
                      <div className="relative">
                        <div className="w-12 h-12 rounded-full overflow-hidden">
                          <Image
                            src={getAvatarByUserId(chat.userId) || "/placeholder.svg"}
                            alt={chat.name}
                            width={48}
                            height={48}
                            className="object-cover w-full h-full"
                          />
                        </div>
                        {chat.status === "activo" && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between">
                          <span className="font-medium">{chat.name}</span>
                          <span className="text-xs text-gray-500">{chat.time}</span>
                        </div>
                        <div className="flex justify-between mt-1">
                          <p className="text-sm text-gray-600 truncate max-w-[200px]">{chat.lastMessage}</p>
                          {chat.unread > 0 && (
                            <span className="bg-yellow-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                              {chat.unread}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="py-10 text-center">
                  <p className="text-gray-500">No se encontraron mensajes finalizados</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <div className="fixed bottom-20 right-4">
          <Button
            onClick={() => setIsNewChatOpen(true)}
            className="h-14 w-14 rounded-full bg-yellow-500 hover:bg-yellow-600"
          >
            <Plus className="h-6 w-6" />
          </Button>
        </div>
      </main>

      <Dialog open={isNewChatOpen} onOpenChange={setIsNewChatOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Nueva conversación</DialogTitle>
            <DialogDescription>Selecciona un usuario para iniciar una nueva conversación</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input className="pl-9 bg-gray-100 border-0" placeholder="Buscar usuarios" />
            </div>
            <div className="space-y-3 max-h-[300px] overflow-y-auto">
              {availableUsers.map((user) => (
                <Link href={`/chat-detail/new?user=${user.id}`} key={user.id}>
                  <div className="flex items-center py-2 px-1 hover:bg-gray-50 rounded-lg">
                    <div className="w-12 h-12 rounded-full overflow-hidden">
                      <Image
                        src={getAvatarByUserId(user.userId) || "/placeholder.svg"}
                        alt={user.name}
                        width={48}
                        height={48}
                        className="object-cover w-full h-full"
                      />
                    </div>
                    <div className="ml-3">
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-gray-500">{user.profession}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <FilterModal
        isOpen={showFilterModal}
        onClose={() => setShowFilterModal(false)}
        onApplyFilters={(filters) => {
          // Aplicar filtros a los chats
          toast({
            title: "Filtros aplicados",
            description: "Los resultados han sido actualizados",
            duration: 2000,
          })
        }}
        categories={["Todos", "Recientes", "No leídos", "Importantes"]}
      />

      {/* Eliminamos la barra de navegación en esta vista */}
    </div>
  )
}
