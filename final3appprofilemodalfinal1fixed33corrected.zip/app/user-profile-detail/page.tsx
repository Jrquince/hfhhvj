import { ArrowLeft, Star, Check, ThumbsUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ProfileImage } from "@/components/profile-image"

export default function UserProfileDetailPage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M19 21L12 16L5 21V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H17C17.5304 3 18.0391 3.21071 18.4142 3.58579C18.7893 3.96086 19 4.46957 19 5V21Z" />
          </svg>
        </Button>
      </div>

      {/* User profile */}
      <div className="px-6 pt-2 pb-6">
        <div className="flex justify-center mb-4">
          <ProfileImage profileId={3} username="RON 69" size="xl" className="border-2 border-yellow-500" />
        </div>
        <div className="text-center mb-4">
          <h1 className="font-bold text-lg">RON 69</h1>
          <div className="flex items-center justify-center">
            <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                clipRule="evenodd"
              />
            </svg>
          </div>
        </div>

        <div className="flex justify-between items-center mb-6">
          <div className="text-center">
            <p className="font-bold text-sm">23</p>
            <p className="text-xs text-gray-500">Valoraciones</p>
          </div>
          <div className="text-center">
            <p className="font-bold text-sm">5.0 ★</p>
            <div className="flex items-center text-xs text-gray-500">
              <Check className="h-3 w-3 mr-1" />
              <span>Recomendado</span>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <h2 className="font-bold text-sm mb-3">Evaluaciones</h2>
          <div className="space-y-4">
            <div className="border rounded-lg p-3">
              <div className="flex items-center mb-2">
                <ProfileImage profileId={4} username="U1" size="sm" className="border" />
                <div className="ml-2">
                  <div className="flex items-center">
                    <p className="text-sm font-medium">4.6</p>
                    <Star className="h-3 w-3 ml-1 text-yellow-400 fill-yellow-400" />
                  </div>
                </div>
              </div>
              <p className="text-xs text-gray-600 mb-2">
                "Excelente trato de compañero. Lo recomiendo. Muy profesional"
              </p>
              <p className="text-xs text-gray-600 mb-2">"Me ayudó a encontrar un piso muy recomendable y económico"</p>
              <p className="text-xs text-gray-600">
                "Un chico muy majo y muy recomendable como persona. Geniales preguntas"
              </p>
            </div>

            <div className="border rounded-lg p-3">
              <div className="flex items-center mb-2">
                <ProfileImage profileId={5} username="U2" size="sm" className="border" />
                <div className="ml-2">
                  <p className="text-xs text-gray-500">El usuario ha valorado a un profesional</p>
                </div>
              </div>
            </div>
          </div>

          <Button className="w-full rounded-full bg-yellow-500 hover:bg-yellow-600 text-white mt-4">
            Ver todas las evaluaciones
          </Button>
        </div>

        <div className="mb-6">
          <h2 className="font-bold text-sm mb-3">Insignias</h2>
          <div className="flex justify-between">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full border-2 border-gray-200 flex items-center justify-center">
                <span className="font-bold">10</span>
              </div>
              <span className="text-xs mt-1">Puntos</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full border-2 border-gray-200 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="8" />
                  <path d="M12 8v4l2 2" />
                </svg>
              </div>
              <span className="text-xs mt-1">Tiempo</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full border-2 border-gray-200 flex items-center justify-center">
                <Check className="h-6 w-6" />
              </div>
              <span className="text-xs mt-1">Verificado</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full border-2 border-gray-200 flex items-center justify-center">
                <ThumbsUp className="h-6 w-6" />
              </div>
              <span className="text-xs mt-1">Likes</span>
            </div>
          </div>
        </div>

        <div>
          <h2 className="font-bold text-sm mb-3">Ver publicaciones</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="border rounded-lg p-3">
              <div className="flex justify-center mb-2">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
                  <polyline points="9 22 9 12 15 12 15 22" />
                </svg>
              </div>
              <p className="text-xs text-center">Busco un compañero/a de piso...</p>
            </div>
            <div className="border rounded-lg p-3">
              <div className="flex justify-center mb-2">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
                  <polyline points="9 22 9 12 15 12 15 22" />
                </svg>
              </div>
              <p className="text-xs text-center">Busco un...</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
