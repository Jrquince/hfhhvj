import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

// Array of different survey questions
const surveyQuestions = [
  {
    question: "¿Qué tipo de servicio buscas con más frecuencia?",
    options: ["Limpieza del hogar", "Reparaciones", "Clases particulares", "Cuidado de mascotas"],
  },
  {
    question: "¿Cuánto estarías dispuesto a pagar por hora para un servicio de calidad?",
    options: ["Menos de 10€", "Entre 10€ y 20€", "Entre 20€ y 30€", "Más de 30€"],
  },
  {
    question: "¿Qué valoras más en un profesional?",
    options: ["Puntualidad", "Experiencia", "Precio", "Recomendaciones"],
  },
  {
    question: "¿Con qué frecuencia necesitas servicios profesionales?",
    options: ["Semanalmente", "Mensualmente", "Trimestralmente", "Ocasionalmente"],
  },
  {
    question: "¿Prefieres contratar a profesionales cerca de tu ubicación?",
    options: ["Sí, siempre", "Depende del servicio", "No es relevante", "Prefiero recomendados"],
  },
]

export default function SurveyPost() {
  // Get a random question from the array
  const randomIndex = Math.floor(Math.random() * surveyQuestions.length)
  const surveyQuestion = surveyQuestions[randomIndex]

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="flex items-center p-4 border-b bg-white">
        <Link href="/">
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-lg font-medium ml-4">Encuesta</h1>
      </div>

      <div className="flex-1 p-4">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-6">{surveyQuestion.question}</h2>

          <div className="space-y-3">
            {surveyQuestion.options.map((option, index) => (
              <div key={index} className="flex items-center border rounded-lg p-4 cursor-pointer hover:bg-gray-50">
                <div className="h-5 w-5 rounded-full border-2 border-gray-300 mr-3"></div>
                <span>{option}</span>
              </div>
            ))}
          </div>

          <div className="mt-8">
            <Button className="w-full">Enviar respuesta</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
