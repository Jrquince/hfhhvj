import { ArrowLeft, ChevronRight, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"

export default function FiltersPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="flex items-center justify-between p-4 border-b bg-white">
        <div className="flex items-center">
          <Link href="/">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-lg font-medium ml-4">Filtros avanzados</h1>
        </div>
        <Button variant="ghost" size="sm" className="text-gray-500">
          Limpiar
        </Button>
      </div>

      <div className="flex-1 p-4 space-y-6">
        {/* Categoría section */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-medium mb-2">Categoría</h2>
          <p className="text-sm text-gray-500 mb-4">Selecciona la categoría de servicios que estás buscando</p>
          <Link href="/filtros/categoria">
            <div className="flex items-center justify-between py-2 border-t">
              <span className="text-sm">Todas las categorías</span>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </div>
          </Link>
        </div>

        {/* Ubicación section */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-medium mb-2">Ubicación</h2>
          <p className="text-sm text-gray-500 mb-4">Define el área geográfica donde quieres buscar servicios</p>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium">Usar mi ubicación actual</h3>
                <p className="text-xs text-gray-500">Mostrar servicios cercanos a ti</p>
              </div>
              <Switch />
            </div>

            <div>
              <h3 className="text-sm font-medium mb-2">Radio de búsqueda</h3>
              <div className="px-2">
                <Slider defaultValue={[5]} max={20} step={1} />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-gray-500">1 km</span>
                  <span className="text-xs text-gray-500">20 km</span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t">
              <h3 className="text-sm font-medium mb-2">Buscar en otra ubicación</h3>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Introduce una dirección o ciudad"
                  className="w-full p-2 pr-8 border rounded-md text-sm"
                />
                <X className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Precio section */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-medium mb-2">Precio</h2>
          <p className="text-sm text-gray-500 mb-4">Establece un rango de precios para los servicios</p>

          <div className="px-2">
            <Slider defaultValue={[20, 80]} max={100} step={1} />
            <div className="flex justify-between mt-2">
              <div className="border rounded-md p-2 w-24">
                <span className="text-xs text-gray-500">Mínimo</span>
                <div className="flex items-center">
                  <span className="text-sm font-medium">20€</span>
                </div>
              </div>
              <div className="border rounded-md p-2 w-24">
                <span className="text-xs text-gray-500">Máximo</span>
                <div className="flex items-center">
                  <span className="text-sm font-medium">80€</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Valoraciones section */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-medium mb-2">Valoraciones</h2>
          <p className="text-sm text-gray-500 mb-4">Filtra por la calificación mínima de los profesionales</p>

          <div className="flex justify-between space-x-2">
            {[1, 2, 3, 4, 5].map((rating) => (
              <Button key={rating} variant={rating === 4 ? "default" : "outline"} className="flex-1">
                {rating}+
              </Button>
            ))}
          </div>
        </div>

        {/* Disponibilidad section */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-medium mb-2">Disponibilidad</h2>
          <p className="text-sm text-gray-500 mb-4">Filtra por la disponibilidad de los profesionales</p>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Disponible ahora</span>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Disponible fines de semana</span>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Disponible por la tarde</span>
              <Switch />
            </div>
          </div>
        </div>

        {/* Verificación section */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-20">
          <h2 className="text-lg font-medium mb-2">Verificación</h2>
          <p className="text-sm text-gray-500 mb-4">Opciones adicionales de verificación de perfiles</p>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium">Perfiles verificados</h3>
                <p className="text-xs text-gray-500">Solo mostrar usuarios con identidad verificada</p>
              </div>
              <Switch />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium">Con referencias</h3>
                <p className="text-xs text-gray-500">Solo mostrar usuarios con referencias verificadas</p>
              </div>
              <Switch />
            </div>
          </div>
        </div>
      </div>

      {/* Apply filters button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t">
        <Button className="w-full bg-black hover:bg-gray-800 text-white">Aplicar filtros</Button>
      </div>
    </div>
  )
}
