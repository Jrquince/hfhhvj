import { ArrowLeft, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"

export default function CategoriaPage() {
  const categories = [
    { name: "Todos", selected: true },
    { name: "Profesionales", selected: false },
    { name: "Vivienda", selected: false },
    { name: "Motor", selected: false },
    { name: "Tecnología", selected: false },
    { name: "Educación", selected: false },
    { name: "Hogar", selected: false },
    { name: "Mascotas", selected: false },
    { name: "Eventos", selected: false },
    { name: "Moda", selected: false },
    { name: "Deportes", selected: false },
    { name: "Arte y Cultura", selected: false },
    { name: "Salud y Bienestar", selected: false },
    { name: "Gastronomía", selected: false },
    { name: "Viajes", selected: false },
  ]

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/filtros">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">CATEGORÍA</h1>
        <div className="w-8"></div>
      </div>

      <div className="px-6 py-4">
        <p className="text-sm text-gray-500 mb-6">
          Selecciona las categorías que te interesan para filtrar los anuncios que ves.
        </p>

        <div className="space-y-2">
          {categories.map((category, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 cursor-pointer border-b"
            >
              <span className="text-sm">{category.name}</span>
              {category.selected && <Check className="h-5 w-5 text-yellow-500" />}
            </div>
          ))}
        </div>

        <div className="flex space-x-2 mt-8">
          <Button variant="outline" className="flex-1 rounded-full">
            Limpiar
          </Button>
          <Link href="/filtros">
            <Button className="flex-1 rounded-full bg-yellow-500 hover:bg-yellow-600 text-white">Aplicar</Button>
          </Link>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation />
    </div>
  )
}
