"use client"

import { useState } from "react"
import { ChevronLeft, Camera, MapPin, Tag, Calendar, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { toast } from "@/components/ui/use-toast"
import { QuickIAModal, type GeneratedContent } from "@/components/quickia-modal"

export default function CreatePost() {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [location, setLocation] = useState("")
  const [urgent, setUrgent] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [quickIAOpen, setQuickIAOpen] = useState(false)

  const categories = ["Profesionales", "Vivienda", "Motor", "Tecnología", "Educación", "Hogar", "Mascotas", "Eventos"]

  const handleQuickIASubmit = (content: GeneratedContent) => {
    setTitle(content.title)
    setDescription(content.description || "")
    if (content.suggestedCategory && categories.includes(content.suggestedCategory)) {
      setCategory(content.suggestedCategory)
    }

    toast({
      title: "Anuncio generado con QuickIA",
      description: "El contenido ha sido aplicado al formulario",
      duration: 3000,
    })
  }

  return (
    <div className="bg-white dark:bg-gray-950 min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between border-b dark:border-gray-800">
        <div className="flex items-center">
          <Link href="/" className="mr-4">
            <ChevronLeft className="h-6 w-6 dark:text-gray-300" />
          </Link>
          <h1 className="text-lg font-bold dark:text-white">Crear anuncio</h1>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setQuickIAOpen(true)}
            className="text-purple-600 border-purple-200 hover:bg-purple-50 dark:text-purple-400 dark:border-purple-900 dark:hover:bg-purple-950"
          >
            <Sparkles className="h-4 w-4 mr-1" />
            Pregúntale a QuickIA
          </Button>
          <Link href="/create-post/programar">
            <Button variant="ghost" size="sm" className="text-yellow-500 dark:text-yellow-400">
              <Calendar className="h-4 w-4 mr-1" />
              Programar
            </Button>
          </Link>
        </div>
      </div>

      {/* QuickIA Modal */}
      <QuickIAModal
        open={quickIAOpen}
        onOpenChange={(open) => setQuickIAOpen(open)}
        onSubmit={handleQuickIASubmit}
        mode="create"
      />

      {/* Form */}
      <div className="p-4 dark:text-gray-200">
        <div className="mb-6">
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Título
          </label>
          <Input
            id="title"
            placeholder="Ej: Busco fontanero para reparación urgente"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="dark:bg-gray-800 dark:border-gray-700"
          />
        </div>

        <div className="mb-6">
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Descripción
          </label>
          <Textarea
            id="description"
            placeholder="Describe tu anuncio con detalle..."
            rows={5}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="dark:bg-gray-800 dark:border-gray-700"
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Categoría</label>
          <div className="grid grid-cols-2 gap-2">
            {categories.map((cat) => (
              <Button
                key={cat}
                variant="outline"
                className={`justify-start dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 ${
                  category === cat
                    ? "border-yellow-500 bg-yellow-50 text-yellow-700 dark:border-yellow-600 dark:bg-yellow-950 dark:text-yellow-400"
                    : ""
                }`}
                onClick={() => setCategory(cat)}
              >
                <Tag className="h-4 w-4 mr-2" />
                {cat}
              </Button>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <label htmlFor="location" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Ubicación
          </label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 dark:text-gray-500" />
            <Input
              id="location"
              placeholder="Ej: Bilbao, Vizcaya"
              className="pl-10 dark:bg-gray-800 dark:border-gray-700"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Imágenes (opcional)</label>
          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center dark:border-gray-700">
            <Camera className="h-8 w-8 text-gray-400 dark:text-gray-500 mb-2" />
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
              Haz clic para subir imágenes o arrastra y suelta aquí
            </p>
            <Button
              variant="outline"
              className="mt-4 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"
              onClick={() => {
                // Simular selección de archivo
                const input = document.createElement("input")
                input.type = "file"
                input.accept = "image/*"
                input.multiple = true
                input.onchange = (e) => {
                  // Aquí se manejaría la carga de imágenes
                  toast({
                    title: "Imágenes seleccionadas",
                    description: "Las imágenes se han seleccionado correctamente",
                    duration: 2000,
                  })
                }
                input.click()
              }}
            >
              Seleccionar imágenes
            </Button>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="urgent"
              className="h-4 w-4 text-yellow-500 focus:ring-yellow-500 border-gray-300 rounded dark:border-gray-600 dark:bg-gray-800"
              checked={urgent}
              onChange={(e) => setUrgent(e.target.checked)}
            />
            <label htmlFor="urgent" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
              Marcar como urgente
            </label>
          </div>
        </div>

        <div className="flex space-x-3">
          <Button
            variant="outline"
            className="flex-1 rounded-full dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"
            asChild
          >
            <Link href="/">Cancelar</Link>
          </Button>
          <Button
            className="w-full bg-black hover:bg-gray-800 text-white dark:bg-gray-800 dark:hover:bg-gray-700"
            disabled={isSubmitting}
            onClick={() => {
              setIsSubmitting(true)
              // Simular envío del formulario
              setTimeout(() => {
                toast({
                  title: "Anuncio publicado",
                  description: "Tu anuncio ha sido publicado correctamente",
                  duration: 2000,
                })
                setIsSubmitting(false)
                window.location.href = "/"
              }, 1500)
            }}
          >
            {isSubmitting ? "Subiendo..." : "Subir nuevo anuncio"}
          </Button>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="create" />
    </div>
  )
}
