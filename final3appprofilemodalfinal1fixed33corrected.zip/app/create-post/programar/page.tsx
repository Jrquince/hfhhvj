"use client"

import { useState } from "react"
import { ChevronLeft, Calendar, Clock, HelpCircle, X } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function ProgramarAnuncio() {
  const [showHelp, setShowHelp] = useState(false)
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [selectedTime, setSelectedTime] = useState<string | null>(null)

  // Generar fechas para el calendario (próximos 14 días)
  const generateDates = () => {
    const dates = []
    const today = new Date()

    for (let i = 0; i < 14; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      dates.push(date)
    }

    return dates
  }

  // Generar horas disponibles (de 8:00 a 22:00)
  const generateTimes = () => {
    const times = []

    for (let hour = 8; hour <= 22; hour++) {
      times.push(`${hour}:00`)
      if (hour < 22) {
        times.push(`${hour}:30`)
      }
    }

    return times
  }

  const dates = generateDates()
  const times = generateTimes()

  // Formatear fecha para mostrar
  const formatDate = (date: Date) => {
    return date.toLocaleDateString("es-ES", { weekday: "short", day: "numeric", month: "short" })
  }

  // Verificar si una fecha es hoy
  const isToday = (date: Date) => {
    const today = new Date()
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    )
  }

  return (
    <div className="bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between border-b">
        <div className="flex items-center">
          <Link href="/create-post" className="mr-4">
            <ChevronLeft className="h-6 w-6" />
          </Link>
          <h1 className="text-lg font-bold">Programar anuncio</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setShowHelp(true)}>
          <HelpCircle className="h-5 w-5" />
        </Button>
      </div>

      {/* Contenido */}
      <div className="p-4">
        <p className="text-sm text-gray-600 mb-6">
          Selecciona la fecha y hora en la que quieres que se publique tu anuncio automáticamente.
        </p>

        {/* Selector de fecha */}
        <div className="mb-6">
          <div className="flex items-center mb-3">
            <Calendar className="h-5 w-5 mr-2 text-yellow-500" />
            <h2 className="font-medium">Fecha de publicación</h2>
          </div>
          <div className="flex overflow-x-auto pb-2 space-x-2">
            {dates.map((date, index) => (
              <div
                key={index}
                className={`flex flex-col items-center justify-center p-3 rounded-lg min-w-[70px] cursor-pointer ${
                  selectedDate && date.toDateString() === selectedDate.toDateString()
                    ? "bg-yellow-500 text-white"
                    : "border"
                }`}
                onClick={() => setSelectedDate(date)}
              >
                <span className="text-xs uppercase">{date.toLocaleDateString("es-ES", { weekday: "short" })}</span>
                <span className="text-lg font-bold">{date.getDate()}</span>
                <span className="text-xs">{date.toLocaleDateString("es-ES", { month: "short" })}</span>
                {isToday(date) && (
                  <span className="text-xs mt-1 px-2 py-0.5 rounded-full bg-gray-200 text-gray-700">Hoy</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Selector de hora */}
        <div>
          <div className="flex items-center mb-3">
            <Clock className="h-5 w-5 mr-2 text-yellow-500" />
            <h2 className="font-medium">Hora de publicación</h2>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {times.map((time, index) => (
              <div
                key={index}
                className={`flex items-center justify-center p-3 rounded-lg cursor-pointer ${
                  selectedTime === time ? "bg-yellow-500 text-white" : "border"
                }`}
                onClick={() => setSelectedTime(time)}
              >
                <span>{time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Resumen */}
        {selectedDate && selectedTime && (
          <div className="mt-8 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium mb-2">Resumen de programación</h3>
            <p className="text-sm">
              Tu anuncio se publicará el <span className="font-medium">{formatDate(selectedDate)}</span> a las{" "}
              <span className="font-medium">{selectedTime}</span> horas.
            </p>
          </div>
        )}

        {/* Botones */}
        <div className="mt-8 flex space-x-3">
          <Button variant="outline" className="flex-1 rounded-full" asChild>
            <Link href="/create-post">Cancelar</Link>
          </Button>
          <Button
            className="flex-1 rounded-full bg-yellow-500 hover:bg-yellow-600 text-white"
            disabled={!selectedDate || !selectedTime}
          >
            Confirmar
          </Button>
        </div>
      </div>

      {/* Modal de ayuda */}
      {showHelp && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg">¿Cómo funciona la programación?</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowHelp(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="space-y-4">
              <div className="flex">
                <div className="mr-3 mt-1">
                  <div className="w-6 h-6 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-500">
                    1
                  </div>
                </div>
                <p className="text-sm">
                  Puedes elegir una fecha y hora futura para que tu anuncio se publique automáticamente.
                </p>
              </div>

              <div className="flex">
                <div className="mr-3 mt-1">
                  <div className="w-6 h-6 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-500">
                    2
                  </div>
                </div>
                <p className="text-sm">Selecciona el día en el calendario, luego elige la hora exacta.</p>
              </div>

              <div className="flex">
                <div className="mr-3 mt-1">
                  <div className="w-6 h-6 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-500">
                    3
                  </div>
                </div>
                <p className="text-sm">
                  Una vez programado, tu anuncio aparecerá en el feed en ese momento sin que tengas que hacer nada más.
                </p>
              </div>
            </div>

            <Button
              className="w-full mt-6 rounded-full bg-yellow-500 hover:bg-yellow-600 text-white"
              onClick={() => setShowHelp(false)}
            >
              Entendido
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
