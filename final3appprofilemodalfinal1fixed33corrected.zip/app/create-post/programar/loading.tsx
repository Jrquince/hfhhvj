import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between border-b">
        <div className="flex items-center">
          <Skeleton className="h-6 w-6 rounded-full mr-4" />
          <Skeleton className="h-6 w-40" />
        </div>
        <Skeleton className="h-6 w-6 rounded-full" />
      </div>

      {/* Contenido */}
      <div className="p-4">
        <Skeleton className="h-4 w-full mb-6" />

        {/* Selector de fecha */}
        <div className="mb-6">
          <div className="flex items-center mb-3">
            <Skeleton className="h-5 w-5 mr-2" />
            <Skeleton className="h-5 w-40" />
          </div>
          <div className="flex overflow-x-auto pb-2 space-x-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-20 w-16 rounded-lg" />
            ))}
          </div>
        </div>

        {/* Selector de hora */}
        <div>
          <div className="flex items-center mb-3">
            <Skeleton className="h-5 w-5 mr-2" />
            <Skeleton className="h-5 w-40" />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {Array.from({ length: 12 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full rounded-lg" />
            ))}
          </div>
        </div>

        {/* Botones */}
        <div className="mt-8 flex space-x-3">
          <Skeleton className="h-10 flex-1 rounded-full" />
          <Skeleton className="h-10 flex-1 rounded-full" />
        </div>
      </div>
    </div>
  )
}
