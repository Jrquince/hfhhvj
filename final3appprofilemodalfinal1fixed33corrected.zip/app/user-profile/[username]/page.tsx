import { ArrowLeft, Star, ChevronDown, MapPin, Calendar, Award, MessageSquare, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { BottomNavigation } from "@/components/bottom-navigation"
import Link from "next/link"
import { ProfileImage } from "@/components/profile-image"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Datos de ejemplo para los perfiles
const profileData = {
  "jaime-diaz": {
    id: 1,
    name: "Jaime Díaz",
    username: "jaime-diaz",
    profession: "Maestro de obra",
    location: "Bilbao, Vizcaya",
    joinDate: "Marzo 2021",
    verified: true,
    rating: 4.8,
    recommendations: 42,
    badges: ["Profesional verificado", "Respuesta rápida", "Alta calidad"],
    description:
      "Maestro/a en la obra de Bilbao. He estado en este ámbito mucho tiempo y me gustaría que lo vieras. Podrías aprender mucho.",
    completionRate: 40,
    posts: [
      {
        id: 101,
        title: "Buscar un compañero/a de piso para el curso académico 23/24 en Bilbao",
        views: 5,
        date: "12/04/2023",
      },
      {
        id: 102,
        title: "Buscar un compañero/a de piso para el curso académico 22/23 en Bilbao",
        views: 3,
        date: "15/09/2022",
      },
      {
        id: 103,
        title: "Buscar un compañero/a de piso para el curso académico 21/22 en Madrid",
        views: 4,
        date: "20/08/2021",
      },
    ],
    services: [
      {
        id: 201,
        title: "Reformas integrales de viviendas",
        category: "Reformas",
        price: "Desde 150€/m²",
        rating: 4.9,
      },
      {
        id: 202,
        title: "Instalación de pladur y falsos techos",
        category: "Construcción",
        price: "25€/h",
        rating: 4.7,
      },
    ],
    reviews: [
      {
        id: 301,
        author: "Carlos Martínez",
        authorImage: "/placeholder.svg?height=40&width=40",
        rating: 5,
        date: "15/03/2023",
        text: "Excelente profesional, muy puntual y trabajo impecable.",
      },
      {
        id: 302,
        author: "Laura Gómez",
        authorImage: "/placeholder.svg?height=40&width=40",
        rating: 4,
        date: "02/02/2023",
        text: "Buen trabajo, aunque tardó un poco más de lo previsto.",
      },
    ],
  },
  "ron-69": {
    id: 3,
    name: "RON 69",
    username: "ron-69",
    profession: "Experto en servicios profesionales",
    location: "Madrid, España",
    joinDate: "Enero 2022",
    verified: false,
    rating: 4.5,
    recommendations: 28,
    badges: ["Respuesta rápida", "Buen precio"],
    description: "Experto en servicios profesionales con amplia experiencia en el sector.",
    completionRate: 40,
    posts: [
      {
        id: 104,
        title: "Ofrezco servicios de consultoría para pequeñas empresas",
        views: 12,
        date: "05/03/2023",
      },
      {
        id: 105,
        title: "Asesoramiento en marketing digital para emprendedores",
        views: 8,
        date: "18/01/2023",
      },
    ],
    services: [
      {
        id: 203,
        title: "Consultoría de negocios",
        category: "Servicios profesionales",
        price: "50€/h",
        rating: 4.6,
      },
      {
        id: 204,
        title: "Estrategia de marketing digital",
        category: "Marketing",
        price: "Desde 300€",
        rating: 4.4,
      },
    ],
    reviews: [
      {
        id: 303,
        author: "Miguel Torres",
        authorImage: "/placeholder.svg?height=40&width=40",
        rating: 5,
        date: "10/04/2023",
        text: "Muy profesional y con grandes conocimientos. Recomendado.",
      },
      {
        id: 304,
        author: "Ana Rodríguez",
        authorImage: "/placeholder.svg?height=40&width=40",
        rating: 4,
        date: "25/02/2023",
        text: "Buenos consejos que han ayudado a mi negocio.",
      },
    ],
  },
  // Añadir más perfiles según sea necesario
}

export default function UserProfilePage({ params }: { params: { username: string } }) {
  // Obtener datos del perfil según el nombre de usuario
  const profile = profileData[params.username as keyof typeof profileData] || profileData["jaime-diaz"]

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <span className="text-sm font-medium">Perfil profesional</span>
        <div className="w-8"></div> {/* Empty div for spacing */}
      </div>

      {/* User info */}
      <div className="px-6 pt-4 pb-4">
        <div className="flex justify-center mb-4 relative">
          <ProfileImage profileId={profile.id} username={profile.name} size="xl" className="border-2 border-gray-200" />
        </div>

        <div className="text-center mb-4">
          <h1 className="text-xl font-semibold text-gray-900 flex items-center justify-center">
            {profile.name}
            {profile.verified && (
              <Badge className="ml-2 bg-blue-100 text-blue-700 hover:bg-blue-100">
                <Award className="h-3 w-3 mr-1" />
                Verificado
              </Badge>
            )}
          </h1>

          <div className="flex items-center justify-center mt-1">
            <span className="text-sm text-gray-500">{profile.profession}</span>
            <div className="flex items-center ml-2">
              <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
              <span className="ml-1 text-sm font-medium">{profile.rating}</span>
            </div>
          </div>

          <div className="flex items-center justify-center mt-2 text-xs text-gray-500">
            <MapPin className="h-3.5 w-3.5 mr-1" />
            {profile.location}
            <span className="mx-2">•</span>
            <Calendar className="h-3.5 w-3.5 mr-1" />
            Miembro desde {profile.joinDate}
          </div>
        </div>

        <p className="text-sm text-center text-gray-600 mb-6">{profile.description}</p>

        {/* Progress bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-sm font-medium text-gray-700">PERFIL COMPLETADO</h2>
            <span className="text-sm font-medium text-gray-700">{profile.completionRate}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-gray-800 h-2.5 rounded-full" style={{ width: `${profile.completionRate}%` }}></div>
          </div>
          <div className="text-right mt-1">
            <Button variant="link" className="text-xs text-gray-500 p-0 h-auto">
              Completar perfil
            </Button>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2 mb-6">
          <Button className="flex-1 bg-gray-900 hover:bg-gray-800 text-white rounded-md">
            <MessageSquare className="h-4 w-4 mr-2" />
            Contactar
          </Button>
          <Button variant="outline" className="flex-1 border-gray-300 text-gray-700 rounded-md">
            Ver recomendaciones
          </Button>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="posts" className="text-sm">
              Publicaciones
            </TabsTrigger>
            <TabsTrigger value="services" className="text-sm">
              Servicios
            </TabsTrigger>
            <TabsTrigger value="reviews" className="text-sm">
              Valoraciones
            </TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-4">
            <Button className="w-full rounded-md bg-gray-100 text-gray-800 hover:bg-gray-200 text-sm py-2 px-4 h-auto">
              Todos
            </Button>

            {profile.posts.map((post) => (
              <Card key={post.id} className="border rounded-xl overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-sm font-medium text-gray-800">{post.title}</h3>
                    <ChevronDown className="h-5 w-5 text-gray-400 shrink-0 ml-2" />
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">{post.date}</span>
                    <Badge className="text-xs bg-blue-50 text-blue-600 hover:bg-blue-50">{post.views} vistos</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="services" className="space-y-4">
            {profile.services.map((service) => (
              <Card key={service.id} className="border rounded-xl overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-sm font-medium text-gray-800">{service.title}</h3>
                    <div className="flex items-center">
                      <Star className="h-3.5 w-3.5 text-yellow-400 fill-yellow-400" />
                      <span className="ml-1 text-xs font-medium">{service.rating}</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100 font-normal">
                      {service.category}
                    </Badge>
                    <span className="text-xs font-medium text-gray-700">{service.price}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="reviews" className="space-y-4">
            {profile.reviews.map((review) => (
              <Card key={review.id} className="border rounded-xl overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <Avatar className="h-8 w-8 mr-2">
                        <AvatarImage src={review.authorImage || "/placeholder.svg"} alt={review.author} />
                        <AvatarFallback>{review.author.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-sm font-medium text-gray-800">{review.author}</h3>
                        <span className="text-xs text-gray-500">{review.date}</span>
                      </div>
                    </div>
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-3.5 w-3.5 ${
                            star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-200"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">{review.text}</p>
                </CardContent>
              </Card>
            ))}

            <div className="flex justify-center mt-2">
              <Button variant="outline" size="sm" className="text-xs h-8 border-gray-200">
                Ver todas las valoraciones
                <ArrowRight className="ml-1 h-3.5 w-3.5" />
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="profile" />
    </div>
  )
}
