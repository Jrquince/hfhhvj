"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Search, Filter, X, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { ProfileAvatar } from "@/components/profile-avatar"
import Image from "next/image"
import { getAvatarByUserId } from "@/lib/avatar-utils"
import { toast } from "sonner"

export default function SavedPage() {
  const [activeTab, setActiveTab] = useState("posts")
  const [searchQuery, setSearchQuery] = useState("")
  const [hasNewRequests, setHasNewRequests] = useState(true)

  // Eliminar la notificación cuando el usuario visita la página
  useEffect(() => {
    setHasNewRequests(false)
  }, [])

  const savedPosts = [
    {
      id: 1,
      title: "Fontanero profesional disponible 24/7",
      user: { name: "Carlos Martínez", location: "Barcelona", profileId: 7, verified: true },
      category: "Profesionales",
      date: "12/05/23",
    },
    {
      id: 2,
      title: "Busco compañero de piso zona Deusto",
      user: { name: "Ana García", location: "Bilbao", profileId: 2, verified: false },
      category: "Vivienda",
      date: "10/05/23",
    },
    {
      id: 3,
      title: "Clases particulares de matemáticas",
      user: { name: "Laura Vega", location: "Madrid", profileId: 9, verified: true },
      category: "Educación",
      date: "08/05/23",
    },
    {
      id: 4,
      title: "Vendo coche seminuevo, 50.000km",
      user: { name: "Miguel Torres", location: "Valencia", profileId: 3, verified: false },
      category: "Motor",
      date: "05/05/23",
    },
  ]

  const savedProfiles = [
    {
      id: 1,
      name: "Carlos Martínez",
      role: "Fontanero",
      location: "Barcelona",
      rating: 4.8,
      profileId: 7,
      verified: true,
    },
    {
      id: 2,
      name: "Laura Vega",
      role: "Profesora",
      location: "Madrid",
      rating: 4.9,
      profileId: 9,
      verified: true,
    },
    {
      id: 3,
      name: "Miguel Torres",
      role: "Electricista",
      location: "Valencia",
      rating: 4.7,
      profileId: 3,
      verified: false,
    },
    {
      id: 4,
      name: "Ana García",
      role: "Diseñadora",
      location: "Bilbao",
      rating: 4.6,
      profileId: 2,
      verified: false,
    },
    {
      id: 5,
      name: "Javier Ruiz",
      role: "Carpintero",
      location: "Sevilla",
      rating: 4.5,
      profileId: 6,
      verified: true,
    },
    {
      id: 6,
      name: "Sofía Mendoza",
      role: "Arquitecta",
      location: "Madrid",
      rating: 4.9,
      profileId: 4,
      verified: false,
    },
  ]

  const connectionRequests = [
    {
      id: 1,
      name: "Javier Ruiz",
      role: "Carpintero",
      message: "Me gustaría conectar contigo para posibles proyectos",
      time: "Hace 2 horas",
      profileId: 6,
      verified: true,
    },
    {
      id: 2,
      name: "Elena Sánchez",
      role: "Arquitecta",
      message: "Hola, vi tu perfil y me interesa colaborar",
      time: "Hace 1 día",
      profileId: 4,
      verified: true,
    },
    {
      id: 3,
      name: "Roberto Fernández",
      role: "Fotógrafo",
      message: "Podríamos trabajar juntos en futuros eventos",
      time: "Hace 2 días",
      profileId: 8,
      verified: false,
    },
    {
      id: 4,
      name: "Carmen López",
      role: "Diseñadora de interiores",
      message: "Me encantaría colaborar en proyectos de decoración",
      time: "Hace 3 días",
      profileId: 1,
      verified: false,
    },
    {
      id: 5,
      name: "Miguel Ángel",
      role: "Electricista",
      message: "Busco profesionales para formar un equipo de reformas",
      time: "Hace 4 días",
      profileId: 3,
      verified: true,
    },
  ]

  // Filtrar por búsqueda
  const filteredPosts = searchQuery
    ? savedPosts.filter(
        (post) =>
          post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          post.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          post.category.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : savedPosts

  const filteredProfiles = searchQuery
    ? savedProfiles.filter(
        (profile) =>
          profile.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          profile.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
          profile.location.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : savedProfiles

  const filteredRequests = searchQuery
    ? connectionRequests.filter(
        (request) =>
          request.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          request.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
          request.message.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : connectionRequests

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">GUARDADOS</h1>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 rounded-full"
          onClick={() => {
            toast({
              title: "Filtros",
              description: "Abriendo opciones de filtrado",
              duration: 2000,
            })
          }}
        >
          <Filter className="h-5 w-5" />
        </Button>
      </div>

      {/* Search */}
      <div className="p-4 sticky top-16 bg-white z-10">
        <div className="relative">
          <Input
            placeholder="Buscar"
            className="pl-10 pr-3 py-1.5 rounded-full border-gray-200 text-sm h-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          {searchQuery && (
            <X
              className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 cursor-pointer"
              onClick={() => setSearchQuery("")}
            />
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 pb-2 flex space-x-2 overflow-x-auto">
        <Button
          variant="outline"
          size="sm"
          className={`rounded-full text-xs ${
            activeTab === "posts" ? "bg-black text-white border-black" : "border-gray-300"
          }`}
          onClick={() => setActiveTab("posts")}
        >
          Anuncios
        </Button>
        <Button
          variant="outline"
          size="sm"
          className={`rounded-full text-xs ${
            activeTab === "profiles" ? "bg-black text-white border-black" : "border-gray-300"
          }`}
          onClick={() => setActiveTab("profiles")}
        >
          Perfiles
        </Button>
        <Button
          variant="outline"
          size="sm"
          className={`rounded-full text-xs ${
            activeTab === "requests" ? "bg-black text-white border-black" : "border-gray-300"
          }`}
          onClick={() => setActiveTab("requests")}
        >
          Solicitudes
          {hasNewRequests && (
            <span className="ml-1 bg-yellow-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
              {connectionRequests.length}
            </span>
          )}
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === "posts" && (
          <div className="p-4 space-y-4">
            {filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <Link href={`/post-detail/${post.id}`} key={post.id}>
                  <div className="border rounded-xl p-4 hover:bg-gray-50">
                    <div className="flex items-center mb-2">
                      <ProfileAvatar
                        userId={post.user.profileId}
                        username={post.user.name}
                        size="sm"
                        verified={post.user.verified}
                      />
                      <div className="ml-2">
                        <h4 className="font-medium text-xs">{post.user.name}</h4>
                        <p className="text-xs text-gray-500">{post.user.location}</p>
                      </div>
                    </div>
                    <p className="text-sm font-medium mb-2">{post.title}</p>
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <span>{post.category}</span>
                      <span>{post.date}</span>
                    </div>
                  </div>
                </Link>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">No hay anuncios guardados</p>
              </div>
            )}
          </div>
        )}

        {activeTab === "profiles" && (
          <div className="p-4 space-y-4">
            {filteredProfiles.length > 0 ? (
              filteredProfiles.map((profile) => (
                <Link href={`/user-profile-detail/${profile.id}`} key={profile.id}>
                  <div className="border rounded-xl p-4 hover:bg-gray-50">
                    <div className="flex items-center">
                      <div className="relative w-12 h-12 rounded-full overflow-hidden border border-gray-200">
                        <Image
                          src={getAvatarByUserId(profile.profileId) || "/placeholder.svg"}
                          alt={profile.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex items-center">
                          <h3 className="font-medium text-sm">{profile.name}</h3>
                          {profile.verified && (
                            <div className="ml-1 bg-blue-100 text-blue-600 rounded-full px-1.5 py-0.5 text-xs">✓</div>
                          )}
                        </div>
                        <p className="text-xs text-gray-500">{profile.role}</p>
                        <div className="flex items-center mt-1">
                          <span className="text-xs text-gray-500 mr-2">{profile.location}</span>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <svg
                                key={i}
                                className={`w-3 h-3 ${i < Math.floor(profile.rating) ? "text-yellow-400" : "text-gray-300"}`}
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                            ))}
                            <span className="text-xs ml-1">{profile.rating}</span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-gray-400" />
                    </div>
                  </div>
                </Link>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">No hay perfiles guardados</p>
              </div>
            )}
          </div>
        )}

        {activeTab === "requests" && (
          <div className="p-4 space-y-4">
            {filteredRequests.length > 0 ? (
              filteredRequests.map((request) => (
                <div key={request.id} className="border rounded-xl p-4">
                  <div className="flex items-center mb-3">
                    <div className="relative w-12 h-12 rounded-full overflow-hidden border border-gray-200">
                      <Image
                        src={getAvatarByUserId(request.profileId) || "/placeholder.svg"}
                        alt={request.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="ml-3 flex-1">
                      <div className="flex items-center">
                        <h3 className="font-medium text-sm">{request.name}</h3>
                        {request.verified && (
                          <div className="ml-1 bg-blue-100 text-blue-600 rounded-full px-1.5 py-0.5 text-xs">✓</div>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">{request.role}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{request.time}</p>
                    </div>
                  </div>
                  <p className="text-sm mb-3">{request.message}</p>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      className="flex-1 rounded-full text-xs"
                      onClick={() => {
                        toast({
                          title: "Solicitud rechazada",
                          description: "Has rechazado la solicitud de conexión",
                          duration: 2000,
                        })
                      }}
                    >
                      Rechazar
                    </Button>
                    <Button
                      className="flex-1 rounded-full bg-yellow-500 hover:bg-yellow-600 text-white text-xs"
                      onClick={() => {
                        toast({
                          title: "Solicitud aceptada",
                          description: "Has aceptado la solicitud de conexión",
                          duration: 2000,
                        })
                      }}
                    >
                      Aceptar
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">No hay solicitudes pendientes</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="chats" unreadMessages={3} />
    </div>
  )
}
