"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Search, Star, Heart, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { BottomNavigation } from "@/components/bottom-navigation"
import { getAvatarByUserId } from "@/lib/avatar-utils"

export default function SavedProfilesPage() {
  const [searchQuery, setSearchQuery] = useState("")

  // Datos de ejemplo para perfiles guardados
  const savedProfiles = [
    {
      id: 1,
      userId: 10,
      name: "Roberto García",
      profession: "Electricista",
      rating: 4.8,
      reviews: 42,
      location: "Madrid, 3.2 km",
      tags: ["Instalaciones", "Reparaciones", "Urgencias"],
      price: "25€/h",
    },
    {
      id: 2,
      userId: 11,
      name: "Lucía Martínez",
      profession: "Pintora",
      rating: 4.9,
      reviews: 56,
      location: "Barcelona, 1.8 km",
      tags: ["Interior", "Exterior", "Decorativa"],
      price: "22€/h",
    },
    {
      id: 3,
      userId: 12,
      name: "Manuel López",
      profession: "Carpintero",
      rating: 4.7,
      reviews: 38,
      location: "Valencia, 4.5 km",
      tags: ["Muebles", "Restauración", "Montaje"],
      price: "28€/h",
    },
    {
      id: 4,
      userId: 13,
      name: "Carmen Ruiz",
      profession: "Limpieza",
      rating: 4.6,
      reviews: 29,
      location: "Sevilla, 2.1 km",
      tags: ["Hogar", "Oficinas", "Cristales"],
      price: "18€/h",
    },
    {
      id: 5,
      userId: 14,
      name: "Javier Sánchez",
      profession: "Jardinero",
      rating: 4.9,
      reviews: 47,
      location: "Málaga, 5.3 km",
      tags: ["Diseño", "Mantenimiento", "Poda"],
      price: "24€/h",
    },
    {
      id: 6,
      userId: 15,
      name: "Elena Díaz",
      profession: "Informática",
      rating: 4.8,
      reviews: 51,
      location: "Bilbao, 3.7 km",
      tags: ["Reparación", "Software", "Redes"],
      price: "30€/h",
    },
    {
      id: 7,
      userId: 16,
      name: "Antonio Pérez",
      profession: "Fontanero",
      rating: 4.7,
      reviews: 33,
      location: "Zaragoza, 2.9 km",
      tags: ["Instalaciones", "Reparaciones", "Desatascos"],
      price: "26€/h",
    },
    {
      id: 8,
      userId: 17,
      name: "Laura Gómez",
      profession: "Diseñadora",
      rating: 4.9,
      reviews: 62,
      location: "Alicante, 1.5 km",
      tags: ["Web", "Gráfico", "UX/UI"],
      price: "35€/h",
    },
  ]

  // Filtrar perfiles por búsqueda
  const filteredProfiles = savedProfiles.filter(
    (profile) =>
      profile.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      profile.profession.toLowerCase().includes(searchQuery.toLowerCase()) ||
      profile.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/saved">
              <Button variant="ghost" size="icon" className="mr-2">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-lg font-semibold">Perfiles guardados</h1>
          </div>
        </div>
        <div className="container px-4 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              className="pl-9 bg-gray-100 border-0"
              placeholder="Buscar perfiles guardados"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </header>

      <main className="flex-1 container py-4 pb-16">
        <div className="grid grid-cols-1 gap-4">
          {filteredProfiles.length > 0 ? (
            filteredProfiles.map((profile) => (
              <Link href={`/user-profile-detail/${profile.id}`} key={profile.id}>
                <div className="bg-white rounded-lg border p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start">
                    <div className="relative w-16 h-16 rounded-full overflow-hidden">
                      <Image
                        src={getAvatarByUserId(profile.userId) || "/placeholder.svg"}
                        alt={profile.name}
                        width={64}
                        height={64}
                        className="object-cover"
                      />
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex justify-between">
                        <div>
                          <h3 className="font-medium">{profile.name}</h3>
                          <p className="text-sm text-gray-500">{profile.profession}</p>
                        </div>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                          <Heart className="h-5 w-5 fill-current" />
                        </Button>
                      </div>
                      <div className="flex items-center mt-1">
                        <Star className="h-3.5 w-3.5 text-yellow-500 fill-yellow-500" />
                        <span className="text-sm font-medium ml-1">{profile.rating}</span>
                        <span className="text-xs text-gray-500 ml-1">({profile.reviews})</span>
                      </div>
                      <div className="flex items-center mt-1 text-xs text-gray-500">
                        <MapPin className="h-3 w-3 mr-1" />
                        <span>{profile.location}</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex flex-wrap gap-1">
                      {profile.tags.map((tag, index) => (
                        <span key={index} className="text-xs bg-gray-100 text-gray-800 px-2 py-0.5 rounded-full">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-between items-center mt-3">
                    <span className="font-bold text-yellow-600">{profile.price}</span>
                    <Button variant="outline" size="sm" className="text-xs h-8 rounded-full">
                      Ver perfil
                    </Button>
                  </div>
                </div>
              </Link>
            ))
          ) : (
            <div className="py-10 text-center">
              <p className="text-gray-500">No se encontraron perfiles guardados</p>
              <p className="text-sm text-gray-400 mt-1">
                Prueba con otros términos de búsqueda o guarda nuevos perfiles
              </p>
            </div>
          )}
        </div>
      </main>

      <BottomNavigation activeItem="saved" />
    </div>
  )
}
