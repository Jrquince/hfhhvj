import MapPage from "@/components/map-page"

export default function MapPageRoute() {
  return <MapPage />
}
