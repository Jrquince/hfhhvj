import Image from "next/image"
import { Search, Heart } from "lucide-react"
import { Avatar } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { BottomNavigation } from "@/components/bottom-navigation"
import Link from "next/link"

export default function HomeRedesigned() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <span className="font-bold text-yellow-500 text-lg">QuickSer</span>
        <div className="relative w-48">
          <Input placeholder="Buscar" className="pl-3 pr-8 py-1.5 rounded-full border-gray-200 text-sm h-9" />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
        <Link href="/notifications">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full relative">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
            <span className="absolute -top-1 -right-1 bg-black text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
              2
            </span>
          </Button>
        </Link>
      </div>

      {/* Navigation tabs */}
      <div className="px-4 pb-2">
        <div className="flex space-x-2 overflow-x-auto">
          <Button variant="outline" size="sm" className="rounded-full text-xs border-gray-300">
            Anuncios
          </Button>
          <Button variant="outline" size="sm" className="rounded-full text-xs border-gray-300">
            Profesionales
          </Button>
          <Button variant="outline" size="sm" className="rounded-full text-xs border-gray-300">
            Vivienda
          </Button>
          <Button variant="outline" size="sm" className="rounded-full text-xs border-gray-300">
            Motor
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {/* First user post */}
        <div className="p-4">
          <div className="flex items-center mb-3">
            <Avatar className="h-10 w-10 border">
              <Image
                src="/placeholder.svg?height=40&width=40&text=DD"
                alt="Diego Domínguez"
                width={40}
                height={40}
                className="rounded-full"
              />
            </Avatar>
            <div className="ml-3">
              <h3 className="font-medium text-sm">Diego Domínguez</h3>
              <div className="flex items-center">
                <span className="text-xs text-gray-500 mr-2">Bilbao, Vizcaya</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <Link href="/post-detail/1">
            <div className="border rounded-xl p-5 relative mb-2">
              <Button variant="ghost" size="icon" className="absolute top-2 right-2 text-gray-400 hover:text-gray-600">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M19 21L12 16L5 21V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H17C17.5304 3 18.0391 3.21071 18.4142 3.58579C18.7893 3.96086 19 4.46957 19 5V21Z" />
                </svg>
              </Button>

              <div className="mt-4 mb-8 text-center">
                <p className="font-medium text-lg">
                  Busco un compañero de piso que esté estudiando para el curso 2025/2026 en la zona de Deusto.
                </p>
                <div className="flex justify-center mt-6">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                    <svg
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-gray-700"
                    >
                      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
                      <polyline points="9 22 9 12 15 12 15 22" />
                    </svg>
                  </div>
                </div>
              </div>

              <div className="flex justify-center space-x-1 mt-4">
                <div className="w-2 h-2 rounded-full bg-black"></div>
                <div className="w-2 h-2 rounded-full bg-gray-300"></div>
              </div>
            </div>
          </Link>

          <div className="flex justify-between items-center text-xs text-gray-500 px-1">
            <div className="flex items-center">
              <span className="font-medium">Estudiante</span>
              <span className="mx-1">•</span>
              <span>25/04/22 17:55</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                <Heart className="h-5 w-5 text-gray-400" />
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M4 11l9 9 9-9" />
                </svg>
              </Button>
            </div>
          </div>
        </div>

        {/* Second user post */}
        <div className="p-4 pt-2">
          <div className="flex items-center mb-3">
            <Avatar className="h-10 w-10 border">
              <Image
                src="/placeholder.svg?height=40&width=40&text=AU"
                alt="Ana Urrutia"
                width={40}
                height={40}
                className="rounded-full"
              />
            </Avatar>
            <div className="ml-3">
              <Link href="/user-profile/ana-urrutia">
                <h3 className="font-medium text-sm">Ana Urrutia</h3>
              </Link>
              <div className="flex items-center">
                <span className="text-xs text-gray-500 mr-2">Bilbao, Vizcaya</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <Link href="/post-detail/2">
            <div className="border rounded-xl overflow-hidden h-24 relative mb-2">
              <Image
                src="/placeholder.svg?height=200&width=400"
                alt="Post image"
                width={400}
                height={200}
                className="w-full h-full object-cover"
              />
            </div>
          </Link>
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNavigation activeItem="home" />
    </div>
  )
}
