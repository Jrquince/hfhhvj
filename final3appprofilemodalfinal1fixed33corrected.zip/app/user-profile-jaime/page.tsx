import { ArrowLeft, Star, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import Link from "next/link"
import Image from "next/image"

export default function UserProfileJaimePage() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <span className="text-sm font-medium">Mejor perfil</span>
      </div>

      {/* User info */}
      <div className="px-6 pt-2 pb-4">
        <div className="flex justify-center mb-3">
          <Avatar className="h-20 w-20 border-2 border-gray-200">
            <Image
              src="/placeholder.svg?height=80&width=80&text=JD"
              alt="Jaime díaz avatar"
              width={80}
              height={80}
              className="rounded-full"
            />
          </Avatar>
        </div>
        <h1 className="text-lg font-semibold text-center">Jaime díaz</h1>
        <div className="flex items-center justify-center mb-2">
          <span className="text-sm text-gray-500">Comunicación</span>
          <Star className="h-4 w-4 ml-1 text-yellow-400 fill-yellow-400" />
        </div>

        <p className="text-sm text-center mb-6">
          Maestro/a en la obra de Bilbao. He estado en este ámbito mucho tiempo y me gustaría que lo vieras. Podrías
          aprender mucho.
        </p>

        {/* Progress bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-sm font-medium">AÑADIR REALIZADOS</h2>
            <span className="text-sm font-medium">40%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "40%" }}></div>
          </div>
        </div>

        <div className="flex justify-end mb-6">
          <Button variant="link" className="text-xs text-gray-500 p-0 h-auto">
            Ver por muy buen aspecto
          </Button>
        </div>

        {/* Category tabs */}
        <div className="flex border-b mb-6">
          <Button variant="ghost" className="flex-1 rounded-none border-b-2 border-yellow-500 text-sm font-medium">
            Publicaciones
          </Button>
          <Button variant="ghost" className="flex-1 rounded-none text-sm font-medium text-gray-500">
            Configuración
          </Button>
          <Button variant="ghost" className="flex-1 rounded-none text-sm font-medium text-gray-500">
            Mis registros
          </Button>
        </div>

        {/* Projects */}
        <div className="space-y-4 mb-6">
          <Button className="w-full rounded-full bg-black text-white text-sm py-2 px-4 h-auto">Todos</Button>

          <div className="border rounded-xl p-4">
            <div className="flex justify-between items-start mb-3">
              <h3 className="text-sm font-medium">
                Buscar un compañero/a de piso para el curso académico 23/24 en Bilbao
              </h3>
              <ChevronDown className="h-5 w-5 text-gray-400 shrink-0 ml-2" />
            </div>
            <div className="flex justify-end">
              <Button className="text-xs text-blue-500 bg-blue-50 rounded-full py-1 px-3 h-auto">5 vistos</Button>
            </div>
          </div>

          <div className="border rounded-xl p-4">
            <div className="flex justify-between items-start mb-3">
              <h3 className="text-sm font-medium">
                Buscar un compañero/a de piso para el curso académico 22/23 en Bilbao
              </h3>
              <ChevronDown className="h-5 w-5 text-gray-400 shrink-0 ml-2" />
            </div>
            <div className="flex justify-end">
              <Button className="text-xs text-blue-500 bg-blue-50 rounded-full py-1 px-3 h-auto">3 vistos</Button>
            </div>
          </div>

          <div className="border rounded-xl p-4">
            <div className="flex justify-between items-start mb-3">
              <h3 className="text-sm font-medium">
                Buscar un compañero/a de piso para el curso académico 21/22 en Madrid
              </h3>
              <ChevronDown className="h-5 w-5 text-gray-400 shrink-0 ml-2" />
            </div>
            <div className="flex justify-end">
              <Button className="text-xs text-blue-500 bg-blue-50 rounded-full py-1 px-3 h-auto">4 vistos</Button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <div className="border-t flex justify-around py-3 mt-auto bg-white">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z" />
              <polyline points="9 22 9 12 15 12 15 22" />
            </svg>
          </Button>
        </Link>
        <Link href="/map">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 13C13.6569 13 15 11.6569 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.6569 10.3431 13 12 13Z" />
              <path d="M12 22C16 18 20 14.4183 20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10C4 14.4183 8 18 12 22Z" />
            </svg>
          </Button>
        </Link>
        <Link href="/create-post">
          <Button
            variant="default"
            size="icon"
            className="h-12 w-12 rounded-full bg-black flex flex-col items-center justify-center"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
          </Button>
        </Link>
        <Link href="/saved">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M19 21L12 16L5 21V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H17C17.5304 3 18.0391 3.21071 18.4142 3.58579C18.7893 3.96086 19 4.46957 19 5V21Z" />
            </svg>
          </Button>
        </Link>
        <Link href="/profile">
          <Button variant="ghost" size="icon" className="h-12 w-12 flex flex-col items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" />
              <circle cx="12" cy="7" r="4" />
            </svg>
          </Button>
        </Link>
      </div>
    </div>
  )
}
