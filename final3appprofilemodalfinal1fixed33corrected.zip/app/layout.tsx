import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { ModalProvider } from "@/components/modal-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "QuickSer",
  description: "Encuentra servicios y profesionales cerca de ti",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange={false}>
          <main className="max-w-md mx-auto bg-background min-h-screen pb-16 theme-transition">{children}</main>
          <ModalProvider />
        </ThemeProvider>
      </body>
    </html>
  )
}
