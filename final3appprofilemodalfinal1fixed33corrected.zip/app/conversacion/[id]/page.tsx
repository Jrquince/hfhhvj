import React from 'react';

interface PageProps {
  params: { id: string };
}

export default function ConversacionPage({ params }: PageProps) {
  const { id } = params;
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Conversación con el anunciante #{id}</h1>
      {/* Aquí puedes añadir tu componente de chat o formulario de mensajes */}
    </div>
  );
}
