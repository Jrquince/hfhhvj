"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Search, Bell, Filter, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { BottomNavigation } from "@/components/bottom-navigation"
import { useToast } from "@/hooks/use-toast"
import VirtualFeed from "@/components/virtual-feed"
import MessageNotification from "@/components/message-notification"
import FollowRequestPopup from "@/components/follow-request-popup"
import FilterModal from "@/components/filter-modal"
import { SearchModal } from "@/components/search-modal"
import { QuickIAModal } from "@/components/quickia-modal"

// Categorías para filtros
const categories = [
  "Todos",
  "Limpieza",
  "Fontanería",
  "Electricidad",
  "Pintura",
  "Carpintería",
  "Jardinería",
  "Mudanzas",
  "Reformas",
]

// URLs de videos de ejemplo para tarjetas de profesionales
const professionalVideos = [
  "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
]

// Datos de profesionales para las tarjetas de video
const professionalData = [
  {
    name: "Carlos Martínez",
    profession: "Fontanero profesional",
    experience: "8 años de experiencia",
    rating: 4.9,
    location: "Bilbao, Vizcaya",
    verified: true,
    description: "Especialista en instalaciones y reparaciones urgentes. Servicio rápido y eficiente.",
    id: 1001,
  },
  {
    name: "Laura Sánchez",
    profession: "Electricista certificada",
    experience: "12 años de experiencia",
    rating: 4.8,
    location: "Bilbao, Vizcaya",
    verified: true,
    description: "Soluciones eléctricas para hogar y comercio. Instalaciones seguras y garantizadas.",
    id: 1002,
  },
  {
    name: "Miguel Torres",
    profession: "Especialista en reformas",
    experience: "15 años de experiencia",
    rating: 4.7,
    location: "Bilbao, Vizcaya",
    verified: true,
    description: "Reformas integrales de cocinas y baños. Diseño y ejecución profesional.",
    id: 1003,
  },
  {
    name: "Ana Gómez",
    profession: "Limpieza profesional",
    experience: "6 años de experiencia",
    rating: 4.9,
    location: "Bilbao, Vizcaya",
    verified: true,
    description: "Servicio de limpieza a fondo para hogares y oficinas. Productos ecológicos.",
    id: 1004,
  },
  {
    name: "David Ruiz",
    profession: "Técnico informático",
    experience: "10 años de experiencia",
    rating: 4.8,
    location: "Bilbao, Vizcaya",
    verified: true,
    description: "Reparación y mantenimiento de ordenadores y redes. Soporte técnico a domicilio.",
    id: 1005,
  },
  {
    name: "Elena Rodríguez",
    profession: "Pintora decorativa",
    experience: "9 años de experiencia",
    rating: 4.9,
    location: "Bilbao, Vizcaya",
    verified: true,
    description: "Especialista en pintura decorativa y murales. Transformo espacios con color y estilo.",
    id: 1006,
  },
  {
    name: "Javier López",
    profession: "Jardinero paisajista",
    experience: "14 años de experiencia",
    rating: 4.7,
    location: "Bilbao, Vizcaya",
    verified: true,
    description: "Diseño y mantenimiento de jardines. Especialista en plantas autóctonas y sostenibles.",
    id: 1007,
  },
  {
    name: "Sofía Martín",
    profession: "Profesora particular",
    experience: "11 años de experiencia",
    rating: 5.0,
    location: "Bilbao, Vizcaya",
    verified: true,
    description: "Clases particulares de matemáticas, física y química. Resultados garantizados.",
    id: 1008,
  },
]

// Datos de ejemplo para el scroll infinito
const generatePosts = (start: number, count: number, filter = "Todos", refresh = false) => {
  // Actualizar la función generatePosts para usar los nuevos avatares
  const users = [
    {
      id: 1,
      name: "Diego Domínguez",
      location: "Bilbao, Vizcaya",
      verified: true,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%286%29.jfif-2N7CGhkzwCvR9V7h8wckVtCaVgBnLD.jpeg",
    },
    {
      id: 2,
      name: "Ana Urrutia",
      location: "Bilbao, Vizcaya",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%287%29.jfif-ymppqAxBMrDCcfpYae8hqdZfdpHwbd.jpeg",
    },
    {
      id: 3,
      name: "Jaime Díaz",
      location: "Bilbao, Vizcaya",
      verified: true,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%281%29.jfif-togashgF7m10GyOiYVlmWbOMn5s2bP.jpeg",
    },
    {
      id: 4,
      name: "María Ruiz",
      location: "Sevilla, España",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%282%29.jfif-3AxWczIWmZr3tN77VFciuOSWNeMW2F.jpeg",
    },
    {
      id: 5,
      name: "Pablo Arzar",
      location: "Madrid, España",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%283%29.jfif-tSg7Nx9ozw5uCpqHsdovFwrDGj1kA5.jpeg",
    },
    {
      id: 6,
      name: "Lucía Gómez",
      location: "Valencia, España",
      verified: true,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%285%29.jfif-XgPkvJ9HwSSvCwKNvTcrGT3gEF6VLO.jpeg",
    },
    {
      id: 7,
      name: "Carlos Martín",
      location: "Barcelona, España",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2810%29.jfif-lMM6ZSR9TENpeXKyJ06CDIkVJhGzss.jpeg",
    },
    {
      id: 8,
      name: "Elena Sánchez",
      location: "Málaga, España",
      verified: true,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2812%29.jfif-CCy5Tm8SlqVRo3k10EEfHfndniubMd.jpeg",
    },
    {
      id: 9,
      name: "Roberto Fernández",
      location: "Zaragoza, España",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/descarga.jfif-1forRaQUkhYOqydcVKCTUM2bvDk2Fh.jpeg",
    },
    {
      id: 10,
      name: "Alberto Vázquez",
      location: "Bilbao, Vizcaya",
      verified: true,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%286%29.jfif-2N7CGhkzwCvR9V7h8wckVtCaVgBnLD.jpeg",
    },
    {
      id: 11,
      name: "Sofía Mendoza",
      location: "Madrid, España",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%287%29.jfif-ymppqAxBMrDCcfpYae8hqdZfdpHwbd.jpeg",
    },
    {
      id: 12,
      name: "Javier Torres",
      location: "Barcelona, España",
      verified: true,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%281%29.jfif-togashgF7m10GyOiYVlmWbOMn5s2bP.jpeg",
    },
    {
      id: 13,
      name: "Carmen López",
      location: "Valencia, España",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%282%29.jfif-3AxWczIWmZr3tN77VFciuOSWNeMW2F.jpeg",
    },
    {
      id: 14,
      name: "Miguel Ángel",
      location: "Sevilla, España",
      verified: true,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%283%29.jfif-tSg7Nx9ozw5uCpqHsdovFwrDGj1kA5.jpeg",
    },
    {
      id: 15,
      name: "Laura Pérez",
      location: "Málaga, España",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%285%29.jfif-XgPkvJ9HwSSvCwKNvTcrGT3gEF6VLO.jpeg",
    },
    {
      id: 16,
      name: "Daniel García",
      location: "Bilbao, Vizcaya",
      verified: true,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2810%29.jfif-lMM6ZSR9TENpeXKyJ06CDIkVJhGzss.jpeg",
    },
    {
      id: 17,
      name: "Isabel Rodríguez",
      location: "Madrid, España",
      verified: false,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2812%29.jfif-CCy5Tm8SlqVRo3k10EEfHfndniubMd.jpeg",
    },
  ]

  // Títulos de anuncios normales
  const postTitles = [
    "Busco un compañero de piso que esté estudiando para el curso 2025/2026 en la zona de Deusto.",
    "Necesito ayuda para montar un mueble de Ikea en mi apartamento en Bagatza",
    "Ofrezco servicios de fontanería en toda la zona de Bilbao",
    "Busco profesor/a particular de matemáticas para nivel universitario",
    "Vendo coche seminuevo en perfecto estado. 50.000km",
    "Necesito reparación urgente de mi ordenador portátil. No enciende",
    "Busco paseador/a para mi perro durante las mañanas",
    "Ofrezco servicios de limpieza por horas. Experiencia demostrable",
    "Vendo moto en perfecto estado. Recién revisada",
    "Busco compañeros para compartir gastos de viaje a Portugal",
    "Se ofrece profesor de inglés nativo para clases particulares",
    "Necesito ayuda con mudanza este fin de semana",
    "Ofrezco servicios de diseño gráfico para pequeñas empresas",
    "Busco canguro para niños de 5 y 7 años, tardes entre semana",
    "Vendo bicicleta de montaña casi sin uso",
  ]

  // Títulos de anuncios urgentes
  const urgentPostTitles = [
    "URGENTE: Necesito un desarrollador web para proyecto que empieza mañana",
    "Busco entrenador personal disponible esta semana para preparar competición",
    "URGENTE: Necesito fontanero hoy mismo para arreglar fuga en baño",
    "Busco profesor de piano para clase intensiva este fin de semana",
    "URGENTE: Necesito electricista para reparación en local comercial hoy",
  ]

  const postTypes = [
    { type: "text", icon: "home", category: "Vivienda", urgent: false },
    { type: "text", icon: "tool", category: "Hogar", urgent: true },
    { type: "text", icon: "book", category: "Educación", urgent: false },
    { type: "text", icon: "laptop", category: "Tecnología", urgent: true },
    { type: "text", icon: "home", category: "Hogar", urgent: false },
    { type: "text", icon: "map", category: "Eventos", urgent: true },
    { type: "text", icon: "book", category: "Educación", urgent: false },
    { type: "text", icon: "box", category: "Hogar", urgent: true },
    { type: "text", icon: "users", category: "Hogar", urgent: false },
    { type: "text", icon: "tool", category: "Hogar", urgent: true },
  ]

  // Filtrar por categoría si es necesario
  let filteredPostTypes = [...postTypes]
  if (filter !== "Todos") {
    filteredPostTypes = postTypes.filter((post) => post.category === filter)
  }

  // Si no hay posts después de filtrar, usar todos
  if (filteredPostTypes.length === 0) {
    filteredPostTypes = [...postTypes]
  }

  // Generar posts
  const posts = []
  const offset = refresh ? Math.floor(Math.random() * 10) : 0
  let normalPostCount = 0
  let videoPostInterval = Math.floor(Math.random() * 2) + 2 // Intervalo aleatorio entre 2 y 3

  for (let i = 0; i < count; i++) {
    const randomOffset = Math.floor(Math.random() * 1000) + start + i + offset
    const uniqueId = randomOffset + (refresh ? 2000 : 0)

    // Incrementar contador de posts normales
    normalPostCount++

    // Comprobar si es hora de insertar un post de video
    if (normalPostCount >= videoPostInterval) {
      // Seleccionar un profesional y un video aleatorio
      const profIndex = Math.floor(Math.random() * professionalData.length)
      const videoIndex = Math.floor(Math.random() * professionalVideos.length)
      const professional = professionalData[profIndex]
      const videoUrl = professionalVideos[videoIndex]

      // Crear post de video
      posts.push({
        id: 5000 + profIndex + (refresh ? 1000 : 0),
        user: {
          id: professional.id,
          name: professional.name,
          location: professional.location,
          verified: professional.verified,
        },
        post: {
          type: "video",
          title: `${professional.profession} - ${professional.experience}`,
          description: professional.description,
          category: "Profesional",
          videoUrl: videoUrl,
          icon: "video",
          urgent: false,
          rating: professional.rating,
        },
        timestamp: new Date().toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit", year: "2-digit" }),
        time: new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }),
        saved: Math.random() > 0.7,
        stats: {
          rating: professional.rating.toFixed(1),
          recommendations: Math.floor(Math.random() * 50) + 20,
          badges: Math.floor(Math.random() * 5) + 3,
        },
      })

      // Resetear contador y establecer nuevo intervalo aleatorio
      normalPostCount = 0
      videoPostInterval = Math.floor(Math.random() * 3) + 2 // Intervalo aleatorio entre 2 y 4
    }

    const userIndex = (start + i + offset) % users.length
    const postIndex = (start + i + offset) % filteredPostTypes.length

    const isUrgentPost = Math.random() > 0.7
    const titleIndex = (start + i + offset) % (isUrgentPost ? urgentPostTitles.length : postTitles.length)
    const title = isUrgentPost ? urgentPostTitles[titleIndex] : postTitles[titleIndex]

    const post = {
      ...filteredPostTypes[postIndex],
      title,
      urgent: isUrgentPost || filteredPostTypes[postIndex].urgent,
    }

    const user = users[userIndex]
    const timestamp = new Date()
    timestamp.setDate(timestamp.getDate() - Math.floor(Math.random() * 7))

    const stats = {
      rating: (3.5 + Math.random() * 1.5).toFixed(1),
      recommendations: Math.floor(Math.random() * 30) + 5,
      badges: Math.floor(Math.random() * 5) + 1,
    }

    // Generar un precio aleatorio basado en la categoría
    const generatePrice = () => {
      const basePrice = Math.floor(Math.random() * 50) + 10
      const isHourly = Math.random() > 0.6
      return isHourly ? `${basePrice}€/h` : `${basePrice * 2}€`
    }

    posts.push({
      id: start + i + (refresh ? 1000 : 0),
      user,
      post: {
        ...filteredPostTypes[postIndex],
        title,
        urgent: isUrgentPost || filteredPostTypes[postIndex].urgent,
        price: generatePrice(), // Añadir precio aleatorio
      },
      timestamp: timestamp.toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit", year: "2-digit" }),
      time: timestamp.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }),
      saved: Math.random() > 0.7,
      stats: stats,
    })

    // Añadir encuesta cada 4-5 posts
    if ((start + i + 1) % 5 === 0) {
      const surveyIndex = Math.floor(Math.random() * 3)
      const surveyUser = users[(userIndex + 3) % users.length]
      const surveyTimestamp = new Date()
      surveyTimestamp.setDate(surveyTimestamp.getDate() - Math.floor(Math.random() * 3))

      const surveyTypes = [
        {
          title: "ENCUESTA: ¿Qué tipo de servicios buscas más frecuentemente?",
          options: ["Fontanería", "Electricidad", "Limpieza", "Cuidado de niños", "Reparaciones"],
        },
        {
          title: "ENCUESTA: ¿Cómo valoras la calidad de los profesionales en la app?",
          options: ["Excelente", "Buena", "Regular", "Mala", "Muy mala"],
        },
        {
          title: "ENCUESTA: ¿Qué características valoras más en un compañero de piso?",
          options: ["Limpieza", "Respeto", "Sociabilidad", "Horarios compatibles", "Que pague a tiempo"],
        },
      ]

      posts.push({
        id: 1000 + start + i + (refresh ? 1000 : 0),
        user: surveyUser,
        post: {
          type: "survey",
          title: surveyTypes[surveyIndex].title,
          options: surveyTypes[surveyIndex].options,
          icon: "clipboard",
          category: "Encuesta",
          urgent: false,
          price: "N/A", // Añadir precio para mantener consistencia
        },
        timestamp: surveyTimestamp.toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit", year: "2-digit" }),
        time: surveyTimestamp.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }),
        likes: Math.floor(Math.random() * 20),
        comments: Math.floor(Math.random() * 10),
        saved: Math.random() > 0.8,
        stats: {
          rating: (4.0 + Math.random() * 1.0).toFixed(1),
          recommendations: Math.floor(Math.random() * 20) + 10,
          badges: Math.floor(Math.random() * 3) + 1,
        },
      })
    }
  }

  return posts
}

// Función para optimizar la reproducción de videos
const optimizeVideoPlayback = () => {
  // Usar requestIdleCallback si está disponible, o setTimeout como fallback
  const scheduleTask = window.requestIdleCallback || ((cb) => setTimeout(cb, 1))

  scheduleTask(() => {
    const videoElements = document.querySelectorAll("video")
    videoElements.forEach((video) => {
      // Configurar atributos para reproducción óptima
      video.setAttribute("playsinline", "")
      video.setAttribute("webkit-playsinline", "")
      video.muted = true
      video.preload = "auto"

      // Crear un IntersectionObserver para cada video
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              video.play().catch((err) => console.log("Error al reproducir:", err))
            } else {
              video.pause()
            }
          })
        },
        { threshold: 0.5 },
      )

      observer.observe(video)
    })
  })
}

// Función para asegurar que los videos estén listos para reproducción automática
const prepareVideosForAutoplay = () => {
  setTimeout(() => {
    const videoElements = document.querySelectorAll("video")
    videoElements.forEach((video) => {
      video.load()
      video.muted = true
      video.setAttribute("playsinline", "")
      video.setAttribute("webkit-playsinline", "")
    })
  }, 500)
}

const createVideoPost = (id) => {
  // Video URLs - add more variety
  const videoUrls = [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fontanero.mp4-Yx9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9I.mp4",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/electricista.mp4-Yx9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9I.mp4",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/carpintero.mp4-Yx9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9I.mp4",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pintor.mp4-Yx9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9I.mp4",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/jardinero.mp4-Yx9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9I.mp4",
  ]

  // More variety in professionals
  const professionals = [
    { name: "Carlos Martínez", profession: "Fontanero", category: "Fontanería" },
    { name: "Laura Gómez", profession: "Electricista", category: "Electricidad" },
    { name: "Miguel Sánchez", profession: "Carpintero", category: "Carpintería" },
    { name: "Ana Rodríguez", profession: "Pintora", category: "Pintura" },
    { name: "Javier López", profession: "Jardinero", category: "Jardinería" },
    { name: "Elena Torres", profession: "Limpieza", category: "Limpieza" },
    { name: "David Ruiz", profession: "Cerrajero", category: "Cerrajería" },
  ]

  const randomProIndex = Math.floor(Math.random() * professionals.length)
  const randomVideoIndex = Math.floor(Math.random() * videoUrls.length)

  return {
    id: 1000 + id,
    user: {
      id: 2000 + id,
      name: professionals[randomProIndex].name,
      location: "Bilbao",
      verified: Math.random() > 0.3,
    },
    post: {
      id: 3000 + id,
      title: `Servicios profesionales de ${professionals[randomProIndex].profession}`,
      type: "video",
      category: professionals[randomProIndex].category,
      videoUrl: videoUrls[randomVideoIndex],
      description: `Ofrezco servicios de ${professionals[randomProIndex].profession.toLowerCase()} con más de ${Math.floor(Math.random() * 10) + 5} años de experiencia. Trabajo rápido y de calidad.`,
    },
    timestamp: "Hoy",
    time: `${Math.floor(Math.random() * 12) + 1}:${Math.floor(Math.random() * 60)
      .toString()
      .padStart(2, "0")}`,
    saved: false,
    stats: {
      rating: (4 + Math.random()).toFixed(1),
      recommendations: Math.floor(Math.random() * 100) + 20,
      badges: Math.floor(Math.random() * 5) + 1,
    },
  }
}

const createNormalPost = (id) => {
  // Implementation for normal posts
  // Keep your existing implementation
}

// Función para forzar la reproducción automática de videos
const forceAutoplayVideos = () => {
  // Usar un intervalo para intentar reproducir videos periódicamente
  const interval = setInterval(() => {
    const videos = document.querySelectorAll("video")
    let playedAny = false

    videos.forEach((video) => {
      // Asegurarse de que el video tenga los atributos correctos
      video.muted = true
      video.setAttribute("muted", "")
      video.playsInline = true
      video.setAttribute("playsinline", "")
      video.setAttribute("webkit-playsinline", "")
      video.autoplay = true
      video.setAttribute("autoplay", "")

      // Verificar si el video está visible
      const rect = video.getBoundingClientRect()
      const isVisible =
        rect.top >= -rect.height &&
        rect.top <= window.innerHeight &&
        rect.left >= -rect.width &&
        rect.left <= window.innerWidth

      if (isVisible && video.paused) {
        // Intentar reproducir el video
        video
          .play()
          .then(() => {
            playedAny = true
          })
          .catch((error) => {
            console.error("Error al forzar reproducción:", error)
          })
      }
    })

    // Si no se reprodujo ningún video después de varios intentos, detener el intervalo
    if (!playedAny) {
      clearInterval(interval)
    }
  }, 1000)

  // Limpiar después de 10 segundos
  setTimeout(() => {
    clearInterval(interval)
  }, 10000)
}

export default function Home() {
  const { toast } = useToast()
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [page, setPage] = useState(0)
  const [activeFilter, setActiveFilter] = useState("Todos")
  const [showFilterModal, setShowFilterModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [showConnectPopup, setShowConnectPopup] = useState(false)
  const [connectUser, setConnectUser] = useState({
    name: "",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2812%29.jfif-CCy5Tm8SlqVRo3k10EEfHfndniubMd.jpeg",
    profession: "Profesional",
  })
  const [showResponsePopup, setShowResponsePopup] = useState(false)
  const [responseAction, setResponseAction] = useState("")
  const [unreadMessages, setUnreadMessages] = useState(3)
  const [hasNewSavedRequests, setHasNewSavedRequests] = useState(true)
  const [showMessageNotification, setShowMessageNotification] = useState(false)
  const [messageNotification, setMessageNotification] = useState({
    sender: {
      name: "",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2810%29.jfif-lMM6ZSR9TENpeXKyJ06CDIkVJhGzss.jpeg",
      id: "1",
    },
    message: "",
  })
  const [hasMorePosts, setHasMorePosts] = useState(true)
  const [filters, setFilters] = useState({})
  const [showSearchModal, setShowSearchModal] = useState(false)
  const searchInputRef = useRef<HTMLInputElement>(null)

  // Añadir un estado para controlar la visibilidad de los filtros avanzados
  const [filtersVisible, setFiltersVisible] = useState(false)
  const [showQuickIAModal, setShowQuickIAModal] = useState(false)

  // Modificar la función que maneja la apertura de los filtros
  const handleOpenFilters = () => {
    setFiltersVisible(true)
    // Cualquier otra lógica existente para abrir filtros
  }

  // Modificar la función que maneja el cierre de los filtros
  const handleCloseFilters = () => {
    setFiltersVisible(false)
    setShowFilterModal(false)
  }

  // Función para refrescar la página
  const refreshHomePage = () => {
    toast({
      title: "Actualizando",
      description: "Cargando nuevos anuncios...",
      duration: 2000,
    })
    refreshPosts()
  }

  // Cargar posts iniciales
  useEffect(() => {
    loadMorePosts(true)
  }, [activeFilter])

  // Función para cargar más posts
  const loadMorePosts = (reset = false) => {
    if (loading) return

    setLoading(true)

    // Simulamos una carga de datos con delay mínimo para mejor UX
    setTimeout(() => {
      const offset = reset ? 0 : page * 10
      const newPosts = generatePosts(offset, 10, activeFilter)

      if (reset) {
        setPosts(newPosts)
        setPage(1)
        setHasMorePosts(true)
      } else {
        const existingIds = posts.map((post) => post.id)
        const filteredNewPosts = newPosts.filter((post) => !existingIds.includes(post.id))

        setPosts((prevPosts) => [...prevPosts, ...filteredNewPosts])
        setPage((prevPage) => prevPage + 1)

        // Simular que después de cargar muchos posts, ya no hay más
        if (page > 5) {
          setHasMorePosts(false)
        }
      }

      // Después de actualizar los posts, optimizar la reproducción de videos
      optimizeVideoPlayback()

      setLoading(false)
    }, 300)
  }

  // Función para refrescar los posts
  const refreshPosts = () => {
    const newPosts = generatePosts(0, 10, activeFilter, true)
    setPosts(newPosts)
    setPage(1)
    setHasMorePosts(true)
  }

  // Simular notificaciones en tiempo real - solicitudes de seguimiento
  useEffect(() => {
    const timer = setInterval(() => {
      const randomUsers = [
        {
          name: "Laura Vega",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%286%29.jfif-2N7CGhkzwCvR9V7h8wckVtCaVgBnLD.jpeg",
          profession: "Diseñadora",
        },
        {
          name: "Miguel Torres",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%287%29.jfif-ymppqAxBMrDCcfpYae8hqdZfdpHwbd.jpeg",
          profession: "Fontanero",
        },
        {
          name: "Carmen Ortiz",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%281%29.jfif-togashgF7m10GyOiYVlmWbOMn5s2bP.jpeg",
          profession: "Profesora",
        },
        {
          name: "Javier Ruiz",
          image:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/descarga.jfif-1forRaQUkhYOqydcVKCTUM2bvDk2Fh.jpeg",
          profession: "Electricista",
        },
      ]
      const randomUser = randomUsers[Math.floor(Math.random() * randomUsers.length)]
      setConnectUser(randomUser)
      setShowConnectPopup(true)

      // Ocultar después de 10 segundos si no hay interacción
      const hideTimer = setTimeout(() => {
        setShowConnectPopup(false)
      }, 10000)

      return () => clearTimeout(hideTimer)
    }, 90000) // Cada minuto y medio

    return () => clearInterval(timer)
  }, [])

  // Simular notificaciones de mensajes
  useEffect(() => {
    const timer = setInterval(() => {
      const randomMessages = [
        {
          sender: {
            name: "Carlos Martínez",
            image:
              "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%285%29.jfif-XgPkvJ9HwSSvCwKNvTcrGT3gEF6VLO.jpeg",
            id: "2",
          },
          message: "Hola, ¿estás disponible para un trabajo mañana?",
        },
        {
          sender: {
            name: "Elena Gómez",
            image:
              "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%281%29.jfif-togashgF7m10GyOiYVlmWbOMn5s2bP.jpeg",
            id: "3",
          },
          message: "Te he enviado los detalles del proyecto",
        },
        {
          sender: {
            name: "Roberto Sánchez",
            image:
              "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%283%29.jfif-tSg7Nx9ozw5uCpqHsdovFwrDGj1kA5.jpeg",
            id: "4",
          },
          message: "¿Podemos hablar sobre el presupuesto?",
        },
        {
          sender: {
            name: "Ana López",
            image:
              "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%282%29.jfif-3AxWczIWmZr3tN77VFciuOSWNeMW2F.jpeg",
            id: "5",
          },
          message: "Gracias por tu ayuda, ha quedado perfecto",
        },
      ]

      const randomMessage = randomMessages[Math.floor(Math.random() * randomMessages.length)]
      setMessageNotification(randomMessage)
      setShowMessageNotification(true)

      // Incrementar contador de mensajes no leídos
      setUnreadMessages((prev) => prev + 1)

      // Ocultar después de 5 segundos
      const hideTimer = setTimeout(() => {
        setShowMessageNotification(false)
      }, 5000)

      return () => clearTimeout(hideTimer)
    }, 120000) // Cada dos minutos

    return () => clearInterval(timer)
  }, [])

  // Manejar respuesta a solicitud de conexión
  const handleConnectResponse = (action: string) => {
    setShowConnectPopup(false)
    setResponseAction(action)
    setShowResponsePopup(true)

    toast({
      title: action === "aceptada" ? "Solicitud aceptada" : "Solicitud rechazada",
      description:
        action === "aceptada"
          ? `Has aceptado la solicitud de ${connectUser.name}`
          : `Has rechazado la solicitud de ${connectUser.name}`,
      duration: 3000,
    })

    // Ocultar respuesta después de 3 segundos
    setTimeout(() => {
      setShowResponsePopup(false)
    }, 3000)
  }

  // Manejar búsqueda
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      toast({
        title: "Búsqueda iniciada",
        description: `Buscando: "${searchQuery}"`,
        duration: 2000,
      })
    }
  }

  // Aplicar filtros
  const handleApplyFilters = (newFilters: any) => {
    setFilters(newFilters)
    toast({
      title: "Filtros aplicados",
      description: "Los resultados han sido actualizados según tus filtros",
      duration: 2000,
    })
  }

  // Limpiar búsqueda
  const clearSearch = () => {
    setSearchQuery("")
    setShowSearchResults(false)
  }

  // Modificar la función handleSavePost para manejar el caso cuando el evento es undefined
  const handleSavePost = (postId: number, event?: React.MouseEvent) => {
    // Prevenir el comportamiento predeterminado solo si el evento existe
    if (event) {
      event.preventDefault()
      event.stopPropagation()
    }

    const post = posts.find((p) => p.id === postId)
    const wasSaved = post?.saved

    setPosts(posts.map((post) => (post.id === postId ? { ...post, saved: !post.saved } : post)))

    toast({
      title: wasSaved ? "Anuncio eliminado de guardados" : "Anuncio guardado correctamente",
      duration: 2000,
    })
  }

  // Función para crear nuevo anuncio
  const handleCreatePost = () => {
    toast({
      title: "Crear anuncio",
      description: "Redirigiendo a la página de creación de anuncios",
      duration: 2000,
    })
    // Aquí iría la redirección a la página de creación de anuncios
  }

  const handleLikePost = (postId: number, event: React.MouseEvent) => {
    event.preventDefault()
    event.stopPropagation()

    const post = posts.find((p) => p.id === postId)
    const wasLiked = post?.liked

    setPosts(posts.map((post) => (post.id === postId ? { ...post, liked: !post.liked } : post)))

    toast({
      title: wasLiked ? "Anuncio eliminado de favoritos" : "Anuncio guardado correctamente",
      duration: 2000,
    })
  }

  // Manejar la búsqueda desde el modal
  const handleSearchFromModal = (query: string) => {
    setSearchQuery(query)
    toast({
      title: "Búsqueda iniciada",
      description: `Buscando: "${query}"`,
      duration: 2000,
    })
  }

  // Manejar el foco en el input de búsqueda
  const handleSearchFocus = () => {
    setShowSearchModal(true)
  }

  // Manejar el cambio en el input de búsqueda
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  // Manejar la tecla Enter en el input de búsqueda
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearchFromModal(searchQuery)
    }
  }

  // Manejar el cierre del modal de búsqueda
  const handleCloseSearchModal = () => {
    setShowSearchModal(false)
    // Asegurar que la barra de navegación esté visible
    const bottomNav = document.querySelector(".bottom-navigation")
    if (bottomNav) bottomNav.classList.remove("hidden")
  }

  // Función para asegurar que los videos estén listos para reproducción automática
  useEffect(() => {
    if (posts.length > 0) {
      prepareVideosForAutoplay()
    }
  }, [posts])

  // Añadir este efecto después del useEffect que carga los posts iniciales
  useEffect(() => {
    if (posts.length > 0) {
      // Optimizar la reproducción de videos después de que los posts se carguen
      optimizeVideoPlayback()
    }
  }, [posts])

  // Añadir este efecto para forzar la reproducción automática
  useEffect(() => {
    if (posts.length > 0) {
      // Esperar a que el DOM se actualice
      setTimeout(() => {
        forceAutoplayVideos()
      }, 500)
    }
  }, [posts])

  // Añadir un listener para el evento scroll
  useEffect(() => {
    const handleScroll = () => {
      const videos = document.querySelectorAll("video")

      videos.forEach((video) => {
        const rect = video.getBoundingClientRect()
        const isVisible =
          rect.top >= -rect.height &&
          rect.top <= window.innerHeight &&
          rect.left >= -rect.width &&
          rect.left <= window.innerWidth

        if (isVisible && video.paused) {
          video.play().catch((error) => {
            console.error("Error al reproducir durante scroll:", error)
          })
        }
      })
    }

    window.addEventListener("scroll", handleScroll, { passive: true })

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <Link href="/" onClick={refreshPosts}>
          <span className="font-bold text-yellow-500 text-lg">QuickSer</span>
        </Link>
        <div className="flex items-center flex-1 ml-4">
          <div className="relative flex-1">
            <div className="pl-10 pr-3 py-1.5 rounded-full border border-gray-200 text-sm h-9 flex items-center bg-gray-50">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                ref={searchInputRef}
                type="text"
                className="bg-transparent border-none outline-none w-full text-gray-700 placeholder-gray-400"
                placeholder="Buscar servicios, profesionales..."
                value={searchQuery}
                onChange={handleSearchChange}
                onFocus={handleSearchFocus}
                onKeyDown={handleSearchKeyDown}
                autoComplete="off"
              />
            </div>
          </div>
        </div>
        <div className="flex items-center ml-2">
          <Link href="/notifications">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                {unreadMessages}
              </span>
            </Button>
          </Link>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full ml-1"
            onClick={() => {
              handleOpenFilters()
              setShowFilterModal(true)
            }}
          >
            <Filter className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Filtros */}
      <div className="px-4 pb-2 sticky top-16 bg-white z-10">
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant="outline"
              size="sm"
              className={`rounded-full text-xs whitespace-nowrap ${
                activeFilter === category ? "bg-black text-white border-black" : "border-gray-300 text-gray-700"
              }`}
              onClick={() => {
                setActiveFilter(category)
                setPage(0)
                loadMorePosts(true)
                toast({
                  title: "Filtro aplicado",
                  description: `Mostrando anuncios de ${category}`,
                  duration: 2000,
                })
              }}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Modal de filtros avanzados */}
      {showFilterModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg">Filtros avanzados</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setShowFilterModal(false)
                  handleCloseFilters()
                }}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="space-y-6">
              <div>
                <h4 className="font-medium text-sm mb-2">Categoría</h4>
                <p className="text-xs text-gray-500 mb-3">Selecciona la categoría de servicios que estás buscando</p>
                <div className="grid grid-cols-2 gap-2">
                  {categories.map((category) => (
                    <Button
                      key={category}
                      variant="outline"
                      size="sm"
                      className={`rounded-full text-xs ${
                        activeFilter === category ? "bg-black text-white border-black" : "border-gray-300 text-gray-700"
                      }`}
                      onClick={() => setActiveFilter(category)}
                    >
                      {category}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium text-sm mb-2">Ubicación</h4>
                <p className="text-xs text-gray-500 mb-3">Filtra por ubicación o establece un radio de distancia</p>
                <Input placeholder="Cualquier ubicación" className="rounded-full text-sm mb-2" />
                <div className="mt-2">
                  <label className="text-xs text-gray-700 mb-1 block">Radio de distancia</label>
                  <div className="flex items-center justify-between">
                    <span className="text-xs">1 km</span>
                    <input type="range" min="1" max="50" className="mx-2 flex-1" />
                    <span className="text-xs">50 km</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-sm mb-2">Precio</h4>
                <p className="text-xs text-gray-500 mb-3">Filtra por rango de precios o nivel de precio</p>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" className="rounded-full text-xs flex-1">
                    €
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-full text-xs flex-1">
                    €€
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-full text-xs flex-1">
                    €€€
                  </Button>
                </div>
                <div className="mt-3">
                  <div className="flex justify-between">
                    <Input placeholder="Min €" className="w-[48%] rounded-full text-sm" />
                    <Input placeholder="Max €" className="w-[48%] rounded-full text-sm" />
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-sm mb-2">Valoración</h4>
                <p className="text-xs text-gray-500 mb-3">Filtra por valoración mínima de los usuarios</p>
                <div className="flex space-x-2">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <Button key={rating} variant="outline" size="sm" className="rounded-full text-xs flex-1">
                      {rating}★
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium text-sm mb-2">Disponibilidad</h4>
                <p className="text-xs text-gray-500 mb-3">Filtra por disponibilidad de fecha y hora</p>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm" className="rounded-full text-xs">
                    Hoy
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-full text-xs">
                    Mañana
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-full text-xs">
                    Esta semana
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-full text-xs">
                    Este mes
                  </Button>
                </div>
                <div className="mt-3">
                  <label className="text-xs text-gray-700 mb-1 block">Franja horaria</label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button variant="outline" size="sm" className="rounded-full text-xs">
                      Mañana
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-full text-xs">
                      Tarde
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-full text-xs">
                      Noche
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex space-x-2 mt-6">
              <Button
                variant="outline"
                className="flex-1 rounded-full"
                onClick={() => {
                  setActiveFilter("Todos")
                  handleCloseFilters()
                  setShowFilterModal(false)
                  loadMorePosts(true)
                  toast({
                    title: "Filtros eliminados",
                    description: "Mostrando todos los anuncios",
                    duration: 2000,
                  })
                }}
              >
                Limpiar
              </Button>
              <Button
                className="flex-1 rounded-full bg-yellow-500 hover:bg-yellow-600 text-white"
                onClick={() => {
                  handleCloseFilters()
                  setShowFilterModal(false)
                  toast({
                    title: "Filtros aplicados",
                    description: "Los resultados han sido actualizados",
                    duration: 2000,
                  })
                }}
              >
                Aplicar
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Feed con virtualización */}
      <VirtualFeed
        initialPosts={posts}
        onLoadMore={loadMorePosts}
        loading={loading}
        hasMore={hasMorePosts}
        onRefresh={refreshPosts}
        onSavePost={handleSavePost}
        onLikePost={handleLikePost}
        searchQuery={searchQuery}
        filters={filters}
      />

      {/* Popup de nueva conexión */}
      <FollowRequestPopup
        open={showConnectPopup}
        onClose={() => setShowConnectPopup(false)}
        onAccept={() => handleConnectResponse("aceptada")}
        onReject={() => handleConnectResponse("rechazada")}
        user={connectUser}
      />

      {/* Notificación de mensaje */}
      {showMessageNotification && (
        <MessageNotification
          sender={messageNotification.sender}
          message={messageNotification.message}
          onClose={() => setShowMessageNotification(false)}
        />
      )}

      {/* Popup de respuesta a solicitud de conexión */}
      {showResponsePopup && (
        <div className="fixed bottom-20 left-0 right-0 mx-4 bg-white rounded-xl p-4 shadow-lg border z-30">
          <p className="text-sm text-center">Solicitud {responseAction}</p>
        </div>
      )}

      {/* Modal de filtros */}
      <FilterModal
        isOpen={showFilterModal}
        onClose={handleCloseFilters}
        onApplyFilters={handleApplyFilters}
        initialFilters={filters}
        filterType="home"
      />

      {/* Modal de búsqueda */}
      <SearchModal
        isOpen={showSearchModal}
        onClose={handleCloseSearchModal}
        onSearch={handleSearchFromModal}
        placeholder="Buscar servicios, profesionales..."
        initialQuery={searchQuery}
      />

      {/* Modal de QuickIA */}
      <QuickIAModal
        open={showQuickIAModal}
        onOpenChange={setShowQuickIAModal}
        onSubmit={(content) => {
          setSearchQuery(content.title)
          handleSearchFromModal(content.title)
          setShowQuickIAModal(false)
        }}
        mode="map"
      />

      {/* Bottom navigation */}
      <BottomNavigation
        activeItem="home"
        unreadMessages={unreadMessages}
        refreshHome={refreshHomePage}
        hidden={filtersVisible}
      />
    </div>
  )
}
