"use client"

import { useState } from "react"
import { ArrowLeft, Camera, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { getProfileAvatar } from "@/lib/avatar-utils"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

export default function EditProfilePage() {
  const router = useRouter()
  const [profileImage, setProfileImage] = useState(getProfileAvatar())
  const [username, setUsername] = useState("Diego Domínguez")
  const [location, setLocation] = useState("Bilbao, España")
  const [bio, setBio] = useState(
    "Profesional de la fontanería con más de 10 años de experiencia. Especializado en instalaciones y reparaciones.",
  )
  const [additionalInfo, setAdditionalInfo] = useState("Disponible para trabajos urgentes. Presupuesto sin compromiso.")
  const [showLevel, setShowLevel] = useState(true)
  const [showRating, setShowRating] = useState(true)
  const [selectedSkills, setSelectedSkills] = useState(["Fontanería", "Reparaciones", "Instalaciones"])
  const [contactInfo, setContactInfo] = useState({
    email: "diego.dominguez@example.com",
    phone: "+34 600 123 456",
    website: "",
  })

  const [quickIAOpen, setQuickIAOpen] = useState(false)
  const [quickIAPrompt, setQuickIAPrompt] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const availableSkills = [
    "Fontanería",
    "Reparaciones",
    "Instalaciones",
    "Mantenimiento",
    "Calefacción",
    "Sanitarios",
    "Tuberías",
    "Desatascos",
    "Grifería",
    "Calderas",
  ]

  const handleSaveProfile = (e) => {
    e.preventDefault()

    toast.success("Perfil actualizado correctamente", {
      description: "Los cambios han sido guardados.",
    })

    // Simulamos un tiempo de guardado
    setTimeout(() => {
      router.push("/profile")
    }, 1000)
  }

  const handleSkillToggle = (skill) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter((s) => s !== skill))
    } else {
      setSelectedSkills([...selectedSkills, skill])
    }
  }

  const handleImageUpload = () => {
    // Simular selección de archivo
    const input = document.createElement("input")
    input.type = "file"
    input.accept = "image/*"
    input.onchange = (e) => {
      // Simulamos que se mantiene la misma imagen para mantener consistencia
      toast.success("Imagen actualizada correctamente")
    }
    input.click()
  }

  const handleQuickIAProcess = () => {
    if (!quickIAPrompt.trim()) {
      toast.error("Por favor, escribe cómo quieres que sea tu perfil")
      return
    }

    setIsProcessing(true)

    // Simulate AI processing
    setTimeout(() => {
      // Example updates based on the prompt
      if (quickIAPrompt.toLowerCase().includes("fontanero")) {
        setBio(
          "Fontanero profesional con más de 10 años de experiencia en instalaciones, reparaciones y mantenimiento. Especializado en soluciones rápidas y eficientes para todo tipo de problemas de fontanería.",
        )
        setSelectedSkills(["Fontanería", "Reparaciones", "Instalaciones", "Mantenimiento", "Desatascos"])
        setAdditionalInfo(
          "Disponible para emergencias 24/7. Presupuestos sin compromiso. Garantía en todos los trabajos realizados.",
        )
      } else if (quickIAPrompt.toLowerCase().includes("profesional")) {
        setBio(
          "Profesional de la fontanería certificado con experiencia demostrada en proyectos residenciales y comerciales. Enfoque meticuloso y atención al detalle en cada trabajo.",
        )
        setSelectedSkills(["Fontanería", "Instalaciones", "Calefacción", "Tuberías", "Calderas"])
        setAdditionalInfo(
          "Servicio profesional y puntual. Materiales de primera calidad. Referencias disponibles de clientes satisfechos.",
        )
      } else {
        setBio(
          "Experto en fontanería con amplia experiencia en el sector. Ofrezco soluciones personalizadas para cada cliente, garantizando resultados duraderos y de calidad.",
        )
        setSelectedSkills(["Fontanería", "Reparaciones", "Instalaciones", "Grifería", "Sanitarios"])
        setAdditionalInfo("Servicio rápido y eficiente. Precios competitivos. Satisfacción garantizada.")
      }

      setIsProcessing(false)
      setQuickIAOpen(false)

      toast.success("Perfil optimizado correctamente", {
        description: "Se han aplicado las mejoras sugeridas por QuickIA.",
      })
    }, 2000)
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
      {/* Header */}
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b">
        <div className="flex items-center">
          <Link href="/profile">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">Editar Perfil</h1>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-1 bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600 border-0"
            onClick={() => setQuickIAOpen(true)}
          >
            <Sparkles className="h-4 w-4" />
            QuickIA
          </Button>
          <Button variant="ghost" onClick={() => router.push("/profile")}>
            Cancelar
          </Button>
        </div>
      </div>

      <form onSubmit={handleSaveProfile} className="p-4 space-y-6">
        {/* Foto de perfil */}
        <div className="flex flex-col items-center">
          <div className="relative group">
            <Image
              src={profileImage || "/placeholder.svg"}
              alt="Foto de perfil"
              width={100}
              height={100}
              className="w-24 h-24 rounded-full object-cover border-2 border-gray-200"
            />
            <div
              className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
              onClick={handleImageUpload}
            >
              <Camera className="text-white h-6 w-6" />
            </div>
          </div>
          <button type="button" className="mt-2 text-sm text-blue-600" onClick={handleImageUpload}>
            Cambiar foto
          </button>
        </div>

        {/* Información básica */}
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1 block">Nombre</label>
            <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Tu nombre" />
          </div>

          <div>
            <label className="text-sm font-medium mb-1 block">Ubicación</label>
            <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Tu ubicación" />
          </div>

          <div>
            <label className="text-sm font-medium mb-1 block">Biografía</label>
            <Textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Cuéntanos sobre ti" rows={3} />
          </div>

          <div>
            <label className="text-sm font-medium mb-1 block">Información adicional</label>
            <Textarea
              value={additionalInfo}
              onChange={(e) => setAdditionalInfo(e.target.value)}
              placeholder="Información adicional sobre tus servicios"
              rows={2}
            />
          </div>
        </div>

        <Separator />

        {/* Habilidades profesionales */}
        <div>
          <h2 className="text-sm font-medium mb-3">Habilidades profesionales</h2>
          <div className="flex flex-wrap gap-2">
            {availableSkills.map((skill) => (
              <Badge
                key={skill}
                variant={selectedSkills.includes(skill) ? "default" : "outline"}
                className={`cursor-pointer ${selectedSkills.includes(skill) ? "bg-black hover:bg-gray-800" : "hover:bg-gray-100"}`}
                onClick={() => handleSkillToggle(skill)}
              >
                {skill}
              </Badge>
            ))}
          </div>
        </div>

        <Separator />

        {/* Información de contacto */}
        <div className="space-y-4">
          <h2 className="text-sm font-medium">Información de contacto</h2>

          <div>
            <label className="text-sm text-gray-500 mb-1 block">Correo electrónico</label>
            <Input
              value={contactInfo.email}
              onChange={(e) => setContactInfo({ ...contactInfo, email: e.target.value })}
              placeholder="Tu correo electrónico"
              type="email"
            />
          </div>

          <div>
            <label className="text-sm text-gray-500 mb-1 block">Teléfono</label>
            <Input
              value={contactInfo.phone}
              onChange={(e) => setContactInfo({ ...contactInfo, phone: e.target.value })}
              placeholder="Tu número de teléfono"
              type="tel"
            />
          </div>

          <div>
            <label className="text-sm text-gray-500 mb-1 block">Sitio web (opcional)</label>
            <Input
              value={contactInfo.website}
              onChange={(e) => setContactInfo({ ...contactInfo, website: e.target.value })}
              placeholder="Tu sitio web"
              type="url"
            />
          </div>
        </div>

        <Separator />

        {/* Opciones de privacidad */}
        <div className="space-y-4">
          <h2 className="text-sm font-medium">Opciones de privacidad</h2>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Mostrar nivel</p>
              <p className="text-xs text-gray-500">Tu nivel será visible para otros usuarios</p>
            </div>
            <Switch checked={showLevel} onCheckedChange={setShowLevel} />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Mostrar valoraciones</p>
              <p className="text-xs text-gray-500">Tus valoraciones serán visibles para otros usuarios</p>
            </div>
            <Switch checked={showRating} onCheckedChange={setShowRating} />
          </div>
        </div>

        {/* Botón de guardar */}
        <div className="pt-4">
          <Button type="submit" className="w-full" size="lg">
            Guardar cambios
          </Button>
        </div>
      </form>
      {/* QuickIA Dialog */}
      <Dialog open={quickIAOpen} onOpenChange={setQuickIAOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-purple-500" />
              QuickIA - Optimizador de Perfil
            </DialogTitle>
            <DialogDescription>
              QuickIA es una inteligencia artificial que te ayuda a editar y optimizar tu perfil según tus preferencias.
              Solo tienes que escribir cómo quieres que sea tu perfil y QuickIA lo ajustará automáticamente para mejorar
              tu posicionamiento y destacar en la barra del buscador.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Textarea
              value={quickIAPrompt}
              onChange={(e) => setQuickIAPrompt(e.target.value)}
              placeholder="Ejemplo: Quiero un perfil profesional de fontanero especializado en reparaciones urgentes, con un tono cercano pero formal..."
              rows={5}
              className="resize-none"
            />
            <div className="text-xs text-gray-500">
              <p>Sugerencias:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Describe tu especialidad y experiencia</li>
                <li>Menciona el tono que prefieres (formal, cercano, técnico)</li>
                <li>Indica servicios específicos que ofreces</li>
                <li>Especifica tu disponibilidad o zona de trabajo</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setQuickIAOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleQuickIAProcess}
              className="bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600"
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <span className="animate-pulse mr-2">Optimizando...</span>
                  <span className="animate-spin">⚙️</span>
                </>
              ) : (
                <>Optimizar perfil</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
