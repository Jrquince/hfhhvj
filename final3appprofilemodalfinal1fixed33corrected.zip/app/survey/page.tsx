"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { SurveyCompletionDialog } from "@/components/survey-completion-dialog"

// Definir la estructura de las preguntas
interface Question {
  id: number
  text: string
  options: string[]
}

// Preguntas de ejemplo
const questions: Question[] = [
  {
    id: 1,
    text: "¿Qué tipo de servicios buscas con más frecuencia?",
    options: ["Reparaciones del hogar", "Servicios profesionales", "Cuidado personal", "Educación", "Otros"],
  },
  {
    id: 2,
    text: "¿Con qué frecuencia utilizas aplicaciones para buscar servicios?",
    options: ["Diariamente", "Semanalmente", "Mensualmente", "Raramente", "Nunca"],
  },
  {
    id: 3,
    text: "¿Qué factor es más importante para ti al elegir un servicio?",
    options: ["Precio", "Calidad", "Cercanía", "Recomendaciones", "Disponibilidad"],
  },
  {
    id: 4,
    text: "¿Cómo prefieres contactar con los proveedores de servicios?",
    options: ["Llamada telefónica", "Mensaje de texto", "Chat en la app", "Email", "Contacto en persona"],
  },
  {
    id: 5,
    text: "¿Qué características te gustaría ver mejoradas en nuestra aplicación?",
    options: [
      "Más filtros de búsqueda",
      "Mejor sistema de valoraciones",
      "Más opciones de pago",
      "Verificación de proveedores",
      "Interfaz más sencilla",
    ],
  },
]

export default function SurveyPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [showCompletionDialog, setShowCompletionDialog] = useState(false)

  // Calcular el progreso
  const progress = ((currentQuestion + 1) / questions.length) * 100

  // Manejar la selección de una opción
  const handleOptionSelect = (option: string) => {
    setSelectedOption(option)
  }

  // Manejar el botón de continuar
  const handleContinue = () => {
    if (selectedOption) {
      // Guardar la respuesta actual
      setAnswers({
        ...answers,
        [questions[currentQuestion].id]: selectedOption,
      })

      // Si es la última pregunta, mostrar el diálogo de finalización
      if (currentQuestion === questions.length - 1) {
        setShowCompletionDialog(true)
      } else {
        // Avanzar a la siguiente pregunta
        setCurrentQuestion(currentQuestion + 1)
        setSelectedOption(null)
      }
    }
  }

  // Manejar el botón de volver
  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      setSelectedOption(answers[questions[currentQuestion - 1].id] || null)
    }
  }

  return (
    <div className="max-w-md mx-auto p-4 min-h-screen flex flex-col">
      <div className="flex items-center mb-6">
        <Link href="/">
          <Button variant="ghost" size="icon" className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-xl font-bold">Encuesta de satisfacción</h1>
      </div>

      <div className="mb-6">
        <Progress value={progress} className="h-2 bg-gray-200" indicatorClassName="bg-orange-500" />
        <div className="flex justify-between mt-2 text-sm text-gray-500">
          <span>
            Pregunta {currentQuestion + 1} de {questions.length}
          </span>
          <span>{Math.round(progress)}%</span>
        </div>
      </div>

      <Card className="flex-1 mb-4">
        <CardHeader>
          <CardTitle className="text-lg">{questions[currentQuestion].text}</CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup value={selectedOption || ""} onValueChange={handleOptionSelect}>
            {questions[currentQuestion].options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2 mb-4">
                <RadioGroupItem value={option} id={`option-${index}`} />
                <Label
                  htmlFor={`option-${index}`}
                  className="flex-1 py-2 px-3 rounded-lg hover:bg-gray-50 cursor-pointer"
                >
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={handleBack} disabled={currentQuestion === 0}>
            Anterior
          </Button>
          <Button
            onClick={handleContinue}
            disabled={!selectedOption}
            className="bg-yellow-500 hover:bg-yellow-600 text-white"
          >
            {currentQuestion === questions.length - 1 ? "Finalizar" : "Continuar"}
          </Button>
        </CardFooter>
      </Card>

      {/* Diálogo de finalización con mensaje de boost de nivel */}
      <SurveyCompletionDialog open={showCompletionDialog} onClose={() => setShowCompletionDialog(false)} />
    </div>
  )
}
