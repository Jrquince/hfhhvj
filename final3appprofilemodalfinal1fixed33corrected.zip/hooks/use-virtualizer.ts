// Este archivo es un re-export de @tanstack/react-virtual para facilitar su uso
export { useVirtualizer } from "@tanstack/react-virtual"
