// Colección de imágenes de perfil variadas para usar en toda la aplicación
export const profileImages = [
  "/placeholder.svg?height=300&width=300", // Imagen base placeholder
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1527980965255-d3b416303d12?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1607746882042-944635dfe10e?q=80&w=300&h=300&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?q=80&w=300&h=300&auto=format&fit=crop",
]

// Función para obtener una imagen de perfil aleatoria
export function getRandomProfileImage(): string {
  const randomIndex = Math.floor(Math.random() * profileImages.length)
  return profileImages[randomIndex]
}

// Función para obtener una imagen de perfil basada en un ID o nombre de usuario
// Esto asegura que el mismo usuario siempre tenga la misma imagen
export function getConsistentProfileImage(id: string | number | null | undefined): string {
  // Si el ID es null o undefined, devolver una imagen por defecto
  if (id === null || id === undefined) {
    return profileImages[0] // Usar la primera imagen como imagen por defecto
  }

  // Convertir el id a string si es un número
  const idString = id.toString()

  // Usar el código ASCII de cada carácter en el ID para generar un número
  let sum = 0
  for (let i = 0; i < idString.length; i++) {
    sum += idString.charCodeAt(i)
  }

  // Usar ese número para seleccionar una imagen de manera consistente
  const index = sum % profileImages.length
  return profileImages[index]
}

// Función para obtener múltiples imágenes de perfil únicas
export function getUniqueProfileImages(count: number): string[] {
  // Crear una copia del array de imágenes para no modificar el original
  const availableImages = [...profileImages]
  const result: string[] = []

  // Obtener 'count' imágenes únicas
  for (let i = 0; i < count && availableImages.length > 0; i++) {
    const randomIndex = Math.floor(Math.random() * availableImages.length)
    result.push(availableImages[randomIndex])
    // Eliminar la imagen seleccionada para evitar duplicados
    availableImages.splice(randomIndex, 1)
  }

  return result
}
