// Función para obtener el avatar de un usuario por su ID
export function getAvatarByUserId(userId: number): string {
  // Lista de avatares disponibles
  const avatars = [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%286%29.jfif-2N7CGhkzwCvR9V7h8wckVtCaVgBnLD.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%287%29.jfif-ymppqAxBMrDCcfpYae8hqdZfdpHwbd.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%281%29.jfif-togashgF7m10GyOiYVlmWbOMn5s2bP.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%282%29.jfif-3AxWczIWmZr3tN77VFciuOSWNeMW2F.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%283%29.jfif-tSg7Nx9ozw5uCpqHsdovFwrDGj1kA5.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%285%29.jfif-XgPkvJ9HwSSvCwKNvTcrGT3gEF6VLO.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2810%29.jfif-lMM6ZSR9TENpeXKyJ06CDIkVJhGzss.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2812%29.jfif-CCy5Tm8SlqVRo3k10EEfHfndniubMd.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/descarga.jfif-1forRaQUkhYOqydcVKCTUM2bvDk2Fh.jpeg",
    "/placeholder.svg?height=64&width=64",
    "/placeholder.svg?height=64&width=64&text=User",
  ]

  // Usar el ID del usuario para seleccionar un avatar consistente para cada usuario
  const index = userId % avatars.length

  // Devolver el avatar correspondiente o uno de respaldo si no está disponible
  return avatars[index] || "/placeholder.svg"
}

// Función para obtener un avatar aleatorio
export function getRandomAvatar(): string {
  const avatars = [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%286%29.jfif-2N7CGhkzwCvR9V7h8wckVtCaVgBnLD.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%287%29.jfif-ymppqAxBMrDCcfpYae8hqdZfdpHwbd.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%281%29.jfif-togashgF7m10GyOiYVlmWbOMn5s2bP.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%282%29.jfif-3AxWczIWmZr3tN77VFciuOSWNeMW2F.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%283%29.jfif-tSg7Nx9ozw5uCpqHsdovFwrDGj1kA5.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%285%29.jfif-XgPkvJ9HwSSvCwKNvTcrGT3gEF6VLO.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2810%29.jfif-lMM6ZSR9TENpeXKyJ06CDIkVJhGzss.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2812%29.jfif-CCy5Tm8SlqVRo3k10EEfHfndniubMd.jpeg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/descarga.jfif-1forRaQUkhYOqydcVKCTUM2bvDk2Fh.jpeg",
  ]

  const randomIndex = Math.floor(Math.random() * avatars.length)
  return avatars[randomIndex]
}

// Función para obtener el avatar de perfil
export function getProfileAvatar(): string {
  // Devolver siempre la imagen de un hombre/chico
  return "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%287%29.jfif-ymppqAxBMrDCcfpYae8hqdZfdpHwbd.jpeg"
}
