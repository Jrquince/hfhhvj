// utils/profile-data.ts
export interface Profile {
  name: string
  image: string
}

export const femaleProfiles: Profile[] = [
  { name: "Lucía García", image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3" },
  { name: "María Fernández", image: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3" },
  { name: "Sofía López", image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3" },
  { name: "Inés González", image: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?ixlib=rb-4.0.3" },
  { name: "Carmen Rodríguez", image: "https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-4.0.3" },
  { name: "Ana Martínez", image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3" },
  { name: "Elena Sánchez", image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-4.0.3" },
  { name: "Isabel Pérez", image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3" },
  { name: "Laura Gómez", image: "https://images.unsplash.com/photo-1544725176-7c40e5a2c9f1?ixlib=rb-4.0.3" },
  { name: "Marta Díaz", image: "https://images.unsplash.com/photo-1542345812-d98b5cd6cf98?ixlib=rb-4.0.3" },
  { name: "Ane Urrutia", image: "https://images.unsplash.com/photo-1544725176-123456789abc?ixlib=rb-4.0.3" },
]

export const maleProfiles: Profile[] = [
  { name: "Alejandro Hernández", image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3" },
  { name: "Carlos Romero", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3" },
  { name: "David Muñoz", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3" },
  { name: "Fernando Navarro", image: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3" },
  { name: "Javier Rubio", image: "https://images.unsplash.com/photo-1544005313-7d3b9a0a6d88?ixlib=rb-4.0.3" },
  { name: "Miguel Ortiz", image: "https://images.unsplash.com/photo-1545992336-8f8e666a5b2b?ixlib=rb-4.0.3" },
  { name: "Pablo Jiménez", image: "https://images.unsplash.com/photo-1544725176-3d45b2a7e470?ixlib=rb-4.0.3" },
  { name: "Raúl Torres", image: "https://images.unsplash.com/photo-1544725176-abcdef123456?ixlib=rb-4.0.3" },
  { name: "Sergio Morales", image: "https://images.unsplash.com/photo-1544725176-fedcba654321?ixlib=rb-4.0.3" },
  { name: "Víctor Ruiz", image: "https://images.unsplash.com/photo-1544725176-xyz987654321?ixlib=rb-4.0.3" },
  { name: "Diego Dominguez", image: "https://images.unsplash.com/photo-1544725176-987654321def?ixlib=rb-4.0.3" },
]
